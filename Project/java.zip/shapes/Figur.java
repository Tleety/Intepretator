package shapes;
/*
 !***************************************************************
 !		Revision history
 !	0.1	980601 
 ! 1.0	980825
 !
 !***************************************************************
*/
import window.*;
import java.awt.*;
/** Common abstract type Figur.
	This should be used as the supertype of figures, that may
	be manipulated and drawn on the screen using the window package.
	A number of common methods is defined as abstract methods.
	@author G�ran Fries
	@version 1.0
*/
public abstract class Figur
{	
	public abstract boolean Within(int x, int y);
	public abstract boolean Within(double x, double y);
	public abstract void Draw(w W);
	public abstract void Erase(w W);
	public abstract void Fill(w W);
	public abstract void Fill(w W, Color C);
	public abstract void EraseFilled(w W);
	public abstract Figur Rotate(Punkt p, double phi);
	public abstract Figur Rotate(double phi);
	public abstract Figur Translate(int dx,int dy);
	public abstract Figur Scale(double x);
	public abstract Poly MakePoly();
	public abstract Punkt GetCentre();
	
	/* *****************************************************
	*	Vrid punkten p1 med vinkeln alpha kring punkten p0
	*	vridningen sker moturs.
	***************************************************** */
	protected Punkt Vrid(Punkt p0,Punkt p1,double alpha)
	{	double r,phi;
		double x0,y0,x1,y1,x2,y2;
		double dx,dy;
		x0=p0.GetX();
		y0=p0.GetY();
		x1=p1.GetX();
		y1=p1.GetY();
		dx=x1-x0;
		dy=y1-y0;
		r=Math.sqrt(dx*dx+dy*dy);
		phi=Math.atan2(dx,dy);
		x2=x0+r*Math.sin(phi-alpha);
		y2=y0+r*Math.cos(phi-alpha);
		return new Punkt(x2,y2);
	}
	/* *****************************************************
	*	Skala upp (ned) en punkt. Vektorn fr�n p0 till p1
	* f�rl�ngs enligt en faktor (kan vara <1) och en ny
	* punkt ber�knas.
	***************************************************** */
	protected Punkt Skala(Punkt p0,Punkt p1,double faktor)
	{	double r,phi;
		double x0,y0,x1,y1,x2,y2;
		double dx,dy;
		x0=p0.GetX();
		y0=p0.GetY();
		x1=p1.GetX();
		y1=p1.GetY();
		dx=x1-x0;
		dy=y1-y0;
		r=Math.sqrt(dx*dx+dy*dy);
		phi=Math.atan2(dx,dy);
		x2=x0+faktor*r*Math.sin(phi);
		y2=y0+faktor*r*Math.cos(phi);
		return new Punkt(x2,y2);
	}
	/* *****************************************************
	*	F�rflytta punkten p med kvantiteten x resp y
	***************************************************** */
	protected Punkt Translatera(Punkt p, int x, int y)
	{return new Punkt(p.GetX()+x,p.GetY()+y);}
}
