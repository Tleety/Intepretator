package shapes;
/*
 !***************************************************************
 !		Revision history
 !	0.1	980601 
 ! 1.0	980825
 !	1.0.1	981007 sin,cos changed in constructor
 !
 !***************************************************************
*/
/** Implements the type for vectors.
	The vectors are in the two dimensional real vector space.
	@author G�ran Fries
	@version 1.0
*/
public class Vektor
{	private double Xr,Yr;
	private int X,Y;
	/* ********************************************
	*		Constructors
	******************************************** */
	/** Create the zero vector.
	*/
	public Vektor()
	{Xr=0; Yr=0; X=0; Y=0;}
	/** Create a vector from two components.
		Using reals.
		@param x First component.
		@param y Second component.
	*/
	public Vektor(double x, double y)
	{Xr=x; Yr=y; X=(int)Xr; Y=(int)Yr;}
	/** Create a vector from two components.
		Using integers.
		@param x First component.
		@param y Second component.
	*/
	public Vektor(int x, int y)
	{X=x; Y=y; Xr=X; Yr=Y;}
	/** Create vector from a point.
		A point and a vector are in many respects the same thing,
		here the methods differ.
		@param P The point.
	*/
	public Vektor(Punkt P)
	{Xr=P.GetX(); Yr=P.GetY(); X=(int)Xr; Y=(int)Yr;}
	/** Create vector from two points.
		Here the vector is regarded as the vector from one
		point to another. (Difference between points).
		@param P1 The first point.
		@param P2 The second point.
	*/
	public Vektor(Punkt P1,Punkt P2)
	{	Xr=P2.GetX()-P1.GetX();
		Yr=P2.GetY()-P1.GetY();
		X=(int)Xr; Y=(int)Yr;
	}
	/** Create a vector with length and direction.
		A point in polar coordinates is used to create a vector.
		@param phi The direction of the vector.
		@param r The length of the vector.
	*/
	public Vektor(double phi,int r)
	{	Xr=(r*Math.cos(phi)); 
		Yr=(r*Math.sin(phi));
		X=(int)Xr; Y=(int)Yr;
	}
	/* ******************************************* */
	/** The size of the vector.
		@return the length or absolute value of the vector.
	*/
	public double Abs()
	{return Math.sqrt(Xr*Xr+Yr*Yr);}
	/** First component.
		@return First component (x).
	*/
	public double XComponent() {return Xr;}
	/** Second component.
		@return Second component (y).
	*/
	public double YComponent() {return Yr;}
	/** Make point.
		@return The coresponding point.
	*/
	public Punkt MakePunkt() {return new Punkt(Xr,Yr);}
	/** Direction.
		@return The direction of the vector.
	*/
	public double Direction() {return Math.PI/2.0-Math.atan2(Xr,Yr);}
	/** Vector addition.
		This vector and another vector are added.
		@param U The second vector.
		@return A new vector, the result of the addition.
	*/
	public Vektor Add (Vektor U)
	{	double x,y;
		x=Xr+U.XComponent();
		y=Yr+U.YComponent();
		return new Vektor(x,y);
	}
	/** Vector subtraction.
		This vector and another vector are subtracted.
		@param U The second vector.
		@return A new vector, the result of the subtraction.
	*/
	public Vektor Sub (Vektor U)
	{	double x,y;
		x=Xr-U.XComponent();
		y=Yr-U.YComponent();
		return new Vektor(x,y);
	}
	/** Scalar product.
		The scalar, dot, product of this vector and another
		vector is calculated.
		@param U The other vector.
		@return The value of the dot product.
	*/
	public float Dot(Vektor U)
	{ return (float)(Xr*U.XComponent()+Yr*U.YComponent()); }
}
