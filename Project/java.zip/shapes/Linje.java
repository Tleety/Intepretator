package shapes;
/*
 !***************************************************************
 !		Revision history
 !	0.1	980601 
 ! 1.0	980825
 !
 !***************************************************************
*/
import java.awt.*;
import window.*;
/** Implements the type for lines.
	@author G�ran Fries
	@version 1.0
*/
public class Linje extends Figur
{	protected double Xr0,Yr0,Xr1,Yr1;
	protected int X0,Y0,X1,Y1;
	/* **********************************************
	*		Constructors
	********************************************** */
	/** Create a line.
		Real parameters used.
		A line from (x,y) to (u,v) is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param x x coordinate of start point.
		@param y y coordinate of start point.
		@param u x coordinate of end point.
		@param v y coordinate of end point.
	*/
	public Linje(double x, double y, double u, double v)
	{	Xr0=x; Yr0=y; Xr1=u; Yr1=v;
		X0=(int)Xr0; Y0=(int)Yr0; X1=(int)Xr1; Y1=(int)Yr1;
	}
	/** Create a line.
		Real parameters used.
		A line from p0 to p1 is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param p0 Start point.
		@param p1 End point
	*/
	public Linje(Punkt p0, Punkt p1)
	{	Xr0=p0.GetX(); Yr0=p0.GetY(); Xr1=p1.GetX(); Yr1=p1.GetY();
		X0=(int)Xr0; Y0=(int)Yr0; X1=(int)Xr1; Y1=(int)Yr1;
	}
	/** Create a line.
		Real parameters used.
		A line from p0 in direction d with length l is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param p0 Start point.
		@param l The length of the line.
		@param d The direction (from p0) of the line.
	*/
	public Linje(Punkt p0, double l, double d)
	{	Xr0=p0.GetX(); Yr0=p0.GetY();
		Xr1=Xr0+l*Math.cos(d); Yr1=Yr0+l*Math.sin(d);
		X0=(int)Xr0; Y0=(int)Yr0; X1=(int)Xr1; Y1=(int)Yr1;
	}
	/* **********************************************
	*		Drawing in a window
	********************************************** */
	/** Draw the line.
		@param W The window to draw the line in.
	*/
	public void Draw(w W) {W.DrawLine(X0,Y0,X1,Y1);}
	/** Erase the line.
		@param W The window the line is drawn in.
	*/
	public void Erase(w W) {W.EraseLine(X0,Y0,X1,Y1);}
	/** Draw the line "area".
		The line has no area and is just drawn (same as Draw).
		@param W The window to draw the line in.
	*/
	public void Fill(w W) {W.DrawLine(X0,Y0,X1,Y1);}
	/** Draw the line "area".
		The line has no area and is just drawn , but with
		another colour (similar to Draw but another pen).
		@param W The window to draw the line in.
		@param C The colour of the pen to draw the line with.
	*/
	public void Fill(w W, Color C)
	{	Color Old;
		Old=W.GetPen();
		W.SetPen(C);
		W.DrawLine(X0,Y0,X1,Y1);
		W.SetPen(Old);
	}
	/** Erase the line "area".
		A line has no area and this does the same as Erase.
		@param W The window the line is drawn in.
	*/
	public void EraseFilled(w W) {W.EraseLine(X0,Y0,X1,Y1);}
	/** Topographic check.
		Using integer coordinates.
		Check if a point lies within the line area.
		A line is to this to have something within it.
		@param x0 x coordinate of point.
		@param y0 y coordinate of point.
		@return false always.
	*/
	public boolean Within(int x0,int y0)
	{return false;}
	/** Topographic check.
		Using real coordinates.
		Check if a point lies within the line area.
		A line is to this to have something within it.
		@param x0 x coordinate of point.
		@param y0 y coordinate of point.
		@return false always.
	*/
	public boolean Within(double x0,double y0)
	{return false;}
	/** Figure rotation.
		Rotate the figur around a given point a given angle.
		A new line is created, the old is still the same as before.
		@param p0 Centre of rotation.
		@param phi The angle of rotation.
		@return The result of rotation as a new line.
	*/
	public Figur Rotate(Punkt p0,double phi)
	{	Punkt P0,P1;
		P0=Vrid(p0,new Punkt(Xr0,Yr0),phi);
		P1=Vrid(p0,new Punkt(Xr1,Yr1),phi);
		return (Figur)new Linje(P0,P1);
	}
	/** Figure rotation.
		Rotate the figur around the start point a given angle.
		A new line is created, the old is still the same as before.
		@param phi The angle of rotation.
		@return The result of rotation as a new line.
	*/
	public Figur Rotate(double phi)
	{	Punkt P0,P1;
		P0=new Punkt(Xr0,Yr0);
		P1=Vrid(P0,new Punkt(Xr1,Yr1),phi);
		return (Figur)new Linje(P0,P1);
	}
	/** Figure translation.
		A copy of the line is just moved. 
		@param dx The move in x direction.
		@param dy The move in y direction.
		@return The resulting new line.
	*/
	public Figur Translate(int dx,int dy)
	{return (Figur)new Linje(Xr0+dx,Yr0+dy,Xr1+dx,Yr1+dy);}
	/** Figure scaling.
		A new line with a different size is created.
		@param faktor The scaling factor.
		@return The new line.
	*/
	public Figur Scale(double faktor)
	{	Punkt P0,P1;
		P0=new Punkt(Xr0,Yr0);
		P1=Skala(P0,new Punkt(Xr1,Yr1),faktor);
		return (Figur)new Linje(P0,P1);
	}
	/** Make a polygon.
		A polygon with two corners does not exist.
		@return null always.
	*/
	public Poly MakePoly() {return null;}
	/** Get centre of figure.
		The centre of a line is choosen to be its start point,
		not its mid point.
		The start of the line is returned as a point.
		@return Start of line.
	*/
	public Punkt GetCentre() {return new Punkt(Xr0,Yr0);}
	/** Get start of figure.
		The start of the line is returned as a point.
		For this type it is the same as GetCentre.
		@return Start of line.
	*/
	public Punkt GetStart() {return new Punkt(Xr0,Yr0);}
	/** Get End of figure.
		The end of the line is returned as a point.
		@return End of line.
	*/
	public Punkt GetEnd() {return new Punkt(Xr1,Yr1);}
	/** Get direction.
		@return The direction of the line.
	*/
	public double GetDirection()
	{return Math.PI/2.0-Math.atan2(Xr1-Xr0,Yr1-Yr0);}
	/** Get length.
		@return The length of the line.
	*/
	public double GetLength()
	{return Math.sqrt((Xr1-Xr0)*(Xr1-Xr0)+(Yr1-Yr0)*(Yr1-Yr0));}
}
