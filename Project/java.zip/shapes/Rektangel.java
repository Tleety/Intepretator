package shapes;
/*
 !***************************************************************
 !		Revision history
 !	0.1	980601 
 ! 1.0	980825
 !
 !***************************************************************
*/
import java.awt.*;
import window.*;
/** Implements the type for rectangles.
	A rectangle of this type (Rektangel) is always aligned with
	the normal coordinate axes. If you want to place a rectangle
	in any other way you have to use a polygon with four corners
	instead.
	@author G�ran Fries
	@version 1.0
*/
public class Rektangel extends Figur
{	private Rectangle R;
	private double Xr,Yr,Hr,Br;
	private int X,Y,H,B;
	/* **********************************************
	*		Constructors
	********************************************** */
	/** Create a rectangle.
		Integer parameters used.
		A rectangle with corners at (x1,y1) and (x2,y2) is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param x1 x coordinate of left top corner.
		@param y1 y coordinate of left top corner.
		@param x2 x coordinate of right bottom corner.
		@param y2 y coordinate of right bottom corner.
	*/
	public Rektangel(int x1,int y1,int x2,int y2)
	{	X=x1; Y=y1;
		B=x2-x1; H=y2-y1;
		Xr=X; Yr=Y; Hr=H; Br=B;
		R=new Rectangle(X,Y,B,H);
	}
	/** Create a rectangle.
		Real parameters used.
		A rectangle with corners at (x1,y1) and (x2,y2) is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param x1 x coordinate of left top corner.
		@param y1 y coordinate of left top corner.
		@param x2 x coordinate of right bottom corner.
		@param y2 y coordinate of right bottom corner.
	*/
	public Rektangel(double x1,double y1,double x2,double y2)
	{	Xr=x1; Yr=y1;
		Br=x2-x1; Hr=y2-y1;
		X=(int)Xr; Y=(int)Yr; H=(int)Hr; B=(int)Br;
		R=new Rectangle(X,Y,B,H);
	}
	/** Create a rectangle.
		A rectangle parameters used.
		A rectangle of type Rektangel is created from a Rectangle.
		The awt type Rectangle is a bit different from the type
		defined here in our Figur hierarchy, with other methods.
		Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param Rect an awt type rectangle
	*/
	public Rektangel(Rectangle Rect)
	{R=new Rectangle(Rect);}
	/* **********************************************
	*		Drawing in a window
	********************************************** */
	/** Draw the rectangle.
		@param W The window to draw the rectangle in.
	*/
	public void Draw(w W) {W.DrawRectangle(X,Y,X+B,Y+H);}
	/** Erase the rectangle.
		@param W The window the rectangle is drawn in.
	*/
	public void Erase(w W) {W.EraseRectangle(X,Y,X+B,Y+H);}
	/** Draw the rectangle area.
		The rectangle area is filled with the "filler" colour of
		the window.
		@param W The window to draw the rectangle area in.
	*/
	public void Fill(w W) {W.FillRectangle(X,Y,X+B,Y+H);}
	/** Draw the rectangle area.
		The rectangle area is filled with the given colour.
		@param W The window to draw the rectangle area in.
		@param C The colour to fill the rectangle with.
	*/
	public void Fill(w W, Color C)
	{	Color Old;
		Old=W.GetFiller();
		W.SetFiller(C);
		W.FillRectangle(X,Y,X+B,Y+H);
		W.SetFiller(Old);
	}
	/** Erase the rectangle area.
		@param W The window the rectangle area is drawn in.
	*/
	public void EraseFilled(w W) {W.EraseFilledRectangle(X,Y,X+B,Y+H);}
	/** Topographic check.
		Using integer coordinates.
		Check if a point lies within the rectangle or rectangle area.
		@param x x coordinate of point.
		@param y y coordinate of point.
		@return true if (x,y) is within the rectangle.
	*/
	public boolean Within(int x,int y)
	{return R.contains(x,y);}
	/** Topographic check.
		Using real coordinates.
		Check if a point lies within the rectangle or rectangle area.
		@param x x coordinate of point.
		@param y y coordinate of point.
		@return true if (x,y) is within the rectangle.
	*/
	public boolean Within(double x,double y)
	{return R.contains((int)x,(int)y);}
	/** Topographic check.
		Are the two rectangles in contact with each other?
		They are in contact if they have some point in common.
		@param Q The other rectangle.
		@return true if in contact, else false.
	*/
	public boolean InContact(Rektangel Q)
	{return R.intersects(Q.R);}
	/* **********************************************
	*		Figure transformations
	********************************************** */
	/** Figure rotation.
		Rotate the figur around a given point a given angle.
		A new polygon is created, the old is still the same as before.
		Notice that a rotated rectangle is mostly not aligned any more,
		and has to be changed to a polygon.
		@param p0 Centre of rotation.
		@param phi The angle of rotation.
		@return The result of rotation as a new polygon.
	*/
	public Figur Rotate(Punkt p0,double phi)
	{	Punkt[] P;
		P=new Punkt[4];
		P[0]=Vrid(p0,new Punkt(Xr,Yr),phi);
		P[1]=Vrid(p0,new Punkt(Xr+Br,Yr),phi);
		P[2]=Vrid(p0,new Punkt(Xr+Br,Yr+Hr),phi);
		P[3]=Vrid(p0,new Punkt(Xr,Yr+Hr),phi);
		return (Figur)new Poly(P);
	}
	/** Figure rotation.
		Rotate the figur around the centre a given angle.
		A new polygon is created, the old is still the same as before.
		Notice that a rotated rectangle is mostly not aligned any more,
		and has to be changed to a polygon.
		@param phi The angle of rotation.
		@return The result of rotation as a new polygon.
	*/
	public Figur Rotate(double phi)
	{	Punkt[] P;
		P=new Punkt[4];
		Punkt p0=GetCentre();
		P[0]=Vrid(p0,new Punkt(Xr,Yr),phi);
		P[1]=Vrid(p0,new Punkt(Xr+Br,Yr),phi);
		P[2]=Vrid(p0,new Punkt(Xr+Br,Yr+Hr),phi);
		P[3]=Vrid(p0,new Punkt(Xr,Yr+Hr),phi);
		return (Figur)new Poly(P);
	}
	/** Figure translation.
		A copy of the rectangle is just moved. 
		@param dx The move in x direction.
		@param dy The move in y direction.
		@return The resulting new rectangle.
	*/
	public Figur Translate(int dx,int dy)
	{return (Figur)new Rektangel(Xr+dx,Yr+dy,Xr+Br+dx,Yr+Hr+dy);}
	/** Figure scaling.
		A new rectangle with a different size is created.
		@param faktor The scaling factor.
		@return The new rectangle.
	*/
	public Figur Scale(double faktor)
	{return (Figur)new Rektangel((Xr+Br*(1-faktor)*2),
										  (Yr+Hr*(1-faktor)*2),
										  (Xr+Br*(1+faktor)*2),
										  (Yr+Hr*(1+faktor)*2));
	}
	/** Make a polygon.
		A new polygon is created, with the same four corners as
		the original rectangle.
		@return The new four corner polygon.
	*/
	public Poly MakePoly()
	{	Punkt[] P=new Punkt[4];
		P[0]=new Punkt(Xr,Yr);
		P[1]=new Punkt(Xr+Br,Yr);
		P[2]=new Punkt(Xr+Br,Yr+Hr);
		P[3]=new Punkt(Xr,Yr+Hr);
		return new Poly(P);
	}
	/** Get centre of figure.
		The centre of the rectangle is returned as a point.
		@return Centre of rectangle.
	*/
	public Punkt GetCentre()
	{return new Punkt(Xr+Br/2,Yr+Hr/2);}
}
