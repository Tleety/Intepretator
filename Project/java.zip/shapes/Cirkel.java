package shapes;
/* 
 !***************************************************************
 !		Revision history
 !	0.1	980601 
 ! 1.0	980825
 !
 !***************************************************************
*/
import java.awt.*;
import window.*;
/** Implements the type for circles.
	@author G�ran Fries
	@version 1.0
*/
public class Cirkel extends Figur
{	private double Xr,Yr,Rr;
	private int X,Y,R;
	/* **********************************************
	*		Constructors
	********************************************** */
	/** Create a circle.
		Integer parameters used.
		A circle with centre at (x0,y0) and radius ra is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param x0 x coordinate of centre
		@param y0 y coordinate of centre
		@param ra The radius ofthe circle.
	*/
	public Cirkel(int x0,int y0,int ra)
	{	X=x0; Y=y0; R=ra;
		Xr=X; Yr=Y; Rr=R;
	}
	/** Create a circle.
		Real parameters used.
		A circle with centre at (x0,y0) and radius ra is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param x0 x coordinate of centre
		@param y0 y coordinate of centre
		@param ra The radius ofthe circle.
	*/
	public Cirkel(double x0,double y0,double ra)
	{	Xr=x0; Yr=y0; Rr=ra;
		X=(int)Xr; Y=(int)Yr; R=(int)Rr;
	}
	/** Create a circle.
		Centre given as a point.
		A circle with centre at p and radius ra is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param p The point defining the centre of the circle.
		@param ra The radius ofthe circle.
	*/
	public Cirkel(Punkt p, double ra)
	{	Xr=p.GetX(); Yr=p.GetY(); Rr=ra;
		X=(int)Xr; Y=(int)Yr; R=(int)Rr;
	}
	/* **********************************************
	*		Drawing in a window
	********************************************** */
	/** Draw the circle.
		@param W The window to draw the circle in.
	*/
	public void Draw(w W) {W.DrawCircle(X,Y,R);}
	/** Erase the circle.
		@param W The window the circle is drawn in.
	*/
	public void Erase(w W) {W.EraseCircle(X,Y,R);}
	/** Draw the circle area.
		The circle area is filled with the "filler" colour of
		the window.
		@param W The window to draw the circle area in.
	*/
	public void Fill(w W) {W.FillCircle(X,Y,R);}
	/** Draw the circle area.
		The circle area is filled with the given colour.
		@param W The window to draw the circle area in.
		@param C The colour to fill the circle with.
	*/
	public void Fill(w W, Color C)
	{	Color Old;
		Old=W.GetFiller();
		W.SetFiller(C);
		W.FillCircle(X,Y,R);
		W.SetFiller(Old);
	}
	/** Erase the circle area.
		@param W The window the circle area is drawn in.
	*/
	public void EraseFilled(w W) {W.EraseFilledCircle(X,Y,R);}
	/** Topographic check.
		Using integer coordinates.
		Check if a point lies within the circle or circle area.
		@param x0 x coordinate of point.
		@param y0 y coordinate of point.
		@return true if (x0,y0) is within the circle.
	*/
	public boolean Within(int x0,int y0)
	{return (X-x0)*(X-x0)+(Y-y0)*(Y-y0)<R*R;}
	/** Topographic check.
		Using real coordinates.
		Check if a point lies within the circle or circle area.
		@param x0 x coordinate of point.
		@param y0 y coordinate of point.
		@return true if (x0,y0) is within the circle.
	*/
	public boolean Within(double x0,double y0)
	{return (Xr-x0)*(Xr-x0)+(Yr-y0)*(Yr-y0)<Rr*Rr;}
	/** Topographic check.
		Using a point as parameter.
		Check if a point lies within the circle or circle area.
		@param p The point.
		@return true if p is within the circle.
	*/
	public boolean Within(Punkt p)
	{return (Xr-p.GetX())*(Xr-p.GetX())+(Yr-p.GetY())*(Yr-p.GetY())<Rr*Rr;}
	/** Figure rotation.
		Rotate the figur around a given point a given angle.
		A new circle is created, the old is still the same as before.
		@param p0 Centre of rotation.
		@param phi The angle of rotation.
		@return The result of rotation as a new circle.
	*/
	public Figur Rotate(Punkt p0,double phi)
	{	Punkt P;
		P=Vrid(p0,new Punkt(Xr,Yr),phi);
		return (Figur)new Cirkel(P,Rr);
	}
	/** Figure rotation.
		Rotate the figur around the centre a given angle.
		A new circle is created, the old is still the same as before.
		A rotation around the centre of a circle will of course
		result in a copy of the old one.
		@param phi The angle of rotation.
		@return The result of rotation as a new circle.
	*/
	public Figur Rotate(double phi)
	{	Punkt P;
		P=new Punkt(Xr,Yr);
		return (Figur)new Cirkel(P,Rr);
	}
	/** Figure translation.
		A copy of the circle is just moved. 
		@param dx The move in x direction.
		@param dy The move in y direction.
		@return The resulting new circle.
	*/
	public Figur Translate(int dx,int dy)
	{return (Figur)new Cirkel(Xr+dx,Yr+dy,Rr);}
	/** Figure scaling.
		A new circle with a different size is created.
		@param faktor The scaling factor.
		@return The new circle.
	*/
	public Figur Scale(double faktor)
	{	return (Figur)new Cirkel(Xr,Yr,(Rr*faktor));}
	/** Make a polygon.
		The circle is approximated by a polygon of 120 corners.
		@return A new polygon, approximating the circle.
	*/
	public Poly MakePoly()
	{	Punkt[] P=new Punkt[120];
		double z=0.0;
		for (int i=0; i<120; i=i+1)
		{	P[i]=new Punkt((Rr*Math.sin(z))+Xr,(Rr*Math.cos(z))+Yr);
			z=z+Math.PI/60.0;
		}
		return new Poly(P);
	}
	/** Get centre of figure.
		The centre of the circle is returned as a point.
		@return Centre of circle.
	*/
	public Punkt GetCentre() {return new Punkt(Xr,Yr);}
}
