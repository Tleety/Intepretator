package shapes;
/*
 !***************************************************************
 !		Revision history
 !	0.1	980601 
 ! 1.0	980825
 !
 !***************************************************************
*/
import java.awt.*;
import window.*;
/** Implements the type for polygones.
	@author G�ran Fries
	@version 1.0
*/
public class Poly extends Figur
{	private Polygon P;
	int NofPoints;
	double[]Xr,Yr;
	int[]X,Y;
	/* **********************************************
	*		Constructors
	********************************************** */
	/** Create a polygon.
		Integer parameters used.
		A polygon with corners in points created from x, y is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param x The x coordinates of the corners (x0,x1,....)
		@param y The y coordinates of the corners (y0,y1,....)
	*/
	public Poly(int[] x, int[] y)
	{	NofPoints=x.length;
		Xr=new double[NofPoints];
		Yr=new double[NofPoints];
		X=new int[NofPoints];
		Y=new int[NofPoints];
		if (y.length<NofPoints) NofPoints=y.length;
		for (int i=0; i<NofPoints; i=i+1)
		{X[i]=x[i]; Y[i]=y[i]; Xr[i]=X[i]; Yr[i]=Y[i];}
		P=new Polygon(X,Y,NofPoints);
	}
	/** Create a polygon.
		Real parameters used.
		A polygon with corners in points created from x, y is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param x The x coordinates of the corners (x0,x1,....)
		@param y The y coordinates of the corners (y0,y1,....)
	*/
	public Poly(double[] x, double[] y)
	{	NofPoints=x.length;
		Xr=new double[NofPoints];
		Yr=new double[NofPoints];
		X=new int[NofPoints];
		Y=new int[NofPoints];
		if (y.length<NofPoints) NofPoints=y.length;
		for (int i=0; i<NofPoints; i=i+1)
		{Xr[i]=x[i]; Yr[i]=y[i]; X[i]=(int)Xr[i]; Y[i]=(int)Yr[i];}
		P=new Polygon(X,Y,NofPoints);
	}
	/** Create a polygon.
		Point parameters used.
		A polygon with corners in the points in Q is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param Q The corners (Q0,Q1,...)
	*/
	public Poly(Punkt[] Q)
	{	int n=Q.length;
		Xr=new double[n];
		Yr=new double[n];
		X=new int[n];
		Y=new int[n];
		for(int i=0; i<n; i=i+1)
		{	Xr[i]=Q[i].GetX();
			Yr[i]=Q[i].GetY();
			X[i]=(int)Xr[i]; Y[i]=(int)Yr[i];
		}
		P=new Polygon(X,Y,n);
		NofPoints=n;
	}
	/* **********************************************
	*		Drawing in a window
	********************************************** */
	/** Draw the polygon.
		@param W The window to draw the polygon in.
	*/
	public void Draw(w W) {W.DrawPolygon(X,Y);}
	/** Erase the polygon.
		@param W The window the polygon is drawn in.
	*/
	public void Erase(w W) {W.ErasePolygon(X,Y);}
	/** Draw the polygon area.
		The polygon area is filled with the "filler" colour of
		the window.
		@param W The window to draw the polygon area in.
	*/
	public void Fill(w W) {W.FillPolygon(X,Y);}
	/** Draw the polygon area.
		The polygon area is filled with the given colour.
		@param W The window to draw the polygon area in.
		@param C The colour to fill the polygon with.
	*/
	public void Fill(w W, Color C)
	{	Color Old;
		Old=W.GetFiller();
		W.SetFiller(C);
		W.FillPolygon(X,Y);
		W.SetFiller(Old);
	}
	/** Erase the polygon area.
		@param W The window the polygon area is drawn in.
	*/
	public void EraseFilled(w W) {W.EraseFilledPolygon(X,Y);}
	/** Topographic check.
		Using integer coordinates.
		Check if a point lies within the polygon or polygon area.
		@param x x coordinate of point.
		@param y y coordinate of point.
		@return true if (x,y) is within the polygon.
	*/
	public boolean Within(int x,int y)
	{return P.contains(x,y);}
	/** Topographic check.
		Using real coordinates.
		Check if a point lies within the polygon or polygon area.
		@param x x coordinate of point.
		@param y y coordinate of point.
		@return true if (x,y) is within the polygon.
	*/
	public boolean Within(double x,double y)
	{return P.contains((int)x,(int)y);}
	/** Figure rotation.
		Rotate the figur around a given point a given angle.
		A new polygon is created, the old is still the same as before.
		@param p0 Centre of rotation.
		@param phi The angle of rotation.
		@return The result of rotation as a new polygon.
	*/
	public Figur Rotate(Punkt p0,double phi)
	{	Punkt[] Q=new Punkt[NofPoints];
		for (int i=0; i<NofPoints; i=i+1)
		{	Q[i]=Vrid(p0,new Punkt(Xr[i],Yr[i]),phi);
		}
		return (Figur)new Poly(Q);
	}
	/** Figure rotation.
		Rotate the figur around the centre a given angle.
		A new polygon is created, the old is still the same as before.
		@param phi The angle of rotation.
		@return The result of rotation as a new polygon.
	*/
	public Figur Rotate(double phi)
	{	Punkt[] Q=new Punkt[NofPoints];
		Punkt p0=GetCentre();
		for (int i=0; i<NofPoints; i=i+1)
		{	Q[i]=Vrid(p0,new Punkt(Xr[i],Yr[i]),phi);
		}
		return (Figur)new Poly(Q);
	}
	/** Figure translation.
		A copy of the polygon is just moved. 
		@param dx The move in x direction.
		@param dy The move in y direction.
		@return The resulting new polygon.
	*/
	public Figur Translate(int dx,int dy)
	{	Punkt[] Q=new Punkt[NofPoints];
		for (int i=0; i<NofPoints; i=i+1)
		{	Q[i]=Translatera(new Punkt(Xr[i],Yr[i]),dx,dy);
		}
		return (Figur)new Poly(Q);
	}
	/** Figure scaling.
		A new polygon with a different size is created.
		@param faktor The scaling factor.
		@return The new polygon.
	*/
	public Figur Scale(double faktor)
	{	Punkt[] Q=new Punkt[NofPoints];
		Punkt p0=GetCentre();
		for (int i=0; i<NofPoints; i=i+1)
		{	Q[i]=Skala(p0,new Punkt(Xr[i],Yr[i]),faktor);
		}
		return (Figur)new Poly(Q);
	}
	/** Make polygon.
		@return A copy of this polygon is returned.
	*/
	public Poly MakePoly()
	{return new Poly(Xr,Yr);}
	/** Get centre of figure.
		The centre of the polygon is returned as a point.
		@return Centre of polygon.
	*/
	public Punkt GetCentre()
	{	double XSum=0,YSum=0,n=NofPoints;
		for (int i=0; i<NofPoints; i=i+1)
		{XSum=XSum+Xr[i]; YSum=YSum+Yr[i];}
		return new Punkt(XSum/NofPoints,YSum/NofPoints);
	}
	/* **********************************************
	*		Getting the shape in coordinates
	********************************************** */
	/** Get the corners.
		The corners is returned as a point sequence, 
		in form of a point array.
		@return The sequence of corners.
	*/
	public Punkt[] GetCorners()
	{	Punkt[] Ps=new Punkt[NofPoints];
		for (int i=0; i<NofPoints; i=i+1)
		{Ps[i]=new Punkt(Xr[i],Yr[i]);}
		return Ps;
	}
}
