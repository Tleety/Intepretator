package shapes;
/*
 !***************************************************************
 !		Revision history
 !	0.1	980601 
 ! 1.0	980825
 !
 !***************************************************************
*/
import window.*;
/** Implements the type for points.
	@author G�ran Fries
	@version 1.0
*/
public class Punkt
{	private double Xr,Yr;
	private int X,Y;
	/** Create a point.
		Integer coordinates.
		@param x0 The x coordinate of the point.
		@param y0 The y coordinate of the point.
	*/
	public Punkt(int x0,int y0) {X=x0; Y=y0; Xr=X; Yr=Y;}
	/** Create a point.
		Real coordinates.
		@param x0 The x coordinate of the point.
		@param y0 The y coordinate of the point.
	*/
	public Punkt(double x0,double y0)
	{Xr=x0; Yr=y0; X=(int)Xr; Y=(int)Yr;}
	/** Get x coordinate.
		@return The x coordinate.
	*/
	public double GetX() {return Xr;}
	/** Get y coordinate.
		@return The y coordinate.
	*/
	public double GetY() {return Yr;}
	/** Get the distance.
		The distance to the given point will be returned.
		@return Distance.
	*/
	public double Dist(Punkt p)
	{	double u,v;
		u=p.GetX();
		v=p.GetY();
		return Math.sqrt((X-u)*(X-u)+(Y-v)*(Y-v));
	}
	/** Move the point.
		The point is moved by a "vector quantity.
		@param V The vector.
	*/
	public void Translatera(Vektor V)
	{Xr=Xr+V.XComponent(); Yr=Yr+V.YComponent(); X=(int)Xr; Y=(int)Yr;}
	/*
	public void Translatera(Punkt V)
	{Xr=Xr+V.GetX(); Yr=Yr+V.GetY(); X=(int)Xr; Y=(int)Yr;}
	*/
	/** Draw the point.
		As a point has no size in any direction it is in some sens
		impossible to draw. But in order to "see" the point it is marked
		(drawn) as a small cross.
		@param W The window to draw the point in.
	*/
	public void Draw(w W)
	{W.DrawLine(X-1,Y-1,X+1,Y+1); W.DrawLine(X-1,Y+1,X+1,Y-1);}
	/** ***TEST*** */
	public void Write()
	{System.out.println("X="+Xr+"Y="+Yr);}
}
