package shapes;
/*
 !***************************************************************
 !		Revision history
 !	0.1	980601 
 ! 1.0	980825
 !
 !***************************************************************
*/
import java.awt.*;
import window.*;
/** Implements the type for arrows.
	They are just like lines but are drawn like arrows.
	@author G�ran Fries
	@version 1.0
*/
public class Pil extends Linje
{	private double alpha,spets;
	private double fi;
	final static double pi=Math.PI;
	/* **********************************************
	*		Constructors
	********************************************** */
	/** Create an arrow.
		Real parameters used.
		An arrow from (x,y) to (u,v) is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param x x coordinate of start point.
		@param y y coordinate of start point.
		@param u x coordinate of end point.
		@param v y coordinate of end point.
	*/
	public Pil(double x, double y, double u, double v)
	{	super(x,y,u,v);
		alpha=pi/6.0;
		spets=6.0;
		fi=pi/2.0-Math.atan2(Xr1-Xr0,Yr1-Yr0);
	}
	/** Create an arrow.
		Real parameters used.
		An arrow from p0 to p1 is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param p0 Start point.
		@param p1 End point
	*/
	public Pil(Punkt p0, Punkt p1)
	{	super(p0,p1);
		alpha=pi/6.0;
		spets=6.0;
		fi=pi/2.0-Math.atan2(Xr1-Xr0,Yr1-Yr0);
	}
	/** Create an arrow.
		Real parameters used.
		An arrow from p0 in direction d with length l is
		created. Notice that it will not be put on the screen
		until it is drawn by the draw method.
		@param p0 Start point.
		@param l The length of the arrow.
		@param d The direction (from p0) of the arrow.
	*/
	public Pil(Punkt p0, double l, double d)
	{	super(p0,l,d);
		alpha=pi/6.0;
		spets=6.0;
		fi=d;
	}
	/* **********************************************
	*		Drawing in a window
	********************************************** */
	/** Draw the arrow.
		This is drawn as a line with a sharp arrowhead.
		@param W The window to draw the arrow in.
	*/
	public void Draw(w W)
	{	W.DrawLine(X0,Y0,X1,Y1);
		if (alpha!=0.0)
		{	int x1,y1,x2,y2;
			x1=(int)(X1+spets*Math.cos(fi-pi-alpha));
			y1=(int)(Y1+spets*Math.sin(fi-pi-alpha));
			W.DrawLine(X1,Y1,x1,y1);
			x2=(int)(X1+spets*Math.cos(fi-pi+alpha));
			y2=(int)(Y1+spets*Math.sin(fi-pi+alpha));
			W.DrawLine(X1,Y1,x2,y2);
		}
	}
	/** Erase the arrow.
		@param W The window the arrow is drawn in.
	*/
	public void Erase(w W)
	{	W.EraseLine(X0,Y0,X1,Y1);
		if (alpha!=0.0)
		{	int x1,y1,x2,y2;
			x1=(int)(X1+spets*Math.cos(fi-pi-alpha));
			y1=(int)(Y1+spets*Math.sin(fi-pi-alpha));
			W.EraseLine(X1,Y1,x1,y1);
			x2=(int)(X1+spets*Math.cos(fi-pi+alpha));
			y2=(int)(Y1+spets*Math.sin(fi-pi+alpha));
			W.EraseLine(X1,Y1,x2,y2);
		}
	}
	/** Draw the arrow "area".
		The arrow has no area and is just drawn (same as Draw).
		@param W The window to draw the arrow in.
	*/
	public void Fill(w W) {Draw(W);}
	/** Draw the arrow "area".
		The arrow has no area and is just drawn , but with
		another colour (similar to Draw but another pen).
		@param W The window to draw the arrow in.
		@param C The colour of the pen to draw the arrow with.
	*/
	public void Fill(w W, Color C)
	{	Color Old;
		Old=W.GetPen();
		W.SetPen(C);
		Draw(W);
		W.SetPen(Old);
	}
	/** Erase the arrow "area".
		A arrow has no area and this does the same as Erase.
		@param W The window the arrow is drawn in.
	*/
	public void EraseFilled(w W) {Erase(W);}
	/* **********************************************
	*		Figure transformations
	********************************************** */
	/** Figure rotation.
		Rotate the figur around a given point a given angle.
		A new arrow is created, the old is still the same as before.
		@param p0 Centre of rotation.
		@param phi The angle of rotation.
		@return The result of rotation as a new arrow.
	*/
	public Figur Rotate(Punkt p0,double phi)
	{	Punkt P0,P1;
		P0=Vrid(p0,new Punkt(Xr0,Yr0),phi);
		P1=Vrid(p0,new Punkt(Xr1,Yr1),phi);
		return (Figur)new Pil(P0,P1);
	}
	/** Figure rotation.
		Rotate the figur around the start point a given angle.
		A new arrow is created, the old is still the same as before.
		@param phi The angle of rotation.
		@return The result of rotation as a new arrow.
	*/
	public Figur Rotate(double phi)
	{	Punkt P0,P1;
		P0=new Punkt(Xr0,Yr0);
		P1=Vrid(P0,new Punkt(Xr1,Yr1),phi);
		return (Figur)new Pil(P0,P1);
	}
	/** Figure translation.
		A copy of the arrow is just moved. 
		@param dx The move in x direction.
		@param dy The move in y direction.
		@return The resulting new arrow.
	*/
	public Figur Translate(int dx,int dy)
	{return (Figur)new Pil(Xr0+dx,Yr0+dy,Xr1+dx,Yr1+dy);}
	/** Figure scaling.
		A new arrow with a different size is created.
		@param faktor The scaling factor.
		@return The new arrow.
	*/
	public Figur Scale(double faktor)
	{	Punkt P0,P1;
		P0=new Punkt(Xr0,Yr0);
		P1=Skala(P0,new Punkt(Xr1,Yr1),faktor);
		return (Figur)new Pil(P0,P1);
	}
}
