package file;
/*
 !***************************************************************
 !		Revision history
 !	0.1	971001 
 ! 1.0	980825
 !
 !***************************************************************
*/
import java.io.*;
/* *************************************************************************
*		*** outbytefile ***
*
*	outbytefile is a sequential file of bytes.
*
*	outbytefile has one constructor:
*		new outbytefile("filename")	will open a named "normal" file for output
*	Methods:
*		Open()-->boolean		file has to be opened before used
*									false will be returned on error else true
*		Close()					file should be closed when not used anymore
*									last image written if not empty
*		Write(int I)			output integer as four bytes
*		Write(float R)			similar as writeint, but the real R is written.
*		Write(String)			similar, but the string is transfered. Notice that
*									the string is written in exactly the number of
*									bytes that are necessary (not four byte units).
*		Write(int[] V)			output vector V as a number of int:s (V.length)
*
*		Check()-->boolean		return false if last operation failed, else true
*		GetError()-->String	return an error text. The following errors exists:
*									"failed" - open or closed failed
*									"closed" - operation attempted on a closed file
*									"writeerror" - error during output
*									"OK"     - geterror called when no pending error
* OpenE, CloseE, WriteE does the same as
* those without E, but throws an FileException when error.
************************************************************************* */
/** An outbytefile object is used to represent an output byte file.
	A bytefile is a sequence of bytes with no interpretation of
	newlines, linefeed or other formatting characters. When output of
	a number (say integer) is made to a textfile the number is converted
	to its text representation and this is written. In a bytefile the 
	transfered data is just the bitrepresentation of the number and no
	conversion is made. Byte files are used to represent bitpatterns just
	as they are. A bytefile is connected to a named file in the file system.
	There are two different types of error handling. There is
	an error flag and text in the outbytefile object that will be set.
	This may be checked by methods. Another way of handling errors
	is that in addition to the above an exception may be thrown.
	@author G�ran Fries
	@version 1.0
*/
public class outbytefile
{	private ByteOutput Fil;
	private String Filename,ERR;
	boolean Opened;
	/**  constructor
		A connection to a file with the given name is created.
		@param FN Name of the file.
	*/
	public outbytefile(String FN) {Filename=FN; Fil=new ByteOutput(Filename);}
	
	/* **** Methods not throwing any Exceptions **** */
	/** Open. A file has to be opened befor it is used.
		If the file could not be opened an error will be registered.
		@return true if successfull else false.
	*/
	public boolean Open()
	{	Opened=Fil.open();
		if (Opened) {ERR=""; return true;}
		else{ERR="failed"; return false;}
	}
	/** Write integer.
		An integer (four bytes) is written to the buffer and position is advanced.
		@param I The integer to write.
	*/
	public void Write(int I)
	{	if (Opened) {Fil.Put(I); if (Fil.check()) ERR="writeerror"; else ERR="";}
		else ERR="closed";
	}
	/** Write real.
		A real (four bytes) is written to the buffer and position is advanced.
		@param X The real (float) to write.
	*/
	public void Write(float X)
	{	if (Opened) {Fil.Put(X); if (Fil.check()) ERR="writeerror"; else ERR="";}
		else ERR="closed";
	}
	/** Write text.
		A text (n bytes) is written to the buffer and position is advanced.
		The number (n) of bytes to write is the text length.
		@param S The text (String) to write.
	*/
	public void Write(String S)
	{	if (Opened) {Fil.Put(S); if (Fil.check()) ERR="writeerror"; else ERR="";}
		else ERR="closed";
	}
	/** Write integer array.
		An integer array (n*4 bytes) is written to the buffer 
		and position is advanced. n is the length of the array.
		@param V The integer array to write.
	*/
	public void Write(int [] V)
	{	if (Opened)
			{	for (int I=0; I<V.length; I=I+1) Fil.Put(V[I]);
				if (Fil.check()) ERR="writeerror"; else ERR="";
			}
		else ERR="closed";
	}
	/** Write byte.
		A byte is written to the buffer and position is advanced.
		@param I The byte to write.
	*/
	public void Write(byte I)
	{	if (Opened) {Fil.Put(I); if (Fil.check()) ERR="writeerror"; else ERR="";}
		else ERR="closed";
	}
	/** Write byte array.
		A byte array is written to the buffer and position is advanced.
		@param I The byte array to write.
	*/
	public void Write(byte[] I)
	{	if (Opened) {Fil.Put(I); if (Fil.check()) ERR="writeerror"; else ERR="";}
		else ERR="closed";
	}
	/** Write byte array.
		A part of a byte array is written to the buffer and position is advanced.
		@param I The byte array to write.
		@param s Start position in byte array to write.
		@param l Number of bytes to write.
	*/
	public void Write(byte[] I,int s,int l)
	{	if (Opened) {Fil.Put(I,s,l); if (Fil.check()) ERR="writeerror"; else ERR="";}
		else ERR="closed";
	}
	/** Close the file.
		The file is closed. All files should be closed before
		terminating the program. 
	*/
	public void Close() {if (Opened) Fil.close(); else ERR="closed";}
	/** Check for error.
		Did the latest method fail?
		@return true if previous method failed else false.
	*/
	public boolean Check() {return ERR.length()==0;}
	/** Get error message.
		Get the error message for latest method, if this did not fail
		an OK message will be returned.
		@return Error message or OK.
	*/
	public String GetError() {if (ERR.length()==0) return "OK"; else return ERR;}
	/* **** Methods throwing Exceptions **** */
	/** Open. A file has to be opened befor it is used.
		If the file could not be opened an error will be registered.
		@return true if successfull else false.
		@throws FileException
	*/
	public boolean OpenE() throws FileException
	{	Opened=Fil.open();
		if (Opened) {ERR=""; return true;}
		else{ERR="failed"; throw new FileException(ERR);}
	}
	/** Write integer.
		An integer (four bytes) is written to the buffer and position is advanced.
		@param I The integer to write.
		@throws FileException
	*/
	public void WriteE(int I) throws FileException
	{	if (Opened) {Fil.Put(I); if (Fil.check()) ERR="writeerror"; else ERR="";}
		else ERR="closed";
		if (ERR.length()>0) throw new FileException(ERR);
	}
	/** Write real.
		A real (four bytes) is written to the buffer and position is advanced.
		@param X The real (float) to write.
		@throws FileException
	*/
	public void WriteE(float X) throws FileException
	{	if (Opened) {Fil.Put(X); if (Fil.check()) ERR="writeerror"; else ERR="";}
		else ERR="closed";
		if (ERR.length()>0) throw new FileException(ERR);
	}
	/** Close the file.
		The file is closed. All files should be closed before
		terminating the program.
		@throws FileException 
	*/
	public void CloseE() throws FileException
	{	if (Opened) Fil.close();
		else {ERR="closed"; throw new FileException(ERR);}
	}
}
/************************* Internal class ************************************/
class ByteOutput
{	private OutputStream UFIL;
	private DataOutputStream FIL;
	private boolean Error;
	
	ByteOutput(String FN)
	{try	{	UFIL=new FileOutputStream(FN);
				FIL=new DataOutputStream(UFIL);
				Error=false;
			}
	 catch (Exception E) {Error=true;}
	}
	
	boolean open() {return !Error;}
	
	void close()
	{try	{FIL.close();}
	 catch (Exception E) {Error=true;}
	}
	
	void Put(int I) 
	{try	{	FIL.writeInt(I);
			}
	 catch (Exception E) {Error=true;}
	}
	void Put(float X) 
	{try	{	FIL.writeFloat(X);
			}
	 catch (Exception E) {Error=true;}
	}
	void Put(String S) 
	{try	{	FIL.writeBytes(S);
			}
	 catch (Exception E) {Error=true;}
	}
	void Put(byte I) 
	{try	{	FIL.write(I);
			}
	 catch (Exception E) {Error=true;}
	}
	void Put(byte[] I) 
	{try	{	FIL.write(I,0,I.length);
			}
	 catch (Exception E) {Error=true;}
	}
	void Put(byte[] I,int s,int l) 
	{try	{	FIL.write(I,s,l);
			}
	 catch (Exception E) {Error=true;}
	}
	
	boolean check() {boolean E=Error; Error=false; return E;}
}
