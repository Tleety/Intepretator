package file;
/*
 !***************************************************************
 !		Revision history
 !	0.1	971001 
 ! 1.0	980825 (Check for blocking)
 !
 !***************************************************************
*/
import java.io.*;
/* *************************************************************************
*		*** infile ***
*
*	infile is a sequential file of line images, that may be either
*	a "normal" file with a filename or standard input (often keyboard)
*	If reading a numeric item when no such available a zero value will
*	be returned, an error flag (nonum) will be raised or en exception thrown
*	This is also true if end-of-file is reached and we continue reading.
*	infile has two constructors:
*		new infile("filename")	will open a named "normal" file for input
*		new infile()				will open standard input (keyboard)
*	Methods:
*		Open()-->boolean		file has to be opened before used
*									false will be returned on error else true
*		Close()					file should be closed when not used anymore
*		InImage()				discard remaining contents of line buffer
*									and get a new one (next line)
*		ReadChar()-->char		read a character and advance line position
*		ReadInt()-->int		read an integer and advance line position
*		ReadReal()-->double	read a real and advance line position
*		ReadText(int)-->String read a text of n characters or stop at
*									end of line. If no more characters get next
*									line. Line position is advanced.
*		Skip(int)				advance line position, if end of line is
*									reached a new image is read and pos=0.
*		GetImage()-->String	return the current line buffer as a text. The
*									line position is ignored and the current image
*									is still the current one.
*		Available()-->boolean true if input is available (without blocking)
*		CharsToRead()-->int	number of available characters without blocking.
*		Endfile()-->boolean	is end of file read?
*		Check()-->boolean		true if last infile operation OK, else false.
*		GetError()-->String	return an error text. The following errors exists:
*									"failed" - open or closed failed
*									"closed" - operation attempted on a closed file
*									"nonum"	- non-numeric item when such expected
*									"readerror" - read error from file
*									"OK"     - geterror called when no pending error
*									those, except OK, also as FileException texts.
*	OpenE, CloseE, InImageE, ReadCharE, ReadIntE, ReadRealE, ReadTextE
*	have the same meaning and value as those without E, but a FileException
*	may be thrown!
************************************************************************* */

/** An infile object is used to represent an input text file.
	A file may be an "ordinary" file with a file name or it may be
	the standard input. Except file name and creation there are
	no differencies in using standard input or another file.
	There are two different types of error handling. There is
	an error flag and text in the infile object that will be set.
	This may be checked by methods. Another way of handling errors
	is that in addition to the above an exception may be thrown.
	A file object has a buffer for the input (A string buffer called
	image). This image will be filled when necessary, and units like
	characters, numbers or texts may be read from this image. There are
	also some methods directly manipulating the image. As an infile
	is a sequential text file the image represents a line of text.
	@author G�ran Fries
	@version 1.0
*/
public class infile
{	private String FileName;
	private StringBuffer image;
	int pos;
	private boolean EOF,Opened;
	private String ERR;
	private Input Fil;
	
	/* **** constructors **** */
	/** Create with file name.
		This will create an infile object connected to a named file.
		@param FN The name of the file.
	*/
	public infile(String FN)
	{	FileName=FN; Fil=new Input(FN); ERR="";}
	/** Create with standard input.
		This will create an infile object connected to standard input.
	*/
	public infile()
	{	FileName=""; Fil=new Input(); ERR="";}
	
	
	/* **** Methods without Exception **** */
	/** Fill the image with the next text line.
		The old contents of the image is no longer available, and the
		position is set at the start of the image.
	*/
	public void InImage() {if (Opened) fillimage(); else ERR="closed";}
	/** Get an integer.
		Reads an integer from the current position. The position pointer 
		will be advanced over the integer. An integer may not be divided
		by a new line. The changeing to next line (a new image) will be
		made when necessary. If the text from current position could not
		be regarded as an integer an error will be reported and 0 will be
		returned.
		@return An integer from input (0 if no integer).
	*/
	public int ReadInt()
	{if (Opened) return Rint(); else {ERR="closed";return 0;}}
	/** Get a real.
		Reads a real number from the current position. The position pointer 
		will be advanced over the number. An number may not be divided
		by a new line. The changeing to next line (a new image) will be
		made when necessary. If the text from current position could not
		be regarded as a number an error will be reported and 0 will be
		returned.
		@return A real from input (0.0 if no number).
	*/
	public double ReadReal()
	{if (Opened) return Rreal(); else {ERR="closed";return 0;}}
	/** Get a text.
		A text string of n characters from current position is 
		returned. If end of image (line) is found before n characters a
		shorter text will be returned. Current position is updated, and
		new image fetched when necessary.
		@param n The length of the text string to read.
		@return A text string of at most n characters.
	*/
	public String ReadText(int n)
	{if (Opened) return Rtext(n); else {ERR="closed";return "";}}
	/** Get a character.
		Read the character at current position and update current
		position.
	*/
	public char ReadChar()
	{if (Opened) return Rchar(); else {ERR="closed";return '\00';}}
	/** Get the image.
		The image will be returned as a text string. Current position
		is not used or updated. The image is not changed in any way.
		@return The image as a string text.
	*/
	public String GetImage()
	{if (Opened) return image.toString(); else {ERR="closed"; return "";}}
	/** Advance current position.
		The current position is advanced n steps. The position will never
		pass the end of image and a negative (n<0) skip will not be
		performed.
		@param n Number of characters in buffer to skip.
	*/
	public void Skip(int n)
	{	if (Opened)
			{if (n>0) pos=pos+n; if (pos>=image.length()) pos=image.length(); }
		else ERR="closed";
	}
	/** Test for end of file.
		@return true if end of file reached, false otherwise.
	*/
	public boolean Endfile()
	{if (Opened) return EOF; else {ERR="closed"; return true;}}
	/** Check for error.
		Did the latest method fail?
		@return true if previous method failed else false.
	*/
	public boolean Check() {return ERR.length()==0;}
	/** Get error message.
		Get the error message for latest method, if this did not fail
		an OK message will be returned.
		@return Error message or OK.
	*/
	public String GetError()
	{if (ERR.length()==0) return "OK"; else return ERR;}
	/** Open the file.
		A file has to be opened before it is used. If the file 
		could not be opened an error will be registered.
		@return true if successfull else false.
	*/
	public boolean Open()
	{	Opened=Fil.Open();
		if (Opened) {EOF=false; image=new StringBuffer(); pos=0; return true;}
		else {ERR="failed"; return false;}
	}
	/** Close the file.
		The file is closed. All files should be closed before
		terminating the program.
	*/
	public void Close()
	{	boolean B;
		B=true;
		if (Opened) {Opened=false;B=Fil.close();} else ERR="closed";
		if (B) {} else ERR="failed";
	}
	/** Possible to read?
		Used to test if it is possible to read from the file
		without blocking. Some systems will block the whole
		program if one java process will block.
		@return true if input available whithout blocking, otherwise false.
	*/
	public boolean Available()
	{	if (Opened) return Fil.Available();
		else return false;
	}
	/** Available characters.
		Used to get the number of available characters to read from
		the file without blocking.
		@return Number of available characters.
	*/
	public int CharsToRead()
	{	if (Opened) return Fil.CharsAvailable();
		else return 0;
	}
	
	/***** Methods throwing Exceptions *****/
	/** Fill the image with the next text line.
		The old contents of the image is no longer available, and the
		position is set at the start of the image.
		@throws FileException
	*/
	public void InImageE() throws FileException
	{	if (Opened) fillimage(); else ERR="closed";
		if (ERR.length()>0) throw new FileException(ERR);
	}
	/** Get an integer.
		Reads an integer from the current position. The position pointer 
		will be advanced over the integer. An integer may not be divided
		by a new line. The changeing to next line (a new image) will be
		made when necessary. If the text from current position could not
		be regarded as an integer an error will be reported.
		@return An integer from input (0 if no integer).
		@throws FileException
	*/
	public int ReadIntE() throws FileException
	{	int I;
		if (Opened) I=Rint(); else {I=0; ERR="closed";}
		if (ERR.length()==0) return I; else throw new FileException(ERR);
	}
	/** Get a real.
		Reads a real number from the current position. The position pointer 
		will be advanced over the number. An number may not be divided
		by a new line. The changeing to next line (a new image) will be
		made when necessary. If the text from current position could not
		be regarded as a number an error will be reported.
		@return A real from input (0.0 if no number).
		@throws FileException
	*/
	public double ReadRealE() throws FileException
	{	double R;
		if (Opened) R=Rreal(); else {R=0; ERR="closed";}
		if (ERR.length()==0) return R; else throw new FileException(ERR);
	}
	/** Get a text.
		A text string of n characters from current position is 
		returned. If end of image (line) is found before n characters a
		shorter text will be returned. Current position is updated, and
		new image fetched when necessary.
		@param n The length of the text string to read.
		@return A text string of at most n characters.
		@throws FileException
	*/
	public String ReadTextE(int n) throws FileException
	{	String T;
		if (Opened) T=Rtext(n); else {T=""; ERR="closed";}
		if (ERR.length()==0) return T; else throw new FileException(ERR);
	}
	/** Get a character.
		Read the character at current position and update current
		position.
		@throws FileException
	*/
	public char ReadCharE() throws FileException
	{	char C;
		if (Opened) C=Rchar(); else {C='\00'; ERR="closed";}
		if (ERR.length()==0) return C; else throw new FileException(ERR);
	}
	/** Open the file.
		A file has to be opened before it is used. If the file 
		could not be opened an error will be registered.
		@return true if successfull else false.
		@throws FileException
	*/
	public boolean OpenE() throws FileException
	{	Opened=Fil.Open();
		if (Opened) {EOF=false; image=new StringBuffer(); pos=0; return true;}
		else {ERR="failed"; throw new FileException(ERR);}
	}
	/** Close the file.
		The file is closed. All files should be closed before
		terminating the program.
		@throws FileException
	*/
	public void CloseE() throws FileException
	{	if (Opened) {Opened=false;Fil.close();} else ERR="closed";
		if (ERR.length()>0) throw new FileException(ERR);
	}

/* *********************************************************************** */
/* *********************************************************************** */
/* *********************************************************************** */	
/* *********************** internal routines ***************************** */
/* *********************************************************************** */
/* *********************************************************************** */	
	private char Rchar()
	{	ERR="";
		if (!EOF) return getchar();
		else return '\025';
	}
	
	private int Rint()
	{	char ch;
		StringBuffer S;
		ERR="";
		int V=0;
		while ((pos>=image.length())&&!EOF) {fillimage();};
		SkipSpace();
		ch=LookupChar();
		S=new StringBuffer();
		if ((ch=='-')||(ch=='+')) {S.append(getchar()); ch=LookupChar();}
		else
		if (Character.isDigit(ch)) {}  else {ERR="nonum";};
		while (Character.isDigit(ch))
		{S.append(getchar()); ch=LookupChar();}
		try	{V=Integer.parseInt(S.toString());}
		catch (Exception E) {};
		return V;
	}
	
	private double Rreal()
	{	char ch;
		StringBuffer S;
		ERR="";
		double V=0;
		while ((pos>=image.length())&&!EOF) {fillimage();};
		SkipSpace();
		ch=LookupChar();
		S=new StringBuffer();
		if ((ch=='-')||(ch=='+')) {S.append(getchar()); ch=LookupChar();}
		else
		if (Character.isDigit(ch)) {} else {ERR="nonum";};
		while (Character.isDigit(ch))
		{S.append(getchar()); ch=LookupChar();}
		if (ch=='.') {S.append(getchar()); ch=LookupChar();};
		while (Character.isDigit(ch))
		{S.append(getchar()); ch=LookupChar();}
		try	{V=new Double(S.toString()).doubleValue();}
		catch (Exception E) {};
		return V;
	}
	private String Rtext(int n)
	{	String S;
		int start,stop;
		ERR="";
		while ((pos>=image.length())&&!EOF) {fillimage();};
		start=pos;
		if (n>0) stop=pos+n; else stop=pos;
		if (stop>=image.length()) stop=image.length();
		S=image.toString();
		pos=stop;
		return S.substring(start,stop);
	}
	
	
	/* *************** private help routines *************** */
	private void fillimage()
	{	boolean EOL;
		int data;
		char ch;
		image=new StringBuffer();
		pos=0;
		EOL=false;
		while (!EOL)
		{	data=Fil.Get();
			if (Fil.check()) {} else {ERR="readerror";}
			ch=(char) data;
			if (data==-1) {EOF=true; EOL=true;}
			else
			if (ch=='\n') {EOL=true;}
			else
			if (ch=='\r')
			{  EOL=true;
			   data=Fil.Get();
			   ch=(char) data;
			   if(ch=='\n'){}
			   else {}
			}
			else image.append(ch);
		} 
	}
	private char getchar()
	{	if (pos>=image.length())
			{fillimage(); if (!EOF) return getchar(); else return '\025';}
		else {pos=pos+1; return image.charAt(pos-1);}
	}
	private char LookupChar()
	{if (pos>=image.length()) return '\00'; else return image.charAt(pos);}
	private void SkipSpace()
	{	char ch;
		if (pos>=image.length()) {fillimage();ch=' ';} else ch=image.charAt(pos);
		while (Character.isWhitespace(ch))
		{	pos=pos+1;
			if (pos>=image.length())
				{while ((!EOF)&&(pos>=image.length())) fillimage();};
			if (!EOF) ch=image.charAt(pos); else ch='\0';
		}
	}
	
}
/* *********************************************************************
*	Internal class used to implement the interface to file stream
********************************************************************* */
class Input
{	private InputStream FIL;
	boolean Error;
	boolean Std;
	
	Input(String FN)
	{try	{FIL=new FileInputStream(FN); Error=false;}
	 catch(Exception E) {Error=true;}
	 Std=false;
	}
	Input()
	{Std=true; Error=false;
	}
	
	boolean Open()
	{return !Error;}
	
	boolean Available()
	{try {	if (Error) return false;
				else
				if (!Std) return FIL.available()>0;
				else return System.in.available()>0;
		  }
	 catch (IOException E) {Error=true; return false;}
	}
	
	int CharsAvailable()
	{try {	if (Error) return 0;
				else
				if (!Std) return FIL.available();
				else return System.in.available();
		  }
	 catch (IOException E) {Error=true; return 0;}
	}
	
	boolean close()
	{try	{if (Std) {} else FIL.close(); return true;}
	 catch (IOException E) {Error=true; return false;}
	}
	
	int Get()
	{try	{if (Std) return System.in.read(); else return FIL.read();}
	 catch (IOException E) {Error=true; return -1;}
	 }
	 boolean check()
	 {if (Error) {Error=false; return false;} else {Error=false; return true;}}
}
