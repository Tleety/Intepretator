package file;
/*
 !***************************************************************
 !		Revision history
 !	0.1	970901 
 ! 1.0	980825 more methods introduced
 !
 !***************************************************************
*/
/* ******************************************************************
*		*** word ***
*
*	word is used to implement a bitpattern of 32 bits
*	Constructors:
*		word()		creates a bitpattern with all bits set to 0
*		word(int n)	creates a bitpattern representing integer n
*		word(float r)	creates a bitpattern representing real r
*	Methods:
*		Set(int n)	 change bitpattern to that of integer n
*		Set(float f) change bitpattern to that of real f
*		Set(String s)change bitpattern to that of String s
*						 at most 4 leftmost bytes, left justified
*						 null filled.
*		Put(int Field, int Length, int Position)
*						The field is masked out to Length bits and
*						put into the bitpattern at Position 
*		int Get(int Length, int Position)
*						The field of Length bits at Position
*						is masked out and shifted down and returned as int
*
*			Bits numbered:
*		31 30                       2 1 0
*		_________________________________
*		|                                |
*		|________________________________|
*
*		int Get()	return an integer with this bitpattern
*		Write(outbytefile f)
*						The bitpattern is written to the byte file
*						just as a bitpattern.
*
****************************************************************** */
/** An object of type word represents a bitpattern of 32 bits.
	The bits in the word are numbered 0,1,2,..,31 from right to left.
	There are a number of methods for bit manipulation of the word
	bitpattern.
	@author G�ran Fries
	@version 1.0
*/
public class word
{	private int W;
	private final int M=0x80000000;
	/** Creating a bitpattern with all bits set to zero.
	*/
	public word() {W=0;}
	/** Creating a bitpattern representing an integer.
		@param I The integer (32 bits).
	*/
	public word(int I) {W=I;}
	/** Creating a bitpattern representing a real.
		@param R The real (float 32 bits).
	*/
	public word(float R) {W=Float.floatToIntBits(R);}
	/** Change bitpattern.
		A part of the bitpattern is changed by putting a subpattern
		in a part of the word. The rest of the bitpattern is NOT changed.
		The subpattern has a length (number of bits), a content given by
		an integer (cut at left end to fit subpattern). It is put at a
		position of the word (number of rightmost bit).
		@param Field The contents of the subpattern.
		@param Length The length in bits of the subpattern.
		@param Position The number of the rightmost bit in word.
	*/
	public void Put(int Field, int Length, int Position)
	{	int mask,MF;
		mask=M>>(Length-1);
		mask=mask>>>(32-Length);
		MF=Field&mask;
		mask=mask<<Position;
		mask=~mask;
		W=W&mask;
		MF=MF<<Position;
		W=W|MF;
	}
	/** Set pattern from integer.
		The bitpattern is completely changed to that of the integer.
		@param I The integer (32 bits).
	*/
	public void Set(int I) {W=I;}
	/** Set pattern from real.
		The bitpattern is completely changed to that of the real.
		@param R The real (float 32 bits).
	*/
	public void Set(float R) {W=Float.floatToIntBits(R);}
	/** Set pattern from String.
		The bitpattern is completely changed to that of the string.
		Only the four leftmost characters of the string is used. If
		the length of the string is less than four bytes it is padded
		with null characters (at the right end) to be exactly four characters.
		@param S The string.
	*/
	public void Set(String S)
	{	int I,B,L;
		char C;
		I=0;
		W=0;
		L=S.length();
		if (L>3) {L=4;}
		while (I<L)
		{	C=S.charAt(I);
			B=((int)C)<<(8*(3-I));
			W=W|B;
			I=I+1;
		}
	}
	/** Get as integer.
		The bitpattern is returned and interpreted as an integer.
		@return An integer (32 bits) with the bitpattern of the word.
	*/
	public int Get() {return W;}
	/** Get as integer.
		A subpattern of given length and with rightmost bit at given 
		position is extracted and returned and interpreted as an integer.
		@param Length The length of the subpattern.
		@param Position The number of the rightmost position.
		@return An integer with the sub-bitpattern from the word.
	*/
	public int Get(int Length, int Position)
	{	int mask,MF;
		mask=M>>(Length-1);
		mask=mask>>>(32-Length);
		MF=W>>>Position;
		return MF&mask;
	}
	/** Output to bytefile.
		The bitpattern, 32 bits, is written out as four bytes to
		the specified outbytefile.
		@param F The outbytefile.
	*/
	public void Write(outbytefile F) {F.Write(W);}
}
