package file;
/*
 !***************************************************************
 !		Revision history
 !	0.1	971001 
 ! 1.0	980825
 !
 !***************************************************************
*/
/** File exception.
	This type is a subtype of Exception and objects of this
	type are thrown when an error occurs in file methods.
	Most methods handle errors without using the exception
	concept, but there are some methods using exceptions
	to report errors.
	@author G�ran Fries
	@version 1.1
*/
public class FileException extends Exception
{	private String ThisError;
	/** Constructor.
		The main message contained in Exceptions is set to
		"File handling error" and in addition to this
		a special local errortext is saved in the object.
	*/
	FileException(String what)
	{	super("File handling error");
		ThisError=what;
	}
	/** Get special error text.
		@return The special local errortext.
	*/
	public String geterror() {return ThisError;}
}
