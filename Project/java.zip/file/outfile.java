package file;
/*
 !***************************************************************
 !		Revision history
 !	0.1	971001 
 ! 1.0	980825
 !
 !***************************************************************

*/
import java.io.*;
/* *************************************************************************
*		*** outfile ***
*
*	outfile is a sequential file of line images, that may be either
*	a normal named file or standard output.
*
*	infile has two constructors:
*		new outfile("filename")	will open a named "normal" file for output
*		new outfile()				will open standard output (shell,...)
*	Methods:
*		Open()-->boolean		file has to be opened before used
*									false will be returned on error else true
*		Open(int)-->boolean	file has to be opened before used, set buffer length
*									false will be returned on error else true
*		Close()					file should be closed when not used anymore
*									last image written if not empty
*		WriteLine()				output current image, and a newline
*		Write()					output current image, but no newline
*		Write(char)				put char in image at current position, and
*									advance position.
*		Write(I,n)				make a text of n characters and place the
*									integer I right justified there and place this
*									in the image starting at current position and
*									advance position to after this text.
*		Write(R,n)				similar as writeint, but the real R is written.
*		Write(String)			similar, but the string is transfered.
*		Skip(int)				advance current position a number of steps.
*		Check()-->boolean		return false if last operation failed, else true
*		GetError()-->String	return an error text. The following errors exists:
*									"failed" - open or closed failed
*									"closed" - operation attempted on a closed file
*									"readerror" - read error from file
*									"overflow" - textfield too small
*									"OK"     - geterror called when no pending error
*Notice! When the image is filled an automatic writeline will be called.
* OpenE, CloseE, WriteLineE, WriteRealE, WriteTextE, SkipE does the same as
* those without E, but throws an FileException when error.
************************************************************************* */
/** An outfile object is used to represent an output text file.
	A file may be an "ordinary" file with a file name or it may be
	the standard output. Except file name and creation there are
	no differencies in using standard output or another file.
	There are two different types of error handling. There is
	an error flag and text in the outfile object that will be set.
	This may be checked by methods. Another way of handling errors
	is that in addition to the above an exception may be thrown.
	A file object has a buffer for the output (A string buffer called
	image). This image will be emptied when necessary, and units like
	characters, numbers or texts may be written to this image. There are
	also some methods directly manipulating the image. As an outfile
	is a sequential text file the image represents a line of text.
	@author G�ran Fries
	@version 1.0
*/
public class outfile
{	private String FileName;
	private StringBuffer image;
	private String ERR;
	private int pos,high;
	private final int MAX=132;
	private final int NEWLINE=10;
	private StringBuffer blanks;
	private String blanks132;
	private int BuffLength;
	private boolean EOF,Opened;
	private Output Fil;
	
	/* **** constructors **** */
	/** Create with file name.
		This will create an outfile object connected to a named file.
		@param FN The name of the file.
	*/
	public outfile(String FN)
	{	FileName=FN; Fil=new Output(FN);}
	/** Create with standard output.
		This will create an outfile object connected to standard output.
	*/
	public outfile()
	{	FileName=""; Fil=new Output();}
	
	/* **** Methods not throwing any Exceptions **** */
	/** Open the file.
		A file has to be opened before it is used. If the file 
		could not be opened an error will be registered.
		A spacefilled image, with length 132, will be created as buffer.
		@return true if successfull else false.
	*/
	public boolean Open()
	{	Opened=Fil.Open();
		if (Opened)
		{	EOF=false;
			BuffLength=MAX;
			blanks=new StringBuffer();
			while (blanks.length()<BuffLength) blanks.append(' ');
			blanks132=blanks.toString();
			image=new StringBuffer(blanks132);
			ERR="";
			return true;
		}
		else {ERR="failed"; return false;}
	}
	/** Open the file.
		A file has to be opened before it is used. If the file 
		could not be opened an error will be registered.
		A spacefilled image, with length L, will be created as buffer.
		@param L The length of the buffer (text line).
		@return true if successfull else false.
	*/
	public boolean Open(int L)
	{	Opened=Fil.Open();
		if (Opened)
		{	EOF=false;
			BuffLength=L;
			blanks=new StringBuffer();
			while (blanks.length()<BuffLength) blanks.append(' ');
			blanks132=blanks.toString();
			image=new StringBuffer(blanks132);
			ERR="";
			return true;
		}
		else {ERR="failed"; return false;}
	}
	/** Close the file.
		The file is closed. All files should be closed before
		terminating the program. If there is something in the
		output buffer this will be written as a line to the file.
	*/
	public void Close()
	{	if (Opened)
			{	ERR="";
				if (pos>0) Wline(NEWLINE);
				Fil.close();
				if (Fil.check()) {} else ERR="failed";
			}
		else
			{ERR="closed";}
	}
	/** Write a line.
		Output current image, and a newline
	*/
	public void WriteLine() {if (Opened) Wline(NEWLINE); else ERR="closed";}
	/** Write.
		Output current image, but no newline.
	*/
	public void Write() {if (Opened) Wline(0); else ERR="closed";}
	/** Write character.
		A character is written to the buffer and position advanced.
		@param ch The character to write.
	*/
	public void Write(char ch) {if (Opened) Wchar(ch); else ERR="closed";}
	/** Write integer.
		An integer is converted to text representing the number(n characters) 
		and written to the buffer and position is advanced.
		@param I The integer to write.
		@param N Left justyfied with N characters
	*/
	public void Write(int I, int N)
	{if (Opened) Wint(I,N); else ERR="closed";}
	/** Write real.
		A double real is converted to text representing the number(n characters) 
		and written to the buffer and position is advanced.
		@param R The real to write.
		@param N Left justyfied with N characters
	*/
	public void Write(double R, int N)
	{if (Opened) Wreal(R,N); else ERR="closed";}
	/** Write a text.
		A string is written to the output buffer and the position
		is advanced.
		@param T The string to write.
	*/
	public void Write(String T)
	{if (Opened) Wtext(T); else ERR="closed";}
	/** Skip.
		The position is advanced a number(>0) of positions.
		@param n The number of positions to skip.
	*/
	public void Skip(int n)
	{if (Opened) Wskip(n); else ERR="closed";}
	/** Check for error.
		Did the latest method fail?
		@return true if previous method failed else false.
	*/
	public boolean Check() {return ERR.length()==0;}
	/** Get error message.
		Get the error message for latest method, if this did not fail
		an OK message will be returned.
		@return Error message or OK.
	*/
	public String GetError()
	{if (ERR.length()==0) return "OK"; else return ERR;}
	
	/* **** Methods throwing Exceptions **** */
	/** Open the file.
		A file has to be opened before it is used. If the file 
		could not be opened an error will be registered.
		A spacefilled image, with length 132, will be created as buffer.
		@return true if successfull else false.
		@throws FileException
	*/
	public boolean OpenE() throws FileException
	{	Opened=Fil.Open();
		if (Opened)
		{	EOF=false;
			BuffLength=MAX;
			blanks=new StringBuffer();
			while (blanks.length()<BuffLength) blanks.append(' ');
			blanks132=blanks.toString();
			image=new StringBuffer(blanks132);
			ERR="";
			return true;
		}
		else {ERR="failed"; throw new FileException(ERR);}
	}
	/** Open the file.
		A file has to be opened before it is used. If the file 
		could not be opened an error will be registered.
		A spacefilled image, with length L, will be created as buffer.
		@param L The length of the buffer (text line).
		@return true if successfull else false.
		@throws FileException
	*/
	public boolean OpenE(int L) throws FileException
	{	Opened=Fil.Open();
		if (Opened)
		{	EOF=false;
			BuffLength=L;
			blanks=new StringBuffer();
			while (blanks.length()<BuffLength) blanks.append(' ');
			blanks132=blanks.toString();
			image=new StringBuffer(blanks132);
			ERR="";
			return true;
		}
		else {ERR="failed"; throw new FileException(ERR);}
	}
	/** Close the file.
		The file is closed. All files should be closed before
		terminating the program. If there is something in the
		output buffer this will be written as a line to the file.
		@throws FileException
	*/
	public void CloseE() throws FileException
	{	if (Opened)
			{	ERR="";
				if (pos>0) Wline(NEWLINE);
				Fil.close();
				if (Fil.check()) {}
				else {ERR="failed";throw new FileException(ERR);}
			}
		else
			{ERR="closed"; throw new FileException(ERR);}
	}
	/** Write a line.
		Output current image, and a newline
		@throws FileException
	*/
	public void WriteLineE() throws FileException
	{	if (Opened) Wline(NEWLINE); else ERR="closed";
		if (ERR.length()>0) throw new FileException(ERR);
	}
	/** Write.
		Output current image, but no newline.
		@throws FileException
	*/
	public void WriteE() throws FileException
	{	if (Opened) Wline(0); else ERR="closed";
		if (ERR.length()>0) throw new FileException(ERR);
	}
	/** Write character.
		A character is written to the buffer and position advanced.
		@param ch The character to write.
		@throws FileException
	*/
	public void WriteE(char ch) throws FileException
	{	if (Opened) Wchar(ch); else ERR="closed";
		if (ERR.length()>0) throw new FileException(ERR);
	}
	/** Write integer.
		An integer is converted to text representing the number(n characters) 
		and written to the buffer and position is advanced.
		@param I The integer to write.
		@param N Left justyfied with N characters
		@throws FileException
	*/
	public void WriteE(int I, int N) throws FileException
	{	if (Opened) Wint(I,N); else ERR="closed";
		if (ERR.length()>0) throw new FileException(ERR);
	}
	/** Write real.
		A double real is converted to text representing the number(n characters) 
		and written to the buffer and position is advanced.
		@param R The real to write.
		@param N Left justyfied with N characters
		@throws FileException
	*/
	public void WriteE(double R, int N) throws FileException
	{	if (Opened) Wreal(R,N); else ERR="closed";
		if (ERR.length()>0) throw new FileException(ERR);
	}
	/** Write a text.
		A string is written to the output buffer and the position
		is advanced.
		@param T The string to write.
		@throws FileException
	*/
	public void WriteE(String T) throws FileException
	{	if (Opened) Wtext(T); else ERR="closed";
		if (ERR.length()>0) throw new FileException(ERR);
	}
	/** Skip.
		The position is advanced a number(>0) of positions.
		@param n The number of positions to skip.
		@throws FileException
	*/
	public void SkipE(int n) throws FileException
	{	if (Opened) Wskip(n); else ERR="closed";
		if (ERR.length()>0) throw new FileException(ERR);
	}
/* ******************************************************************* */
/* ******************************************************************* */
/* ******************************************************************* */
/* ********************** internal routines ************************** */
/* ******************************************************************* */
/* ******************************************************************* */
/* ******************************************************************* */

	private void Wline(int C)
	{	Fil.Put(image,C,high);
		if (Fil.check()) ERR=""; else ERR="writeerror";
		image=new StringBuffer(blanks132);
		pos=0; high=pos;
	}
	
	private void Wchar(char ch)
	{	Putchar(ch); }
	
	private void Wint(int I, int N)
	{	StringBuffer S; int L;
		S=new StringBuffer();
		S.append(I);
		L=S.length();
		if (N==0) N=L;
		if (L>N) {ERR="overflow";}
		else
		if (L==N) {for (int k=0; k<L; k=k+1) Putchar(S.charAt(k));}
		else
		{	for (int k=0; k<N-L; k=k+1) Putchar(' ');
			for (int k=0; k<L; k=k+1) Putchar(S.charAt(k));
		};
	}
	private void Wreal(double R, int N)
	{	StringBuffer S; int L;
		S=new StringBuffer();
		S.append(R);
		L=S.length();
		if (N==0) N=L;
		if (L>N) {ERR="overflow";}
		else
		if (L==N) {for (int k=0; k<L; k=k+1) Putchar(S.charAt(k));}
		else
		{	for (int k=0; k<N-L; k=k+1) Putchar(' ');
			for (int k=0; k<L; k=k+1) Putchar(S.charAt(k));
		};
	}
	private void Wtext(String T)
	{for (int k=0; k<T.length(); k=k+1) {Putchar(T.charAt(k));}}
	public void setpos(int n)
	{if ((n>=0)&&(n<BuffLength)) pos=n; if (pos>high) high=pos;}
	
	private void Wskip(int n)
	{	if (n>0) pos=pos+n;
		if (pos>=BuffLength)
			{	Fil.Put(image,NEWLINE,high);
				if (Fil.check()) ERR=""; else ERR="writeerror";
				image=new StringBuffer(blanks132);
				pos=0; high=pos;
			}
	}
	
	void Putchar(char ch)
	{	if (pos>=BuffLength) 
		{Fil.Put(image,NEWLINE,high); image=new StringBuffer(blanks132); pos=0; high=pos;}
		image.setCharAt(pos,ch);
		if (pos>high) high=pos;
		pos=pos+1;
	}
}
class Output
{	private OutputStream FIL;
	boolean Error;
	boolean Std;
	final int NEWLINE=10;
	
	Output(String FN)
	{try	{FIL=new FileOutputStream(FN); Error=false;}
	 catch(Exception E) {Error=true;}
	 Std=false;
	}
	Output()
	{Std=true; Error=false;
	}
	
	boolean Open()
	{return !Error;}
	
	void close()
	{try	{if (Std) {} else FIL.close();}
	 catch (IOException E) {Error=true;}
	}
	
	void Put(StringBuffer S, int C, int high)
	{try	{if (Std)
			 {	if (C==NEWLINE) 
			 	System.out.println(S.toString().substring(0,high+1));
			 	else
			 	System.out.print(S.toString().substring(0,high+1));
			 	//System.out.flush();
			 }
			 else
			 {	for (int k=0; k<=high; k=k+1)
			 	FIL.write((int) S.charAt(k));
			 	if (C!=0) FIL.write(C);
			 }
			}
	 catch (IOException E) {Error=true;}
	}
	boolean check()
	{if (Error) {Error=false; return false;} else {Error=false; return true;}}
}
