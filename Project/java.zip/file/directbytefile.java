package file;
import java.io.*;
/** An directbytefile object is used to represent direct access byte file.
	A bytefile is a sequence of bytes with no interpretation of
	newlines, linefeed or other formatting characters. When input of
	a number (say integer) is made from a textfile the text representation
	of a number is read and converted to a number. In a bytefile the 
	transfered data is just the bitrepresentation of the number and no
	conversion is made. Byte files are used to represent bitpatterns just
	as they are. A bytefile is connected to a named file in the file system.
	There are two different types of error handling.
	@author Göran Fries
	@version 1.0
*/
public class directbytefile
{  private String FileName;
   private String Mode;
   private RandomAccessFile Fil;
   private boolean EOF,Opened,Error;
   private boolean ByteOrder; // true for Big-endians, false for Little-endians
   /**  constructor
		A connection to a file with the given name is created.
		@param Name Name of the file.
   */
   public directbytefile(String Name)
   {  FileName=Name;
      Mode="rw";
      ByteOrder=true;
      Error=false;
      {  try {Fil=new RandomAccessFile(FileName,Mode);}
         catch(Exception E){Error=true;}
      }
      EOF=false;
   }
   /**  constructor
		A connection to a file with the given name is created. 
		The file may be used for reading, writing or both.
		@param Name Name of the file.
		@param M an access mode string.
   */
   public directbytefile(String Name,String M)
   {  FileName=Name;
      Mode=M;
      ByteOrder=true;
      Error=false;
      {  try {Fil=new RandomAccessFile(FileName,Mode);}
         catch(Exception E){Error=true;}
      }
      EOF=false;
   }
   /** BigEndian
		When integers or halfwords are transfered they are
		regarded as a sequence of 4 (2) bytes, in big endian
		order. This will set the interpretation to big endian.
   */
   public void BigEndian(){ByteOrder=true;}
   /** LittleEndian
		When integers or halfwords are transfered they are
		regarded as a sequence of 4 (2) bytes, in little endian
		order. This will set the interpretation to little endian.
   */
   public void LittleEndian(){ByteOrder=false;}
   /** Read byte.
		One byte is taken from the input file. Byte pointer advanced.
		@return A byte (one byte from file)
   */
   public int ReadByte()
   {  int N;
      Error=false;
      {  try {N=Fil.read(); if(N==-1){EOF=true;N=0;}}
         catch(Exception E){Error=true;N=0;}
      }
      return N;
   }
   /** Read bytes.
		A number of bytes is taken from the input file, and put in a byte array
		Byte pointer advanced.
		@param  B a byte array used to store the result
		@return an int
   */
   public int ReadBytes(byte[] B)
   {  int N;
      Error=false;
      {  try {N=Fil.read(B); if(N==-1){EOF=true;N=0;}}
         catch(Exception E){Error=true;N=0;}
      }
      return N;
   }
   /** Read bytes.
		A number of bytes is taken from the input file, and put in a byte array
		Byte pointer advanced.
		@param  B a byte array used to store the result
		@param  off start in the array
		@param len  the max number of bytes to be read
		@return an int
   */
   public int ReadBytes(byte[] B,int off,int len)
   {  int N;
      Error=false;
      {  try {N=Fil.read(B,off,len); if(N==-1){EOF=true;N=0;}}
         catch(Exception E){Error=true;N=0;}
      }
      return N;
   }
   /** Read integer.
		Four bytes are read and returned as an integer
		The set byte order is used. Byte pointer advanced.
		@return an int
   */
   public int ReadInt()
   {  int N; byte[]B={0,0,0,0};
      Error=false;
      {  try {  N=Fil.read(B,0,4);
               if(N==-1){EOF=true;return 0;}
               else{N=MakeInt(B);return N;}
             }
         catch(Exception E){Error=true; return 0;}
      }
   }
   /** Read short integer.
		Two bytes are read and returned as a short integer
		The set byte order is used. Byte pointer advanced.
		@return a short
   */
   public short ReadShort()
   {  short N; byte[]B={0,0};
      Error=false;
      {  try {  N=(short)Fil.read(B,0,2);
               if(N==-1){EOF=true;return 0;}
               else{N=MakeShort(B);return N;}
             }
         catch(Exception E){Error=true; return 0;}
      }
   }
   /** Write byte.
   		A byte is written to the file. Byte pointer advanced.
   */
   public void WriteBytes(int v)
   {  Error=false;
      {  try {Fil.write(v);}
         catch(Exception E){Error=true;}
      }
   }
   /** Write byte array.
   		A byte array is written to the file. Byte pointer advanced.
   		@param  B the byte array
   */
   public void WriteBytes(byte[] B)
   {  Error=false;
      {  try {Fil.write(B);}
         catch(Exception E){Error=true;}
      }
   }
   /** Write byte array.
   		A byte array is written to the file. Byte pointer advanced.
   		@param  B the byte array
   		@param  off from this start
   		@param  len at most len bytes
   */
   public void WriteBytes(byte[] B,int off,int len)
   {  Error=false;
      {  try {Fil.write(B,off,len);}
         catch(Exception E){Error=true;}
      }
   }
   /** Write integer.
   		An integer is written to the file, according to byte order of file.
   		Byte pointer advanced.
   		@param  V the integer
   */
   public void Write(int V)
   {  byte[]B;
      Error=false;
      B=MakeBytes(V);
      {  try {Fil.write(B,0,4);}
         catch(Exception E){Error=true;}
      }
   }
   /** Write short.
   		A short integer is written to the file, according to byte order of file.
   		Byte pointer advanced.
   		@param  V the short
   */
   public void Write(short V)
   {  byte[]B;
      Error=false;
      B=MakeBytes(V);
      {  try {Fil.write(B,0,2);}
         catch(Exception E){Error=true;}
      }
   }
   /** Get position.
   		Get pointer at current (next) byte in file
   		@return  file position as long integer
   */
   public long GetPos()
   {  long N;
      Error=false;
      {  try {N=Fil.getFilePointer();return N;}
         catch(Exception E){Error=true;return 0;}
      }
   }
   /** Set position.
   		Set pointer as new current (next) byte in file
   		@param  V  new file position as integer
   */
   public void SetPos(int v)
   {  Error=false;
      {  try {Fil.seek(v);}
         catch(Exception E){Error=true;}
      }
   }
   /** Check if end of file.
   		Return true if end of file already reached
   		@return true if end of file
   */
   public boolean Endfile(){return EOF;}
   /** Check if error.
   		Return true if last operation on the file resulted in an error
   		condition.
   		@return true error during last operation
   */
   public boolean Check(){return !Error;}
   
   private int MakeInt(byte[] B)
   {  int V=0;
      if(ByteOrder){V=((B[0]&0xff)<<24)|((B[1]&0xff)<<16)|((B[2]&0xff)<<8)|(B[3]&0xff);}
      else{V=((B[3]&0xff)<<24)|((B[2]&0xff)<<16)|((B[1]&0xff)<<8)|(B[0]&0xff);}
      return V;
   }
   private short MakeShort(byte[] B)
   {  short V=0;
      if(ByteOrder){V=(short)(((B[0]&0xff)<<8)|(B[1]&0xff));}
      else{V=(short)(((B[1]&0xff)<<8)|(B[0]&0xff));}
      return V;
   }
   private byte[] MakeBytes(int V)
   {  byte[] B={0,0,0,0};
      if(ByteOrder)
      {  B[0]=(byte)((V>>24)&0xff);
         B[1]=(byte)((V>>16)&0xff);
         B[2]=(byte)((V>>8)&0xff);
         B[3]=(byte)(V&0xff);
      }
      else
      {  B[3]=(byte)((V>>24)&0xff);
         B[2]=(byte)((V>>16)&0xff);
         B[1]=(byte)((V>>8)&0xff);
         B[0]=(byte)(V&0xff);
      }
      return B;
   }
   private byte[] MakeBytes(short V)
   {  byte[] B={0,0};
      if(ByteOrder)
      {  B[0]=(byte)((V>>8)&0xff);
         B[1]=(byte)(V&0xff);
      }
      else
      {  B[1]=(byte)((V>>8)&0xff);
         B[0]=(byte)(V&0xff);
      }
      return B;
   }
}
