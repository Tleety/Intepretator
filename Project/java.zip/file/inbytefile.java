package file;
/*
 !***************************************************************
 !		Revision history
 !	0.1	971001 
 ! 1.0	980825
 !
 !***************************************************************
*/
import java.io.*;
/* *************************************************************************
*		*** inbytefile ***
*
*	inbytefile is a sequential file of bytes, that is
*	a "normal" file with a filename
*	inbytefile has one constructor:
*		new inbytefile("filename")	will open a named "normal" file for input
*	Methods:
*		Open()-->boolean		file has to be opened before used
*									false will be returned on error else true
*		Close()					file should be closed when not used anymore
*		ReadChar()-->char		read two bytes as a character (Unicode)
*		ReadByte()-->int		read one byte as an integer
*		ReadInt()-->int		read four bytes as an integer
*		ReadReal()-->float	read four bytes as a real
*		Endfile()-->boolean	is end of file read?
*		Available()-->boolean true if input is available (without blocking)
*		BytesToRead()-->int	number of available characters without blocking.
*		Check()-->boolean		true if last infile operation OK, else false.
*		GetError()-->String	return an error text. The following errors exists:
*									"failed" - open or closed failed
*									"closed" - operation attempted on a closed file
*									"nonum"	- non-numeric item when such expected
*									"readerror" - read error from file
*									"OK"     - geterror called when no pending error
*									those, except OK, also as FileException texts.
*	OpenE, CloseE, ReadCharE, ReadIntE, ReadRealE
*	have the same meaning and value as those without E, but a FileException
*	may be thrown!
************************************************************************* */
/** An inbytefile object is used to represent an input byte file.
	A bytefile is a sequence of bytes with no interpretation of
	newlines, linefeed or other formatting characters. When input of
	a number (say integer) is made from a textfile the text representation
	of a number is read and converted to a number. In a bytefile the 
	transfered data is just the bitrepresentation of the number and no
	conversion is made. Byte files are used to represent bitpatterns just
	as they are. A bytefile is connected to a named file in the file system.
	There are two different types of error handling. There is
	an error flag and text in the inbytefile object that will be set.
	This may be checked by methods. Another way of handling errors
	is that in addition to the above an exception may be thrown.
	@author G�ran Fries
	@version 1.0
*/
public class inbytefile
{	private ByteInput Fil;
	private String Filename,ERR;
	boolean Opened,EOF;
	/**  constructor
		A connection to a file with the given name is created.
		@param FN Name of the file.
	*/
	public inbytefile(String FN) {Filename=FN; Fil=new ByteInput(Filename);}
	
	/* **** Methods not throwing any Exceptions **** */
	/** Open. A file has to be opened befor it is used.
		If the file could not be opened an error will be registered.
		@return true if successfull else false.
	*/
	public boolean Open()
	{	Opened=Fil.open();
		if (Opened) {ERR=""; EOF=false; return true;}
		else{ERR="failed"; return false;}
	}
	/** Close the file.
		The file is closed. All files should be closed before
		terminating the program.
	*/
	public void Close() 
	{Fil.close();}
	/** Possible to read?
		Used to test if it is possible to read from the file
		without blocking. Some systems will block the whole
		program if one java process will block.
		@return true if input available whithout blocking, otherwise false.
	*/
	public boolean Available()
	{	if (Opened) return Fil.Available();
		else return false;
	}
	/** Available bytes.
		Used to get the number of available bytes to read from
		the file without blocking.
		@return Number of available bytes.
	*/
	public int BytesToRead()
	{	if (Opened) return Fil.BytesAvailable();
		else return 0;
	}
	/** Read integer.
		Four bytes are taken from the input file interpreted as
		an integer (NO text to number conversion!). Byte pointer advanced.
		@return An integer (four bytes from file)
	*/
	public int ReadInt()
	{if (Opened) return Fil.GetI(); else {ERR="closed"; return 0;}}
	/** Read real.
		Four bytes are taken from the input file interpreted as
		a real (NO text to number conversion!). Byte pointer advanced.
		@return A real (four bytes from file)
	*/
	public float ReadReal()
	{if (Opened) return Fil.GetF(); else {ERR="closed"; return 0.0f;}}
	/** Read character.
		Two bytes are taken from the input file interpreted as
		a character (Unicode). Byte pointer advanced.
		@return A character (two bytes from file)
	*/
	public char ReadChar()
	{if (Opened) return Fil.GetU(); else {ERR="closed"; return '\0';}}
	/** Read byte.
		One byte is taken from the input file. Byte pointer advanced.
		@return A byte (one byte from file)
	*/
	public int ReadByte()
	{if (Opened) return Fil.GetB(); else {ERR="closed"; return 0;}}
	/** Read short.
		Two bytes is taken from the input file. Byte pointer advanced.
		@return A short (two bytes from file)
	*/
	public int ReadShort()
	{if (Opened) return Fil.GetH(); else {ERR="closed"; return 0;}}
	/** Check for error.
		Did the latest method fail?
		@return true if previous method failed else false.
	*/
	public boolean Check()
	{if (Opened) return Fil.check(); else return false;}
	/** Get error message.
		Get the error message for latest method, if this did not fail
		an OK message will be returned.
		@return Error message or OK.
	*/
	public String GetError()
	{	String E=Fil.GetErr();
		if (E!=null) ERR=ERR+E;
		if (ERR.length()==0) return "OK"; else return ERR;
	}
	/** Test for end of file.
		@return true if end of file reached, false otherwise.
	*/
	public boolean Endfile() {EOF=EOF||Fil.Eof(); return EOF;}
	/** Read integer.
		Four bytes are taken from the input file interpreted as
		an integer (NO text to number conversion!). Byte pointer advanced.
		@return An integer (four bytes from file)
		@throws FileException
	*/
	public int ReadIntE() throws FileException
	{	int I;
		if (Opened) I=Fil.GetI(); else {ERR="closed"; I=0;}
		if (ERR.length()==0) return I; else throw new FileException(ERR);
	}
	/** Read real.
		Four bytes are taken from the input file interpreted as
		a real (NO text to number conversion!). Byte pointer advanced.
		@return A real (four bytes from file)
		@throws FileException
	*/
	public float ReadRealE() throws FileException
	{	double R;
		if (Opened) R=Fil.GetF(); else {ERR="closed"; R=0.0f;}
		if (ERR.length()==0) return (float)R; else throw new FileException(ERR);
	}
	/** Read character.
		Two bytes are taken from the input file interpreted as
		a character (Unicode). Byte pointer advanced.
		@return A character (two bytes from file)
		@throws FileException
	*/
	public char ReadCharE() throws FileException
	{	char U;
		if (Opened) U=Fil.GetU(); else {ERR="closed"; U='\0';}
		if (ERR.length()==0) return U; else throw new FileException(ERR);
	}
	/** Read byte.
		One byte is taken from the input file. Byte pointer advanced.
		@return A byte (one byte from file)
		@throws FileException
	*/
	public int ReadByteE() throws FileException
	{	int B;
		if (Opened) B=Fil.GetB(); else {ERR="closed"; B=0;}
		if (ERR.length()==0) return B; else throw new FileException(ERR);
	}
}
/************************* Internal class ************************************/
class ByteInput
{	private InputStream UFIL;
	private DataInputStream FIL;
	private boolean Error,EOF;
	private String Err;
	
	ByteInput(String FN)
	{try	{	UFIL=new FileInputStream(FN);
				FIL=new DataInputStream(UFIL);
				Error=false; EOF=false;
			}
	 catch (Exception E) {Error=true;}
	}
	
	boolean open() {return !Error;}
	
	boolean Available()
	{try {	if (Error) return false;
				else return FIL.available()>0;
		  }
	 catch (IOException E) {Error=true; return false;}
	}
	
	int BytesAvailable()
	{try {	if (Error) return 0;
				else return FIL.available();
		  }
	 catch (IOException E) {Error=true; return 0;}
	}

	
	void close()
	{try	{FIL.close();}
	 catch (Exception E) {Error=true;}
	}
	int GetI() 
	{try	{	return FIL.readInt();
			}
	 catch (Exception E){Error=true;Err=E.getMessage();EOF=Err==null;return 0;}
	}
	float GetF() 
	{try	{	return FIL.readFloat();
			}
	 catch (Exception E){Error=true;Err=E.getMessage();EOF=Err==null;return 0.0f;}
	}
	int GetB() 
	{try	{	return (int)(FIL.readByte());
			}
	 catch (Exception E) {Error=true;Err=E.getMessage();EOF=Err==null;return 0;}
	}
	int GetH() 
	{try	{	return (int)(FIL.readShort());
			}
	 catch (Exception E) {Error=true;Err=E.getMessage();EOF=Err==null;return 0;}
	}
	char GetU() 
	{try	{	return FIL.readChar();
			}
	 catch (Exception E) {Error=true;Err=E.getMessage();EOF=Err==null;return '\0';}
	}
	boolean check() {boolean E=Error; Error=false; return !E;}
	String GetErr() {String E=Err; Err=""; return E;}
	boolean Eof() {return EOF;}
}
