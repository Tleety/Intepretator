package window;
/*
 !***************************************************************
 !		Revision history
 !	0.1	970901 
 ! 1.0	980825
 !
 !***************************************************************
*/

/** The Key Message type.
	A key event is represented by an object of this type.
	A key event means that a key has been pressed or released.
	The information in the message is whether key pressed, released or
	typed. Wich key it was is given by a code and character.
	The time in milliseconds since midnight.
	@author G�ran Fries
	@version 1.0
*/
public class KeyMessage extends Message
{	char Key;		// The character or null
	int Code;		// -1 if character else code
	int Direction;
	long Time;
	/** Create an object of type KeyMessage.
		Message objects are (and should be) created from a w object.
		@param K The typed character, included shift modified etc..
		@param C The key code, shift has one code etc...
		@param T Time milliseconds since midnight
		@param D Direction: Released, Pressed, Typed
	*/
	KeyMessage(char K,int C,long T,int D)
	{	Key=K;
		Code=C;
		Time=T;
		Direction=D;
	}
	/** Direction constants. */
	public static final int Released=1, Pressed=2, Typed=3;
	/** Get typed character.
		@return Typed char (notice key-a will give a or A depending on shift).
	*/
	public char GetKeyChar() {return Key;}
	/** Get the keycode.
		All keys have code also non-charater keys like shift, control,...
		@return The code of the key.
	*/
	public int GetKeyCode() {return Code;}
	/** Get direction.
		@return Direction as Pressed, Released or Typed (Only for char keys).
	*/
	public int GetDirection() {return Direction;}
	/** Is it a character key?
		@return true if a character key, false otherwise (like shift, alt,...).
	*/
	public boolean CharacterKey() {return Direction==Typed;}
	/** Time.
		@return The time of the event.
	*/
	public long GetTime() {return Time;}
}

