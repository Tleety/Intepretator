package window;
/*
 !***************************************************************
 !		Revision history
 !	0.1	970901 
 ! 1.0	980825
 !
 !***************************************************************
*/

/** The Mouse Message type.
	A mouse event is represented by an object of this type.
	A mouse event means that a mouse button has been pressed or released.
	The information in the message is whether button pressed or released,
	which button, the cursor (arrow) position at that time and the time
	as milliseconds since midnight.
	@author G�ran Fries
	@version 1.0
*/
public class MouseMessage extends Message
{	private int Direction;	// Released=1,Pressed=2
	private int Button;		// Left=1,Centre=2,Right=3
	private int x,y;			// position
	private long Time;		// ms since midnight
	/** Create an object of type MouseMessage.
		Message objects are (and should be) created from a w object.
		@param D Direction: Released, Pressed
		@param B Button: Left, Centre, Right
		@param u Position, x coordinate.
		@param v Position, y coordinate
		@param T Time milliseconds since midnight
	*/
	MouseMessage(int D,int B,int u,int v,long T)
	{	Direction=D;
		Button=B;
		x=u;
		y=v;
		Time=T;
	}
	/** Direction constants. */
	public static final int Released=1,Pressed=2;
	/** Button constants. */
	public static final int Left=1,Centre=2,Right=3;
	/** Which button?
		@return The button (Left, Centre, Right).
	*/
	public int GetButton() {return Button;}
	/** Wich direction?
		@return The direction (Pressed, Released).
	*/
	public int GetDirection() {return Direction;}
	/** Get the x coordinate.
		@return The x coordinate of mouse arrow position.
	*/
	public int Getx() {return x;}
	/** Get the y coordinate.
		@return The y coordinate of mouse arrow position.
	*/
	public int Gety() {return y;}
	/** Time.
		@return The time of the event.
	*/
	public long GetTime() {return Time;}
}
