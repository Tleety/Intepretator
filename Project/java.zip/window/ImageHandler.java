package window;
/* 
 !***************************************************************
 !		Revision history
 !	0.1	980601 Only for test purposes
 !
 !***************************************************************
*/
import java.awt.*;
/** Handling images, TEST version.
	This feature is not tested yet, and should not
	be used for "real programs".
	@author G�ran Fries
	@version 0.1 Test
*/
public class ImageHandler
{	private Image TheImage;
	private Graphics GTool;
	private int X,Y;
	private Color Pen,BGC,FillC;
	
	/* TEST */
	private Canvas Can;
	/************/

	
	public ImageHandler(Image Im)
	{	TheImage=Im;
		GTool=Im.getGraphics();
	}
	public ImageHandler()
	{	
	}
	
	public Image GetImage() {return TheImage;}
	
	public void DrawCircle(int u, int v, int r)
	{	GTool.drawOval(u-r,v-r,2*r,2*r);}
	
	public void DrawOval(int x1, int y1, int a, int b)
	{	GTool.drawOval(x1,y1,a,b);}
	
	public void DrawRectangle(int x1, int y1, int x2, int y2)
	{	GTool.drawRect(x1,y1,x2-x1,y2-y1);}
	
	public void DrawLine(int x1, int y1, int x2, int y2)
	{	GTool.drawLine(x1,y1,x2,y2);}
	
	public void EraseCircle(int x1, int y1, int r)
	{	Eraser();
		DrawCircle(x1,y1,r);
		RestorePen();
	}
	
	public void EraseOval(int x1, int y1, int a, int b)
	{	Eraser();
		DrawOval(x1,y1,a,b);
		RestorePen();
	}
	
	public void EraseRectangle(int x1, int y1, int x2, int y2)
	{	Eraser();
		DrawRectangle(x1,y1,x2,y2);
		RestorePen();
	}
	
	public void EraseLine(int x1, int y1, int x2, int y2)
	{	Eraser();
		DrawLine(x1,y1,x2,y2);
		RestorePen();
	}
	
	public void FillCircle(int u, int v, int r)
	{	Filler();
		GTool.fillOval(u-r,v-r,2*r,2*r);
		RestorePen();
	}
	
	public void FillOval(int x1, int y1, int a, int b)
	{	Filler();
		GTool.fillOval(x1,y1,a,b);
		RestorePen();
	}
	
	public void FillRectangle(int x1, int y1, int x2, int y2)
	{	Filler();
		GTool.fillRect(x1,y1,x2-x1,y2-y1);
		RestorePen();
	}
	
	public void EraseFilledCircle(int u, int v, int r)
	{	Eraser();
		GTool.fillOval(u-r,v-r,2*r,2*r);
		RestorePen();
	}
	
	public void EraseFilledOval(int x1, int y1, int a, int b)
	{	Eraser();
		GTool.fillOval(x1,y1,a,b);
		RestorePen();
	}
	
	public void EraseFilledRectangle(int x1, int y1, int x2, int y2)
	{	Eraser();
		GTool.fillRect(x1,y1,x2-x1,y2-y1);
		RestorePen();
	}
	
	
	public void SetPen(Color C)
	{	Pen=C;
		GTool.setColor(C);
	}
	
	void Eraser()
	{	GTool.setColor(BGC);
	}
	
	public void Filler()
	{	GTool.setColor(FillC);}
	
	public void RestorePen()
	{	GTool.setColor(Pen);}
	
	public void SetBackground(Color C)
	{	if (C!=null) { BGC=C;};}
	
	public void SetFillColor(Color C)
	{	FillC=C;}
	
	public void SetPosition(int x0, int y0)
	{	X=x0;
		Y=y0;
	}
	
}
