package window;
/*
 !***************************************************************
 !		Revision history
 !	0.1	970901 
 ! 0.2	980115
 !	0.3	980428 More methods
 !	1.0	980512 New Buffering introduced
 !	1.0.1	981007 paint changed to update, more stable picture
 !	1.1	021206 gif/jpeg picture images introduced
 !***************************************************************
*/

import java.awt.event.*;
import java.awt.*;
import struct.*;
/* ************************************************************
!	class w
!
! Used to represent a window on the screen. The window is a normal
! one with a title bar. The title is set as a text to the constructor.
! The window has a background colour and is suitable for drawing
! and texthandling.
!	Constructors:
!		w(int width, int height, String title,Color C)
!			The window is created and opened with the given size,
!			title and backgroun colour.
!	Methods:
!	Drawing (made bye pen and fillcolour)
!		DrawLine(x0,y0,x1,y1)
!			Draw a line from (x0,y0) to (x1,y1)
!		DrawRectangle(x0,y0,x1,y1)
!			Draw a rectangle with top left/bottom right corner in
!			(x0,y0)/(x1,y1)
!		DrawCircle(x0,y0,r)
!			Draw a circle with centre in (x0,y0) and radius r
!		DrawOval(x0,y0,a,b)
!			Draw a circle with centre in (x0,y0) and axis a,b
!		Erasexxx with xxx=Line,Rectangle,Circle,Oval and parameters
!			as for the Drawxxx erase the drawn figure
!		Fillyyy with yyy=Rectangle,Circle,Oval the same as
!			Drawyyy, but the interior is filled by the "fill colour".
!		EraseFilledyyy erase the corresponding filled figures.
!	Set attributes (does modify other methods)
!		SetPen(C) Set the colour of the pen to C (of type Color).
!		SetFiller(C) Set the colour used by Fillyyy to C.
!		SetBackground(C) Set the background colour to C. (System problems!)
!		SetFont(Font) changes the font used for texts
!		SetFont(String) changes the font name, and used font
!		SetStyle(int) changes the font style, and used font
!		SetFontSize(int) changes the font size, and used font
!			available styles are Plain, Bold, Italic and BoldItalic.
!	Get attributes
!		GetPen(), GetFiller(), GetBackground() returns the Color
!		GetStyle(), GetFontSize(), GetFontName(), GetFont() 
!		return font attributes.
!		clearRectangle(x0,y0,x1,y1) clear a rectangular field 
!			of the window.
!		MakeColor(R,G,B) ---> Color
!			this returns a Color object made from Red,Green,Blue
!			each of these colours may have a value from 0 to 255,
!			thus it is possible to create 256*256*256 different
!			colors. This is much more than your eye may discriminate,
!			and probably more than the screen may produce.
!		Predefined colours are: black,blue,gray,green,orange,
!			pink,red,yellow and white.
!	Text in window (a window has a text position)
!		Write(T) 
!			write the text t (String) starting at the text position
!		Erase(T)
!			erase a written text T at the text position
!		SetPosition(x,y)
!			change the text position of the window to (x,y)
!	General purpouse methods
!		Open(C)
!			This method is automatically called by the constructor. 
!			It sets the background colour to C. It may be called to
!			reopen a closed window.
!		Close()
!			close the window, but keep its state so it may be reopened
!		Destroy()
!			the window is closed and its state and all its used memory
!			is removed. It may not be reopened again. A forced GC is done.
!		Delay(ms)
!			delay the execution for ms milliseconds. This may be
!			used to control the speed of animation, or to give
!			the window system time to handle events.
!	Event handling.
!		Your program may be regarded as a process running in parallell
!		with a window system and the Unix operating system. When
!		something happens, like mouse clicking and keyboard typing
!		the window system will be notified. Even if you are
!		unaware of parallell activities, you may have a need for knowing
!		when such events have happened. Events may be get from the window
!		as objects of type Message, (subtypes MouseMessage, KeyMessage).
!		GetEvent() --> Message
!			if there is a pending event this is returned and removed from
!			the pending message queue, if queue is empty null is returned.
!		FlushEvents()
!			will empty all event queues!
!		EnableMouse()
!			all mouse events will be sent to mouse message queue
!			(and the common queue)
!		DisableMouse()
!			mouse events will only be sent to the common queue
!		FlushMouse()
!			the mouse queue will be emptied (all mose events lost)
!		GetMouseButton() --> Message
!			return a pending message from mouse event queue
!			or null if queue empty
!		EnableKey(), DisableKey(), FlushKey() and GetKey()
!			all acts as those for the mouse above, but of course
!			they operate on the key event queue.
!
!*********************************************************** */
/** An object of type w is representing a window on the screen.
	A window is an area with a frame and a title bar that may be
	handled by the window system in a normal way. This area may be
	used and controlled from the user program, for drawing, text
	output, keyboard input, mouse actions, etc... 
	Pressed mousebuttons and typed keys are caught by the underlying
	system and registered as events and kept in event queues. Events
	may then be asked for, there are methods in the window class for
	getting events. There is one queue holding all kind of events,
	this queue is always present. Then there may be one queue for
	only mouse events and one queue for key events. Those queues are
	only present when enabled. It is possible to get events (messages)
	from the queues, and the a queue may be flushed (emptied).
	The AWT software is used but all its details are hidden from
	the user, at least as long as the user does not care. 
	An image my also be handled within a window and placed
	somewhere on the canvas. An image may be produced
	in any of those ways images may be produced. A simple
	example is to read an image from a gif or jpeg file. 
	@author G�ran Fries
	@version 1.1
*/
public class w
{
	private WFrame Frm;
	private WCanvas Canv;
	private MessageQueue Mess;
	private DelayObject DelObj;
	
	/** A window is created.
		A window with a width, height and background colour
		is created and opened. The window will also have a
		titlebar with the given text as title. The window
		will be placed somewhere on the screen.
		@param width The width in pixels.
		@param height The height in pixels.
		@param title The title of the window.
		@param C The background colour.
	*/
	public w(int width, int height, String title,Color C)
	{	Frm=new WFrame(width,height,title);
		Frm.setResizable(false);
		Mess=new MessageQueue();
		DelObj=new DelayObject();
		Canv=new WCanvas(width,height,Mess,C);
		Frm.add(Canv);
		Open(C);
		Delay(500);
	}
	/** Open window.
		It is possible to open a closed window. When a window is
		created it will also be opened.
	*/
	public void Open(Color C)
	{	Frm.Open();
		Canv.Open(C);
	}
	/** Close the window.
		The window will not be shown on the screen. It is
		possible to open it again.
	*/
	public void Close()
	{	Frm.Close();
	}
	/** Flush.
		The window may work in two modes, buffered and non-buffered.
		In non-buffered mode all drawing, writing, etc... will be
		immediately shown on the screen, in buffered mode only the
		image will be affected and not the screen. Flush will show
		the buffered image on the screen. Notice that some other
		actions in the window system may force this and the image
		may be shown.
	*/
	public void Flush()
	{Canv.Display();}
	/* NOT YET DOCUMENTED */
	/** Not yet tested and documented. */
	public void SaveImage() {Canv.Save();}
	/** Not yet tested and documented. */
	public Image GetImage() {return Canv.GetImage();}
	/** Not yet tested and documented. */
	public Image GetSavedImage() {return Canv.GetSavedImage();}
	/** Not yet tested and documented. */
	public void RestoreImage() {Canv.Restore();}
	/** Not yet tested and documented. */
	public void RestoreImage(Image Im) {Canv.Restore(Im);}
	/** Not yet tested and documented. */
	public Image CreateImage() {return Canv.CreateImage();}
	
	/** Destroy window.
		The window will be closed, and all internal objects representing
		the window will be made not reachable and a garbage collection
		will be forced. A destroyed window can not be reopened.
	*/
	public void Destroy()
	{	Close();
		Frm=null;
		Canv=null;
		System.gc();
	}
	/** Delay.
		Stop all actions in the window for a number of milliseconds.
		The thread behind the window control will sleep.
		@param ms Number of milliseconds for the delay.
	*/
	public void Delay(int ms)
	{	if (ms>0) DelObj.delay(ms);
	}
	/** ***************************************************
	    Colour constants
	
	**************************************************** */
	public static final Color 
		black=Color.black,
		blue=Color.blue,
		gray=Color.gray,
		green=Color.green,
		orange=Color.orange,
		pink=Color.pink,
		red=Color.red,
		yellow=Color.yellow,
		white=Color.white;
	/** Make a new colour.
		It is possible to make a new object representing a colour
		from Red, Green and Blue. The amount of each may be between
		0 and 255.
		@param R the amount of red.
		@param G the amount of green.
		@param B the amount of blue.
		@return A colour object.
	*/
	public static Color MakeColor(int R, int G, int B)
	{return new Color(R,G,B);}
	/** ***************************************************
		Font constants
	
	*****************************************************/
	public static final int
		Plain=Font.PLAIN,
		Bold=Font.BOLD,
		Italic=Font.ITALIC,
		BoldItalic=Font.BOLD|Font.ITALIC,
		ItalicBold=BoldItalic;
	/** Set style for text.
		It is possible to set the style of text in the window,
		use the constants PLAIN,....., plain is default.
		@param S The style, use constants.
	*/	
	public void SetStyle(int S)
	{	Canv.SetStyle(S);}
	/** Set font size.
		It is possible to set the font size of text in the window.
		@param S The font size.
	*/
	public void SetFontSize(int S)
	{	Canv.SetSize(S);}
	/** Set font.
		It is possible to choose a font for text in the window.
		@param S The name of the font.
	*/
	public void SetFont(String S)
	{	Canv.SetFont(S);}
	/** Set font.
		It is possible to choose a font for text in the window.
		@param F The object defining the font.
	*/
	public void SetFont(Font F)
	{	Canv.SetFont(F);}
	/** Get font size.
		It is possible to get the current font size.
		@return Font size.
	*/
	public int GetFontSize() {return Canv.GetSize();}
	/** Get style.
		It is possible to get the current style.
		@return Style (an integer as in the defined style constants).
	*/
	public int GetStyle() {return Canv.GetStyle();}
	/** Get the font.
		@return The name of the current font.
	*/
	public String GetFontName() {return Canv.GetFontName();}
	/** Get the font.
		@return The object representing the current font.
	*/
	public Font GetFont() {return Canv.GetFont();}
	/* ****************************************************
	    Text in window
	
	**************************************************** */
	/** Write a text in the window.
		A text is written in the window with start at current
		text position. Lower left corner of first character.
		@param T The text to write.
	*/
	public void Write(String T)
	{
		Canv.writeText(T);
	}
	/** Erase a text in the window.
		This is the reverse of Write. Erase the same text at the
		same position as in Write.
		@param T The text to erase.
	*/
	public void Erase(String T)
	{
		Canv.Erase(T);
	}
	/** Set current text position.
		This will set the position used by Write and Erase.
	*/
	public void SetPosition(int x, int y)
	{	Canv.SetPosition(x,y);}
	
	/* ****************************************************
	    Drawing in window
	
	**************************************************** */
	/** Draw a line in window.
		Draw a line from point (x0,y0) to the point (x1,y1).
		@param x0 x-coordinate of first point.
		@param y0 y-coordinate of first point.
		@param x1 x-coordinate of last point.
		@param y1 y-coordinate of last point.
	*/
	public void DrawLine(int x0,int y0,int x1,int y1)
	{
		Canv.Line(x0,y0,x1,y1);
	}
	/** Erase a line in window.
		Erase the line from point (x0,y0) to the point (x1,y1).
		@param x0 x-coordinate of first point.
		@param y0 y-coordinate of first point.
		@param x1 x-coordinate of last point.
		@param y1 y-coordinate of last point.
	*/
	public void EraseLine(int x0,int y0,int x1,int y1)
	{
		Canv.ELine(x0,y0,x1,y1);
	}
	/** Draw a rectangle in window.
		Draw a rectangle with corners (x0,y0),(x1,y1).
		@param x0 x-coordinate of left top.
		@param y0 y-coordinate of left top.
		@param x1 x-coordinate of right bottom.
		@param y1 y-coordinate of right bottom.
	*/
	public void DrawRectangle(int x0,int y0,int x1,int y1)
	{	
		Canv.Rectangle(x0,y0,x1,y1);
	}
	/** Erase a rectangle in window.
		Erase the rectangle wiyh corners (x0,y0),(x1,y1).
		@param x0 x-coordinate of left top.
		@param y0 y-coordinate of left top.
		@param x1 x-coordinate of right bottom.
		@param y1 y-coordinate of right bottom.
	*/
	public void EraseRectangle(int x0,int y0,int x1,int y1)
	{
		Canv.ERectangle(x0,y0,x1,y1);
	}
	/** Draw a circle in window.
		Draw a circle with center at (x0,y0)and radius r.
		@param x0 x-coordinate of centre.
		@param y0 y-coordinate of centre.
		@param r The radius of the circle.
	*/
	public void DrawCircle(int x0,int y0,int r)
	{
		Canv.Circle(x0,y0,r);
	}
	/** Erase a circle in window.
		Erase the circle with center at (x0,y0)and radius r.
		@param x0 x-coordinate of centre.
		@param y0 y-coordinate of centre.
		@param r The radius of the circle.
	*/
	public void EraseCircle(int x0,int y0,int r)
	{
		Canv.ECircle(x0,y0,r);
	}
	/** Draw an oval in window.
		Draw an oval with corners (x0,y0),axis a,b.
		@param x0 x-coordinate of "centre".
		@param y0 y-coordinate of "centre".
		@param a length of vertical axis.
		@param b length of horizontal axis.
	*/
	public void DrawOval(int x0,int y0,int a,int b)
	{
		Canv.Oval(x0,y0,a,b);
	}
	/** Erase an oval in window.
		Erase the oval with corners (x0,y0),axis a,b.
		@param x0 x-coordinate of "centre".
		@param y0 y-coordinate of "centre".
		@param a length of vertical axis.
		@param b length of horizontal axis.
	*/
	public void EraseOval(int x0,int y0,int a,int b)
	{
		Canv.EOval(x0,y0,a,b);
	}
	/** Draw a polygon in window.
		Draw a polygon with corners (x0,y0),(x1,y1),.... .
		@param x x-coordinates of the points.
		@param y y-coordinates of the points.
	*/
	public void DrawPolygon(int[]x,int[]y)
	{	Canv.Polygon(x,y);}
	/** Erase a polygon in window.
		Erase the polygon with corners (x0,y0),(x1,y1),.... .
		@param x x-coordinates of the points.
		@param y y-coordinates of the points.
	*/
	public void ErasePolygon(int[]x,int[]y)
	{	Canv.EPolygon(x,y);}
	
	/* ****************************************************
	    Filling areas in window
	
	**************************************************** */
	/** Draw a rectangle area in window.
		Draw a filled rectangle area with corners (x0,y0),(x1,y1).
		The rectangle is filled with the "filler" colour.
		@param x0 x-coordinate of left top.
		@param y0 y-coordinate of left top.
		@param x1 x-coordinate of right bottom.
		@param y1 y-coordinate of right bottom.
	*/
	public void FillRectangle(int x0,int y0,int x1,int y1)
	{
		Canv.FRectangle(x0,y0,x1,y1);
	}
	/** Draw a circle area in window.
		Draw a filled circle area with centre (x0,y0), and radius r.
		The circle is filled with the "filler" colour.
		@param x0 x-coordinate of centre.
		@param y0 y-coordinate of centre.
		@param r radius.
	*/
	public void FillCircle(int x0,int y0,int r)
	{
		Canv.FCircle(x0,y0,r);
	}
	/** Draw an oval area in window.
		Draw an filled oval area with centre (x0,y0), and axis a,b.
		The oval is filled with the "filler" colour.
		@param x0 x-coordinate of centre.
		@param y0 y-coordinate of centre.
		@param a length of vertical axis.
		@param b length of horizontal axis.
	*/
	public void FillOval(int x0,int y0,int a,int b)
	{
		Canv.FOval(x0,y0,a,b);
	}
	/** Draw a polygon area in window.
		Draw a filled polygon area with corners (x0,y0),..... .
		The polygon is filled with the "filler" colour.
		@param x x-coordinates of the corners.
		@param y y-coordinates of the corners.
	*/
	public void FillPolygon(int[] x,int[] y)
	{
		Canv.FPolygon(x,y);
	}
	/** Erase a rectangle area in window.
		Erase the filled rectangle area with corners (x0,y0),(x1,y1).
		@param x0 x-coordinate of left top.
		@param y0 y-coordinate of left top.
		@param x1 x-coordinate of right bottom.
		@param y1 y-coordinate of right bottom.
	*/
	public void EraseFilledRectangle(int x0,int y0,int x1,int y1)
	{
		Canv.EFRectangle(x0,y0,x1,y1);
	}
	/** Erase a circle area in window.
		Erase the filled circle area with centre (x0,y0), and radius r.
		@param x0 x-coordinate of centre.
		@param y0 y-coordinate of centre.
		@param r radius.
	*/
	public void EraseFilledCircle(int x0,int y0,int r)
	{
		Canv.EFCircle(x0,y0,r);
	}
	/** Erase an oval area in window.
		Erase the filled oval area with centre (x0,y0), and axis a,b.
		@param x0 x-coordinate of centre.
		@param y0 y-coordinate of centre.
		@param a length of vertical axis.
		@param b length of horizontal axis.
	*/
	public void EraseFilledOval(int x0,int y0,int a,int b)
	{
		Canv.EFOval(x0,y0,a,b);
	}
	/** Erase a polygon area in window.
		Erase the filled polygon area with corners (x0,y0),..... .
		@param x x-coordinates of the corners.
		@param y y-coordinates of the corners.
	*/
	public void EraseFilledPolygon(int[] x,int[] y)
	{
		Canv.EFPolygon(x,y);
	}
	
	/* ****************************************************
	    Set Line and Fill Attributes
	
	**************************************************** */
	/** Not implemented yet. */
	public void SetLineWidth(int n)
	{
		//Canv.SetLW(n);
	}
	/** Set the window mode to buffered. */
	public void SetBuffered() {Canv.SetBuffered(true);}
	/** Set the window mode to non-buffered, this is the default. */
	public void SetNoBuffered() {Canv.SetBuffered(false);}
	/** Set the pen colour.
		The pen used for drawing is set to the given colour.
		@param n An object representing the colour.
	*/
	public void SetPen(Color n)
	{Canv.SetPen(n);}
	/** Set the filler colour.
		The pen used for filling areas is set to the given colour.
		@param n An object representing the colour.
	*/
	public void SetFiller(Color n)
	{Canv.SetFillColor(n);}
	/** Set the background colour.
		The colour of the background will be changed.
		@param n An object representing the new colour.
	*/
	public void SetBackground(Color n)
	{
		Canv.SetBackground(n);
		Frm.Refresh();
	}
	/** Get the colour of the pen.
		@return An object representing the colour of the current pen.
	*/
	public Color GetPen()
	{return Canv.GetPen();}
	/** Get the colour of the "filler".
		@return An object representing the colour of the current "area filler".
	*/
	public Color GetFiller()
	{return Canv.GetFillColor();}
	/** Get the background colour.
		@return An object representing the background colour.
	*/
	public Color GetBackground()
	{return Canv.GetBackground();}
	/** Clear a rectangular area (set to background).
		@param x0 x-coordinate of left top.
		@param y0 y-coordinate of left top.
		@param x1 x-coordinate of right bottom.
		@param y1 y-coordinate of right bottom.
	*/
	public void ClearRectangle(int x0,int y0,int x1,int y1)
	{Canv.clearRectangle(x0,y0,x1,y1);}
	
	/* ****************************************************
	    Handle images.
	 An image my be handled within a window and placed
	 somewhere on the canvas. An image may be produced
	 in any of these ways images may be produced. A simple
	 example is to read an image from a gif or jpeg file. 
	
	**************************************************** */
	/** Place an image in the window.
		@param ID String used to identify object.
		@param I  An image to place in window
		@param x0 x-coordinate of left top.
		@param y0 y-coordinate of left top.
		@param dx the width of the object.
		@param dy the heiht of the object.
	*/
	public void PlaceImage(String ID,Image I,int x0,int y0,int dx,int dy)
	{Canv.PlaceImage(ID,I,x0,y0,dx,dy);}

	/** Place an image in the window.
		@param ID String used to identify object.
		@param S  the file name of an image to place in window
		@param x0 x-coordinate of left top.
		@param y0 y-coordinate of left top.
		@param dx the width of the object.
		@param dy the heiht of the object.
	*/
	public void PlaceImage(String ID,String S,int x0,int y0,int dx,int dy)
	{Canv.PlaceImage(ID,S,x0,y0,dx,dy);}

	/** Remove an image from the window.
		@param ID String used to identify object.
	*/
	public void RemoveImage(String ID)
	{Canv.RemoveImage(ID);}

	/** Replace an image in the window.
		@param ID String used to identify object.
		@param I  The new image replacing the old.
	*/
	public void ChangeImage(String ID,Image I)
	{Canv.ChangeImage(ID,I);}

	/** Replace an image in the window.
		@param ID String used to identify object.
		@param S  The file name of the image replacing the old.
	*/
	public void ChangeImage(String ID,String S)
	{Canv.ChangeImage(ID,S);}


	
	/* ****************************************************
	    Get Events (Messages)
	
	**************************************************** */
	/** Get an event.
		The first available event in the queue will be returned,
		if no event available null will be returned. This method
		will never wait (block), it will always return.
		@return Available message or null.
	*/
	public Message GetEvent() { return Mess.get();}
	/** Flush all event queues.
		All events are removed from all queues.
	*/
	public void FlushEvents()
	{	Mess=new MessageQueue();
		Canv.FlushMouse();
		Canv.FlushKey();
	}
	/** Enable mouse event queue.
		An empty queue is created and all mouse events will now
		be saved in this.
	*/
	public void EnableMouse() {Canv.EnableMouse();}
	/** Disable mouse.
		The mouse event queue will be removed and no longer used.
	*/
	public void DisableMouse() {Canv.DisableMouse();}
	/** Flush mouse queue.
		The mouse event queue is emptied.
	*/
	public void FlushMouse() {Canv.FlushMouse();}
	/** Get a mouse event.
		If the mouse event queue is not empty the first event is
		returned as a MouseMessage. If the mouse is not enabled this
		queue will be empty. If empty a null will be returned.
		@return An available message or null.
		@see MouseMessage Description of the message.
	*/
	public Message GetMouseButton() { return Canv.GetMouseButton();}
	/** Enable key event queue.
		An empty queue is created and all key events will now
		be saved in this. All actions on the keyboard creates an event.
		A normal typed key may cause three events, key pressed, key released
		and key typed. Only character keys will have the third event type.
	*/
	public void EnableKey() {Canv.EnableKey();}
	/** Disable key.
		The key event queue will be removed and no longer used.
	*/
	public void DisableKey() {Canv.DisableKey();}
	/** Flush key queue.
		The key event queue is emptied.
	*/
	public void FlushKey() {Canv.FlushKey();}
	/** Get a key event.
		If the key event queue is not empty the first event is
		returned as a KeyMessage. If the key is not enabled this
		queue will be empty. If empty a null will be returned.
		@return An available message or null.
		@see KeyMessage Description of the message.
	*/
	public Message GetKey() { return Canv.GetKey();}
}
/************ end of w ***********************************/

/***********************************************************
/*	! User Event Handling
	!
	!*************************************/
class MessageQueue
{	class MNod
	{	MNod prv,nxt;
		Message Info;
		MNod(Message M)
		{	if (last==null)
				{	last=this;
					first=this;
					Info=M;
				}
			else
				{	last.nxt=this;
					prv=last;
					last=this;
					Info=M;
				}
		}
		Message get()
		{	if (first==null)
				return null;
			else
				{	first=first.nxt;
					if (first!=null) first.prv=null;
					else last=null;
					return Info;
				}
		}
	}
	MNod first,last;
	MessageQueue()
	{
		first=null;
		last=null;
	}
	void Put(Message M)
	{	new MNod(M); }
	Message get()
	{if (first==null) return null; else return first.get();}
}
	
/***********************************************************/

class WFrame extends Frame
{


  WFrame(int width, int height, String T)
  {
    super(T);
    setSize(width,height);
  }
  
  void Open()
  {	pack();
  		validate();
  		setVisible(true);
  }
  void Refresh()
  {	pack();
  		validate();
  		setVisible(true);
  		show();
  }
  void Close()
  {	setVisible(false);
  }
}
/************ end of WFrame ***********************************/
class WCanvas extends Canvas
{
  private int X,Y,Width,Height;
  private Color Pen,BGC,FillC;
  private boolean Buffered;
  private Font CurFont;
  private String FontName;
  private int Style,FontSize;

  private MouseHandler Mus;
  private KeyHandler Tang;
  
  /*************** TEST **********/
  private Image Screen;
  private Graphics GraphTool;
  private Image Saved;
  private Set Images;

  WCanvas(int width, int height,MessageQueue M,Color BC)
  {
    super();
    setSize(width,height);
    Buffered=false;
    BGC=BC;
    Width=width;
    Height=height;
    setBackground(BGC);
    	
    Mus=new MouseHandler(M);
    addMouseListener(Mus);
    Tang=new KeyHandler(M);
    addKeyListener(Tang);

    Pen = Color.black;
    FillC=BGC;
    Images=new Set();
  }
  
  void Open(Color C)
  {	if (C!=null) {setBackground(C); BGC=C;};
  		Screen=createImage(getSize().width,getSize().height);
  		GraphTool=Screen.getGraphics();
  		GraphTool.setColor(Pen);
  		CurFont=getGraphics().getFont();
  		Style=Font.PLAIN;
  		FontSize=CurFont.getSize();
  		FontName=CurFont.getFamily();
  		paint(GraphTool);
//      FRectangle(1,1,Width-1,Height-1);
  }
 
	void Display()
	{if (isShowing()) repaint();}
	
	//{if (isShowing()) paint(getGraphics());}
	
	void Flush()
	{if (isShowing()) repaint();}
	
	void SetBuffered(boolean B) {Buffered=B;}
	
	
	void Circle(int u, int v, int r)
	{	GraphTool.drawOval(u-r,v-r,2*r,2*r);
		if (!Buffered) Flush();
	}
	
	void Oval(int x1, int y1, int a, int b)
	{	GraphTool.drawOval(x1,y1,a,b);
		if (!Buffered) Flush();
	}
	
	void Rectangle(int x1, int y1, int x2, int y2)
	{	GraphTool.drawRect(x1,y1,x2-x1,y2-y1);
		if (!Buffered) Flush();
	}
	
	void Line(int x1, int y1, int x2, int y2)
	{	GraphTool.drawLine(x1,y1,x2,y2);
		if (!Buffered) Flush();
	}
	
	void Polygon(int[]x,int[]y)
	{	GraphTool.drawPolygon(x,y,x.length);
		if (!Buffered) Flush();
	}
	
	
	void ECircle(int x1, int y1, int r)
	{	Eraser();
		Circle(x1,y1,r);
		RestorePen();
	}
	
	void EOval(int x1, int y1, int a, int b)
	{	Eraser();
		Oval(x1,y1,a,b);
		RestorePen();
	}
	
	void ERectangle(int x1, int y1, int x2, int y2)
	{	Eraser();
		Rectangle(x1,y1,x2,y2);
		RestorePen();
	}
	
	void ELine(int x1, int y1, int x2, int y2)
	{	Eraser();
		Line(x1,y1,x2,y2);
		RestorePen();
	}
	
	void EPolygon(int[] x, int[] y)
	{	Eraser();
		Polygon(x,y);
		RestorePen();
	}
	
	void FCircle(int u, int v, int r)
	{	Filler();
		GraphTool.fillOval(u-r,v-r,2*r,2*r);
		if (!Buffered) Flush();
		RestorePen();
	}
	
	void FOval(int x1, int y1, int a, int b)
	{	Filler();
		GraphTool.fillOval(x1,y1,a,b);
		if (!Buffered) Flush();
		RestorePen();
	}
	void FPolygon(int[]x,int[]y)
	{	Filler();
		GraphTool.fillPolygon(x,y,x.length);
		if (!Buffered) Flush();
		RestorePen();
	}
	
	void FRectangle(int x1, int y1, int x2, int y2)
	{	Filler();
		GraphTool.fillRect(x1,y1,x2-x1,y2-y1);
		if (!Buffered) Flush();
		RestorePen();
	}
	
	void EFCircle(int u, int v, int r)
	{	Eraser();
		GraphTool.fillOval(u-r,v-r,2*r,2*r);
		if (!Buffered) Flush();
		RestorePen();
	}
	
	void EFOval(int x1, int y1, int a, int b)
	{	Eraser();
		GraphTool.fillOval(x1,y1,a,b);
		if (!Buffered) Flush();
		RestorePen();
	}
	
	void EFPolygon(int[]x, int[]y)
	{	Eraser();
		GraphTool.fillPolygon(x,y,x.length);
		if (!Buffered) Flush();
		RestorePen();
	}
	
	void EFRectangle(int x1, int y1, int x2, int y2)
	{	Eraser();
		GraphTool.fillRect(x1,y1,x2-x1,y2-y1);
		if (!Buffered) Flush();
		RestorePen();
	}
	
	void SetPen(Color C)
	{	Pen=C;
		GraphTool.setColor(C);
		if (isShowing()) getGraphics().setColor(C);
	}
	
	void Eraser()
	{	GraphTool.setColor(BGC);
		if (isShowing()) getGraphics().setColor(BGC);
	}
	
	void Filler()
	{	GraphTool.setColor(FillC);
    if (isShowing()) getGraphics().setColor(FillC);
	}
	
	void RestorePen()
	{	GraphTool.setColor(Pen);
    if (isShowing()) getGraphics().setColor(Pen);
	}
	
	void SetBackground(Color C)
	{	if (C!=null) {setBackground(C); BGC=C;};
		repaint();
  		Screen=createImage(getSize().width,getSize().height);
  		GraphTool=Screen.getGraphics();
	}
	
	void SetFillColor(Color C)
	{	FillC=C;}
	
	void SetPosition(int x0, int y0)
	{	X=x0;
		Y=y0;
	}
	
	void SetStyle(int I)
	{	Style=I; changefont();}
	
	void SetSize(int I)
	{	FontSize=I; changefont();}
	
	void SetFont(String S)
	{	FontName=S; changefont();}
	
	void SetFont(Font F)
	{	CurFont=F;
		Style=F.getStyle(); FontSize=F.getSize(); FontName=F.getFamily();
		GraphTool.setFont(CurFont);
    	if (isShowing()) getGraphics().setFont(CurFont);
	}
	
	int GetStyle() {return Style;}
	int GetSize() {return FontSize;}
	String GetFontName() {return FontName;}
	Font GetFont() {return CurFont;}
	
	void changefont()
	{	CurFont=new Font(FontName,Style,FontSize);
		GraphTool.setFont(CurFont);
    	if (isShowing()) getGraphics().setFont(CurFont);
	}
 
  Color GetPen()
  { return Pen; }
  
  Color GetFillColor()
  {return FillC;}
 
  Color GetBackground()
  {return BGC;}

	
	public void update(Graphics g)
	{	if(Screen!=null) g.drawImage(Screen,0,0,BGC,this);
		Images.Map(new UpDateIm(g,this));
	}
	
	
	public synchronized void paint(Graphics g)
	{ update(g);}

/*	void ScreenUpdate()
	{	Image t;
		t=Screen;
		Screen=createImage(getSize().width,getSize().height);
		if (Screen!=null) 
		{	GraphTool=Screen.getGraphics();
			if (t!=null) GraphTool.drawImage(t,0,0,BGC,this);
		}
	}
*/
	
	void Save()
	{Display(); Saved=Screen;}
	Image GetImage() {Display(); return Screen;}
	Image GetSavedImage() {return Saved;}
	void Restore()
	{Screen=Saved; paint(getGraphics());}
	void Restore(Image I)
	{Screen=I; paint(getGraphics());}
	Image CreateImage() {return createImage(getSize().width,getSize().height);}

  void clear()
  {
    GraphTool.clearRect(0,0,
        getSize().width,getSize().height);
      if (isShowing())
        getGraphics().clearRect(0,0,
          getSize().width,getSize().height);
  }
   void clearRectangle(int x1, int y1, int x2, int y2)
  {
    GraphTool.clearRect(x1,y1,x2-x1,y2-y1);
      if (isShowing())
        getGraphics().clearRect(x1,y1,x2-x1,y2-y1);
  }
  

  void writeText(String txt)
  {
    GraphTool.drawString(txt,X,Y);
    if (!Buffered) Flush();
    /*if (isShowing())
      {getGraphics().drawString(txt,X,Y); paint(getGraphics());}*/
  }
  void Erase(String T)
  {	Eraser();
  		writeText(T);
  		RestorePen();
  }
  /************ Event handling ***************************/
  void EnableMouse() {Mus.Enable();}
  void DisableMouse() {Mus.Disable();}
  void FlushMouse() {Mus.Flush();} 
  MouseMessage GetMouseButton() { return Mus.Get(); }
  
  void EnableKey() {Tang.Enable();}
  void DisableKey() {Tang.Disable();}
  void FlushKey() {Tang.Flush();}
  KeyMessage GetKey() { return Tang.Get(); }
  
  /* ****************** Image handling **************** */

  void PlaceImage(String ID,String S,int x,int y,int v,int h)
  {Images.Insert(new Paket(S,x,y,v,h,ID));}

  void PlaceImage(String ID,Image I,int x,int y,int v,int h)
  {Images.Insert(new Paket(I,x,y,v,h,ID));}

  void RemoveImage(String ID)
  {Images.Delete(new Paket(ID));}

  void ChangeImage(String ID,String S)
  {  Paket P;
     P=(Paket)Images.SearchElement(new Paket(ID));
     P.ChangeImage(S);
  }

  void ChangeImage(String ID,Image I)
  {  Paket P;
     P=(Paket)Images.SearchElement(new Paket(ID));
     P.ChangeImage(I);
  }

  class Paket extends Element
  {  Image TheImage;
     String Id;
     int LUX,LUY,Width,Height;

     Paket(Image I,int x,int y,int v,int h, String id)
     {  TheImage=I; Id=id;
        LUX=x; LUY=y; Width=v; Height=h;
     }

     Paket(String S,int x,int y,int v,int h, String id)
     {  TheImage=getToolkit().getImage(S); Id=id;
        LUX=x; LUY=y; Width=v; Height=h;
     }

     Paket(String ID){Id=ID;}

     void ChangeImage(Image I){TheImage=I;}
     void ChangeImage(String S){TheImage=getToolkit().getImage(S);}

     void paint(Graphics g, WCanvas C)
     {  if(TheImage!=null)
        {g.drawImage(TheImage,LUX,LUY,Width,Height,BGC,C);}
     }

     public boolean Equal(Element E)
     {  return (E instanceof Paket)&& Id.equals(((Paket)E).Id);
     }
     public boolean Key(Element E) {return Equal(E);}
     public boolean Before(Element E){return true;}
     public boolean After(Element E){return true;}

  }

  class UpDateIm extends Body
  {  Graphics G; WCanvas C;
     UpDateIm(Graphics gg,WCanvas cc){G=gg; C=cc;}
     public void Perform(Element E)
     {if (E instanceof Paket)((Paket)E).paint(G,C);}
  }


}
/************ end of WCanvas ***********************************/

class MouseHandler extends MouseAdapter
{	MessageQueue MessQ,GlobMQ;
	boolean Enabled;
	MouseHandler(MessageQueue M)
	{	MessQ=new MessageQueue();
		GlobMQ=M;
	}
	public void mousePressed(MouseEvent E)
	{	MouseMessage M;
		int K;
		K=E.getModifiers();
		if (K==0||K==16) K=1;
		else
		if (K==8) K=2;
		else
		if (K==4) K=3;
		M=new MouseMessage(2,K,E.getX(),E.getY(),E.getWhen());
		if (Enabled) MessQ.Put(M);
		GlobMQ.Put(M);
	}
	public void mouseReleased(MouseEvent E)
	{	MouseMessage M;
		int K;
		K=E.getModifiers();
		if (K==0||K==16) K=1;
		else
		if (K==8) K=2;
		else
		if (K==4) K=3;
		M=new MouseMessage(1,K,E.getX(),E.getY(),E.getWhen());
		if (Enabled) MessQ.Put(M);
		GlobMQ.Put(M);
	}
	void Enable() {Enabled=true;}
	void Disable() {Enabled=false;}
	void Flush() {MessQ=new MessageQueue();}
	MouseMessage Get()
	{	if (MessQ != null) return (MouseMessage) MessQ.get();
		else return null;
	}
}
class KeyHandler extends KeyAdapter
{	MessageQueue MessQ,GlobMQ;
	boolean Enabled;
	KeyHandler(MessageQueue M)
	{	MessQ=new MessageQueue();
		GlobMQ=M;
	}
	public void keyTyped(KeyEvent E)
	{	KeyMessage M;
		char K;
		K=E.getKeyChar();
		M=new KeyMessage(K,-1,E.getWhen(),KeyMessage.Typed);
		if (Enabled) MessQ.Put(M);
		GlobMQ.Put(M);
	}
	public void keyPressed(KeyEvent E)
	{	KeyMessage M;
		int K;
		K=E.getKeyCode();
		M=new KeyMessage('\00',K,E.getWhen(),KeyMessage.Pressed);
		if (Enabled) MessQ.Put(M);
		GlobMQ.Put(M);
	}
	public void keyReleased(KeyEvent E)
	{	KeyMessage M;
		int K;
		K=E.getKeyCode();
		M=new KeyMessage('\00',K,E.getWhen(),KeyMessage.Released);
		if (Enabled) MessQ.Put(M);
		GlobMQ.Put(M);
	}
	void Enable() {Enabled=true;}
	void Disable() {Enabled=false;}
	void Flush() {MessQ=new MessageQueue();}
	KeyMessage Get()
	{	if (MessQ != null) return (KeyMessage) MessQ.get();
		else return null;
	}
}

class DelayObject extends Thread
{
  void delay(int mSec)
  {
    try
    {
      sleep(mSec);
    }
    catch (InterruptedException e) {}
  }
}

