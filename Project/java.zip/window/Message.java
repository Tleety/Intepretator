package window;
/*
 !***************************************************************
 !		Revision history
 !	0.1	970901 
 !
 !***************************************************************
*/
/**	 User Event Handling.
	This class is used for representing events. This
	class is empty, and its subclasses should be used.
	@author G�ran Fries
	@version 0.1
*/
public class Message
{
}
	
	

/***********************************************************/
