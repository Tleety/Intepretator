package komp;
public class Lexeme
{
}
