package komp;
import struct.*;
/* ******************************************************************
*						Operator Precedence
*
*	This is an abstract, general type for the implementation of
*	operator precedence in a compiler. It contains the general
*	structure and to implement a real operator precedence compiler
*	a subtype of this should be implemeted.
*	In the package together with this type there are a number of
*	other abstract types used by the op.prec. type. 
*	Token is the type of entities read from the input stream.
*	Op with the two subtypes Operand and Operator are the types
*	of the objects handled by the operator precedence.
*	There are also two other types, Interface and Control. Objects
*	of these types has two be sent as parameters when the Operator
*	Precedence object is created. Interface is used to read the input
*	stream and get a Token.
*	Control is the type of an object containing the action matrix, and
*	additional actions.
*	The OperatorPrecedence needs a method MakeOp that translates a Token
*	to an Op (Operand or Operator).
*	This general type handles a number of common actions, and has an
*	"escape" to other user defined actions.
*******************************************************************/
public abstract class OperatorPrecedence
{	/* ***************************************************
	* An internal stack type is defined
	****************************************************/
	private class Stack
	{	class Node
		{	Element Inf;
			Node Next;
			public Node(Element E, Node N)
			{Inf=E; Next=N;}
			
		}
		Node Contents;
		public void Push(Element E)
		{Contents=new Node(E,Contents);}
		public Element Pop()
		{	Node D;
			if (Contents==null) return null;
			else {D=Contents; Contents=Contents.Next; return D.Inf;}
		}
		public Element Top()
		{	if (Contents==null) return null;
			else return Contents.Inf;
		}
	}
	/* ***************************************************/
	private Stack Operands=new Stack(), Operators=new Stack();
	private Op CurrentOp;
	private Lexeme CurrentToken;
	private Interface Com;
	protected Control Ctrl;
	
	public OperatorPrecedence(Interface I, Control C)
	{	Com=I;
		Ctrl=C;
	}
	/* ***************************************************/
	public Operand GetOperand() {return (Operand)(Operands.Pop());}
	public Operand GetTopOperand() {return (Operand)(Operands.Top());}
	public void PutOperand(Operand S) {Operands.Push(S);}
	public Operator GetOperator(){return (Operator)(Operators.Pop());}
	public Operator GetTopOperator() {return (Operator)(Operators.Top());}
	public void PutOperator(Operator S) {Operators.Push(S);}
	public boolean Empty() {return Operands.Top()==null;}
	
	public Op GetCurrentOp(){return CurrentOp;}
	public void SetCurrentOp(Op T){CurrentOp=T;}
	public void SetCurrentToken(Lexeme T){CurrentToken=T;}
	
	
	public final Lexeme Translate(Lexeme T)
	{	boolean Finished=false;
		char Action;
		Operator Q;
		if(T==null){CurrentToken=GetToken();}else{CurrentToken=T;}
		CurrentOp=MakeOp(CurrentToken);
		Operators.Push(new Bottom());
		while (!Finished)
		{	if (CurrentOp instanceof Operand)
				{	Operands.Push(CurrentOp);
					CurrentToken=GetToken();
					CurrentOp=MakeOp(CurrentToken);
				}
			else
			if (CurrentOp instanceof Operator)
				{	int 	i=((Operator)(Operators.Top())).GetIndex(),
							j=CurrentOp.GetIndex();
					Action=GetAction(i,j);
					switch (Action)
					{	case 'S': Operators.Push(CurrentOp);
									 CurrentToken=GetToken();
									 CurrentOp=MakeOp(CurrentToken);
									 break;
						case 'U': Q=(Operator)(Operators.Pop());
									 Q.Exec();
									 break;
						case 'P': Operators.Pop();
									 CurrentToken=GetToken();
									 CurrentOp=MakeOp(CurrentToken);
									 break;
						case 'A': Finished=true;
									 break;
						case 'E': Error(i,j);
									 break;
						default:  OtherAction(Action,this);
									 break;
					}
				}
			else ;
		}
		return CurrentToken;
	}
	
	/*******************************************************************
	
	*******************************************************************/
	class Bottom extends Operator
	{	public int GetIndex() {return 0;}
		public void Exec() {}
		public void Prolog(Op P) {}
	}
	public abstract Op MakeOp(Lexeme Tok);
	
	public Lexeme GetToken() {return Com.GetToken();}
	
	char GetAction(int i,int j) {return Ctrl.GetAction(i,j);}
	
	void OtherAction(char A,OperatorPrecedence Q) {Ctrl.OtherAction(A,Q);}
	
	void Error(int I,int J)
	{System.out.println("Error Action matrix("+I+","+J+")");}
	
}
