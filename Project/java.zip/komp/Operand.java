package komp;
import struct.*;
public abstract class Operand extends Op
{	public abstract void Address();
	public void Write() {System.out.println("%%%");}
}

