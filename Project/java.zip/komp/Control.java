package komp;
public abstract class Control
{
	public abstract char GetAction(int i,int j);
	public abstract void OtherAction(char A,OperatorPrecedence Q);
}
