package komp;
public abstract class Interface
{
	public abstract Lexeme GetToken();
}
