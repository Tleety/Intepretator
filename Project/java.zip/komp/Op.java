package komp;
import struct.*;
public abstract class Op extends Element
{	public abstract int GetIndex();
	public boolean Equal(Element E) {return this==E;}
	public boolean Key(Element E) {return Equal(E);}
	public boolean Before(Element E) {return true;}
	public boolean After(Element E) {return true;}
}
