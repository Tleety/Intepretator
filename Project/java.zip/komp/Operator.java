package komp;
public abstract class Operator extends Op
{	public abstract void Exec();
	public abstract void Prolog(Op P);
}
