package struct;
public abstract class NodeAction
{	protected int X=0,Y=0;
	public abstract void DoAction(Element E);
	public void SetPosition(int x, int y) {X=x; Y=y;}
}
