package struct;
/** ****************************************************
	This is an abstract class implementing the common
	properties of all elements to be handled in structures
	like lists, sets,...
	@author G�ran Fries
	@version 0.1
***************************************************** */
import window.*;
public abstract class Element
{	
	/** Defines equality between elements. Two elements may be
		different but still be regarded as the same element.
		This is defined by equal.
		@param E The element to be compared to this current element
		@return true if equal in our meaning, else false.
	*/
	public abstract boolean Equal(Element E);
	/** Defines the concept "having the same key". Used
		by search routines searching for all elements with a
		given key.
		@param E An element containing the key to be searched for.
		@return true if having the same key, else false.
	*/
	public abstract boolean Key(Element E);
	/** Defines the order for sorting. Elements are before or after
		other elements. A default is defined: all elements are both
		before and after all other elements. If sorting is to be used
		this should be redifined!
		@param E The element to be compared to this current element
		@return true if before in our meaning, else false.
	*/
	public boolean Before(Element E) {return true;}
	/** Defines the order for sorting. Elements are before or after
		other elements. A default is defined: all elements are both
		before and after all other elements. If sorting is to be used
		this should be redifined!
		@param E The element to be compared to this current element
		@return true if after in our meaning, else false.
	*/
	public boolean After(Element E) {return true;}
	/** This is used to give a short id of an element. Default is 
		the string "#". Should be redifined if used!
	*/
	public String GetId(){return "#";}
	/** This is used to "show" an element. Default is to print out
		*** on standard output. Should be redifined if used!
	*/
	public void Show() {System.out.println("***");}
	/** This is used to "show" an element. Default is to print out
		*** on standard output. Should be redifined if used!
		@param F	A window object may be used for output.
	*/
	public void Show(w F) {System.out.println("***");}
}
