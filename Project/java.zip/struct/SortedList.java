package struct;
/** ********************************************
	This class implements a sorted list of Element,
	elements with a bit more structure than 
	ordinary of type Object. In order to be sorted
	the elements should have a decent definition of
	before and after. A SortedList is also a List with
	all its properties.
	All lists are ordered sequences of elements. A normal
	list is ordered by the order of the insertions, but
	the sorted list is ordered by the internal properties
	of its elements(Before/After is used).
	@author G�ran Fries
	@version 0.1
********************************************* */
public class SortedList extends List
{	
	private class Snode extends Node
	{	Snode(Element E, Snode N) {super(E,N);}
		Snode(Element E, Node N) {super(E,N);}
		Snode Insort(Element E)
		{	if (Rest==null) {Rest=new Snode(E,null); return this;}
			else
			/*if (E.Before(Rest.GetInfo())) return new Snode(E,this);*/
			if (E.Before(Rest.GetInfo())){ Rest=new Snode(E,Rest);return this;}
			else {Rest=((Snode)Rest).Insort(E); return this;}
		}
	}
	/** Constructor without parameters will create 
		an empty sorted list. */
	public SortedList() {Contents=null;}
	/** Constructor with one parameter creates a sorted list
		containing one element.
		@param E an element to be put into the list
	*/
	public SortedList(Element E) {Contents=new Snode(E,null);}
	/** Insert an element into the list, it will be put at the
		right place according to Before/After. The current list will
		be changed and no new list will be created.
		@param E Element to be inserted.
	*/
	public void Insert(Element E)
	{	if (Contents==null) Contents=new Snode(E,null);
		else
		if (E.Before(Contents.GetInfo())) Contents=new Snode(E,(Snode)Contents);
		else Contents=((Snode)Contents).Insort(E);
	}
}
