
/* 
 * 
 * Author G�ran Fries
 *
 *---------------------------------------------------------------
 !***************************************************************
 !		Revision history
 !	0.1	971220 Preliminary
 ! 0.9	980825 For test purposes, still under construction
 ! 1.0	030409 First release
 ! 1.1	030508
 !
 !***************************************************************
*---------------------------------------------------------------
*/
package struct;
import window.*;
class Picture
{	w W;
	D writer;
	List Places,Arcs;
	boolean Opened=false;
	NodeAction TheAction;
	/**********************************************/
	abstract class PictElem extends Element
	{	abstract void Draw();
		abstract boolean Interact(int x,int y,NodeAction A);
	}
	/**********************************************/
	class Place extends PictElem
	{	int x,y,r,Prior;
		Element Info;
		String Id;
		Place(int x0, int y0, int r0, int p, Element E)
		{	x=x0;
			y=y0;
			r=r0;
			Prior=p;
			Info=E;
			Id=E.GetId();
		}
		boolean Hit(int u, int v)
		{return (x-u)*(x-u)+(y-v)*(y-v)<=r*r;}
		void Draw()
		{	W.SetFiller(w.white);
			W.FillCircle(x,y,r);
			W.SetPosition(x-r/2,y+r/2);
			W.Write(Id);
		}
		
		void WriteInfo()
		{
		}
		boolean Interact(int u,int v,NodeAction Act)
		{	if (Hit(u,v))
				{	W.SetFiller(w.red);
					W.FillCircle(x,y,r);
					W.SetPosition(x-r/2,y+r/2);
					W.Write(Id);
					W.SetFiller(w.white);
					if (Act==null)
					{	if (Info instanceof Set) {((Set) Info).Map(new A());}
						else {Info.Show(W); }
					}
					else
					{	if (Info instanceof Set) {((Set) Info).Map(new AA(Act));}
						else {Act.DoAction(Info);}
					}
					W.Delay(1000);
					W.FillCircle(x,y,r);
					W.SetPosition(x-r/2,y+r/2);
					W.Write(Id);
					return true;
				}
			else return false;
		}
		public boolean Equal(Element E)
		{	if (!(E instanceof Place)) return false;
			else
			return 	(x==((Place) E).x)&&(y==((Place) E).y);
		}
		public boolean Before(Element E) {return true;}
		public boolean After(Element E) {return true;}
		public boolean Key(Element E) {return Equal(E);}
	}
	/**********************************************/
	class Arc extends PictElem
	{	int x1,x2,y1,y2;
		Arc(int x,int y,int u,int v)
		{	x1=x;
			x2=u;
			y1=y;
			y2=v;
		}
		void Draw() {W.DrawLine(x1,y1,x2,y2);}
		boolean Interact(int x,int y,NodeAction Act){return true;}
		public boolean Equal(Element E)
		{	if (!(E instanceof Arc)) return false;
			else
			return 	(x1==((Arc) E).x1)&&(x2==((Arc) E).x2)&&
						(y1==((Arc) E).y1)&&(y2==((Arc) E).y2);
		}
		public boolean Before(Element E) {return true;}
		public boolean After(Element E) {return true;}
		public boolean Key(Element E) {return Equal(E);}
	}
	/**********************************************/
	class D extends Body
	{	D(){}
		public void Perform(Element E)
		{	if (E instanceof PictElem) {((PictElem) E).Draw();}
			else {}
		}
		public Element eval(Element E) {return null;}
	}
	class C extends Body
	{	boolean done;
		int X,Y;
		NodeAction Act;
		C() {X=0; Y=0; Act=null;}
		void SetXY(int u,int v) {X=u; Y=v;}
		void SetAction(NodeAction N) {Act=N;}
		void Clear() {done=false; Act=null;}
		public void Perform(Element E)
		{	if (done) {}
			else
			if (E instanceof PictElem)
			     {done=((PictElem) E).Interact(X,Y,Act);}
			else {}
		}
		public Element eval(Element E) {return null;}
	}
	class A extends Body
	{	A(){}
		public void Perform(Element E)
		{	E.Show(W);}
		public Element eval(Element E) {return null;}
	}
	class AA extends Body
	{	NodeAction Ac;
		AA(NodeAction a){Ac=a;}
		public void Perform(Element E)
		{	Ac.DoAction(E);}
		public Element eval(Element E) {return null;}
	}
	/**********************************************/
	public Picture()
	{	writer=new D();}
	/**********************************************/
	public void Open()
	{	W=new w(400,400,"Picture",null);
		Buttons();
		Places=new List();
		Arcs=new List();
		Opened=true;
	}
	public void Open(String S)
	{	W=new w(400,400,S,null);
		Buttons();
		Places=new List();
		Arcs=new List();
		Opened=true;
	}
	public void Open(int x,int y,String S)
	{	W=new w(x,y,S,null);
		Buttons();
		Places=new List();
		Arcs=new List();
		Opened=true;
	}
	public void ReOpen()
	{	if (Opened) {}
		else
		if (W!=null)
			{	W.Open(null);
				Places=new List();
				Arcs=new List();
				Opened=true;
			}
		else {Open();}
	}
	public void Close()
	{	if (Opened) {Opened=false; W.Close();}}
	
	public void Destroy()
	{	if (Opened) {Opened=false; W.Destroy(); W=null;}}
	/*****/
	public void PutPlace(int x,int y,int r,int p,Element E)
	{	Place P;
		P=new Place(x,y,r,p,E);
		Places=new List(P,Places);
	}
	public void PutArc(int x1,int y1,int x2,int y2)
	{	Arc A;
		A=new Arc(x1,y1,x2,y2);
		Arcs=new List(A,Arcs);
	}
	public void Draw()
	{	if (Opened)
		{	Arcs.Map(writer);
			Places.Map(writer);
		}
	}
	public void Interact()
	{	MouseMessage M;
		boolean fin,quit;
		C B;
		B=new C();
		fin=false;
		quit=false;
		W.EnableMouse();
		while(!fin)
		{	M=(MouseMessage)W.GetMouseButton();
			if (M==null) {}
			else
			if ((M.GetButton()==M.Left)&&(M.GetDirection()==M.Pressed))
				{ int x,y;
					x=M.Getx();
					y=M.Gety();
					if(HitOK(x,y)){fin=true; quit=true;}
					else
					if(HitFreeze(x,y)){fin=true; quit=false;}
					else
					{	B.SetXY(x,y);
						Places.Map(B);
						B.Clear();
					}
				}
			else
			if ((M.GetButton()==M.Right)&&(M.GetDirection()==M.Pressed))
				{ int x,y;
					x=M.Getx();
					y=M.Gety();
					B.SetXY(x,y);
					if (TheAction!=null)
					{	TheAction.SetPosition(x,y);
						B.SetAction(TheAction);
						Places.Map(B);
						B.Clear();
					}
				}
			else {}
			W.Delay(20);
		}
		if(quit) {W.Destroy();}
		else {W.ClearRectangle(10,10,56,51); W.SetPosition(10,20); W.Write("Frozen");}
	}
	public void RegisterAction(NodeAction Nd) {TheAction=Nd;}
	
	private void Buttons()
	{	W.DrawRectangle(10,10,30,30);
		W.SetPosition(12,26); W.Write("OK");
		W.DrawRectangle(10,32,55,50);
		W.SetPosition(12,46); W.Write("Freeze");
	}
	private boolean HitOK(int x,int y) {return x>=10&&x<=30&&y>=10&&y<=30;}
	private boolean HitFreeze(int x,int y) {return x>=10&&x<=55&&y>=32&&y<=50;}
}
