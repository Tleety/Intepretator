package struct;
/** ********************************************
	This class implements a queue of Element,
	elements with a bit more structure than 
	ordinary of type Object. In order to be able
	to put queues as elements in other structures, the
	Queue is also of type Element.
	@author G�ran Fries
	@version 0.1
***********************************************/
public class Queue extends Element
{	private Node Contents,Rear;
	private int Card;
	private class Node
	{	private Element Info;
		private Node Rest;
		Node(Element E) {Info=E; Rest=null;}
		Element GetInfo() {return Info;}
		Node GetRest() {return Rest;}
		void SetRest(Node N) {Rest=N;}
	}
	
	public Queue() {Contents=null; Rear=null; Card=0;}
	
	/** Take out and return the front element in the queue.
		Notice that the first element will be removed from the queue.
		@return The first element of the queue.
	*/
	public Element TakeOut()
	{	if (Contents!=null)
			{	Element E=Contents.GetInfo();
				Contents=Contents.GetRest();
				Card=Card-1;
				if (Contents==null) Rear=null;
				return E;
			}
		else return null;
	}
	/** Queue an element.
		The given element is put at the end of the queue.
		@param E Element to queue.
	*/
	public void Insert (Element E)
	{	if (Contents==null)
			{Contents=new Node(E); Rear=Contents;}
		else
			{Node N; N=new Node(E); Rear.SetRest(N); Rear=N;}
		Card=Card+1;
	}
	
	/** Tests for empty queue.
		@return true if the queue is empty else false.
	*/
	public boolean Empty() {return Contents==null;}
	
	/** Get size of queue.
		@return The size of the queue.
	*/
	public int Cardinal() {return Card;}
	
	/* *********** Element methods *********** */
	
	/** Used to define when two queue are equal.
		Such a definition has to be included in all objects
		of type Element. Two queues are never equal.
		@param E The queue to compare to.
		@return false always.
	*/
	public boolean Equal(Element E)
	{	return false;}
	/** Used to define when two lists are having the same key.
		Such a definition has to be included in all objects
		of type Element. The key concept is not used for queues, two queues
		are regarded to have the same key only if the queues are equal.
		@param E The list to compare to.
		@return false always
	*/
	public boolean Key(Element E) {return Equal(E);}

}
