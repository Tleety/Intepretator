package struct;
/** ********************************************
	This class implements a set of Element,
	elements with a bit more structure than 
	ordinary of type Object. In order to be able
	to put sets as elements in other structures, the
	Set is also of type Element.
	@author G�ran Fries
	@version 0.1
***********************************************/
public class Set extends Element
{	/* ********** Internal Part ************ */
	/* ********** Internal data ************ */
	private Node Contents;
	private int Card;
	private Picture Pict;
	private int Bredd=400,H�jd=400,Radie=10;
	private int B,H;
	private boolean[][] PM;
	/* ********** Internal classes ********* */
	private class Node
	{	private Element Info;
		private Node Resten;
		Node(Element E, Node N) {Info=E; Resten=N;}
		Element GetInfo() {return Info;}
		Node GetResten() {return Resten;}
		boolean Insert(Element E) 
		{	if (Info.Equal(E)) {return false;}
			else
			if (Resten==null) {Resten=new Node(E,null); Card=Card+1; return true;}
			else return Resten.Insert(E);
		}
		void Delete(Element E)
		{	if (Resten==null) {}
			else
			if (Resten.Info.Equal(E)) {Resten=Resten.GetResten(); Card=Card-1;}
			else Resten.Delete(E);
		}
		void Iterate(Body B)
		{	B.Perform(Info);
			if (!B.Condition()&&Resten!=null) Resten.Iterate(B);
		}
		
		Element Get(int I)
		{	if (I==0) return Info;
			else
			if (Resten==null) return null;
			else return Resten.Get(I-1);
		}
		Element Find(Element E)
		{	if (Info.Equal(E)) return Info;
			else
			if (Resten==null) return null;
			else return Resten.Find(E);
		}
		
		/* **** Draw **** */
		void DrawNode(double x, int y)
		{	Pict.PutPlace((int)x,y,Radie,0,Info);}
		void Draw()
		{	int x,y;
			x=(int)(B*Math.random());
			y=(int)(H*Math.random());
			if(!PM[x][y]){PM[x][y]=true;}
			else
			{	x=2; y=2;
				while(PM[x][y])
				{	x=x+1;
					if(x==B){x=1;y=y+1;}
				}
				PM[x][y]=true;
			}
			DrawNode(10+x*Radie,10+y*Radie);
			if (Resten!=null)
			{	Resten.Draw();}
		}
	}
		
	private class SearchSond extends Body
	{	Set L;
		Element K;
		SearchSond(Element TheKey) {L=new Set(); K=TheKey;}
		public void Perform(Element E)
		{ if (E.Key(K)) L.Insert(E);
		}
		Set GetResult() {return L;}
	}
	
	private class Includer extends Body
	{	public void Perform(Element E)
		{Set.this.Insert(E);}
	}
	
	private class Eq extends Body
	{	boolean CC=false;
		public void Perform(Element E)
		{if (Contents.Find(E)==null) CC=true;}
		public boolean Condition() {return CC;}
	}
	
	private class Same extends Body
	{	Set S;
		Same(Set Q) {S=Q;}
		public void Perform(Element E)
		{if (Contents.Find(E)!=null) S.Insert(E);}
		
	}
	
	private class Valueiterator extends Body
	{	Set S;
		Body V;
		Valueiterator(Set Q, Body B) {S=Q; V=B;}
		public void Perform(Element E)
		{S.Insert(V.Eval(E));}
	}
	
	private class ListBuilder extends Body
	{	List L=new List();
		public void Perform(Element E)
		{L=new List(E,L);}
		public List GetResult() {return L;}
	}
	
	private class SortedListBuilder extends Body
	{	SortedList L;
		SortedListBuilder(SortedList S) {L=S;}
		public void Perform(Element E)
		{L.Insert(E);}
	}
	
	private class ArrayBuilder extends Body
	{	Element [] L;
		int I=0;
		ArrayBuilder(int Size) {L=new Element[Size];}
		public void Perform(Element E)
		{L[I]=E; I=I+1;}
		public Element [] GetResult() {return L;}
	}
	
	private void OpenPict()
	{	
		B=Bredd/Radie;
		H=H�jd/Radie;
		while(B*H<Card){Radie=Radie/2;B=Bredd/Radie;H=H�jd/Radie;}
		PM=new boolean[B][H];
		for(int i=0;i<B;i=i+1)
		for(int j=0;j<H;j=j+1){PM[i][j]=false;}
	}
	
	/* ***********The visible Set structure ******** */
	
	/* ******** Constructor ************** */
	
	public Set() {Contents=null; Card=0;}
	
	/* ******** Methods ************** */
	
	/* ******** Set as Container ************** */
	/** Insert an element into the set. Element that are
		equal, according to the definition of equality in
		the elements, to an element already in the set 
		is not put into the set.
		@param E The element
		@return true if inserted else false(already present in the set).
	*/
	public boolean Insert(Element E)
	{	if (Contents==null) {Contents=new Node(E,null); Card=1;return true;}
		else return Contents.Insert(E);
	}
	/** All elements in a set is inserted into tis set.
		@param S set whose elements are to be inserted.
	*/
	public void Include(Set S)
	{S.Map(new Includer());}
	/** An element equal to the given element is deleted from
		the set (if there).
		@param E element to be deleted.
	*/
	public void Delete(Element E)
	{	if (Contents==null) {}
		else
		if (Contents.GetInfo().Equal(E))
			{Contents=Contents.GetResten();Card=Card-1;}
		else Contents.Delete(E);
	}
	/** This is a "key search" searching the set for elements
		with the same "key" as a given element. To "have a key"
		is an important property of Element.
		@see Element for the definition of key.
		@param K An element representing the "key".
		@return A set of all elements with the given "key".
	*/
	public Set Search(Element K)
	{	if (Contents==null) return new Set();
		else
		{	SearchSond S=new SearchSond(K);
			Map(S);
			return S.GetResult();
		}
	}
	/** Search the set for an element equal to the given.
		@see Element for the definition of equal.
		@param E An element to search for.
		@return The found element in the set (not the parameter element)
	*/
	public Element SearchElement(Element E)
	{	if (Contents==null) return null;
		else return Contents.Find(E);
	}
	/** Take a random element.
		@return An element from the set, randomly choosen
	*/
	public Element Pick()
	{	int I;
		I=(int)(Card*Math.random());
		if (Contents==null) return null;
		else return Contents.Get(I);
	}
	
	/* ******** Set as Type ************** */
	/** Test for emptyness
		@return true if the set is empty else false.
	*/
	public boolean Empty() {return Contents==null;}
	/** Test for membership according to equal.
		@param E the element
		@return true if the element is a member else false.
	*/
	public boolean Member(Element E)
	{	if (Contents==null) return false;
		else return Contents.Find(E)!=null;
	}
	/** @return The number of elements of the set. */
	public int Cardinal() {return Card;}
	/** Makes a shallow copy of the set.
		@resultreturn A new set with the same elements.
	*/
	public Set Copy()
	{	Set R=new Set();
		R.Include(this);
		return R;
	}
	/** Makes the union of this set and the second set.
		@param S The second set.
		@return A new set that is the union of this set and S
	*/
	public Set Union(Set S)
	{	Set R=new Set();
		R.Include(this);
		R.Include(S);
		return R;
	}
	/** Makes the intersection of this set and the second set.
		@param S The second set.
		@return A new set that is the intersection of this set and S
	*/
	public Set Intersection(Set S)
	{	Set R=new Set();
		S.Map(new Same(R));
		return R;
	}
	/** Used to define when two sets are equal.
		Two sets are equal if they contain exactly
		the same elements, where same is defined by equal in the elements
		@param S The set to compare to.
		@return true if this set is equal to the parameter set.
	*/
	public boolean Equal(Set S)
	{	if (Card!=S.Cardinal()) return false;
		else {Eq Q=new Eq(); S.Map(Q); return !Q.Condition();}
	}
	/** Tests if a set S is a subset of the current set.
		@param S Is the set S a subset of the current set
		@return true if S is a subset else false.
	*/
	public boolean Subsetofthis(Set S)
	{	if (Card<S.Cardinal()) return false;
		else {Eq Q=new Eq(); S.Map(Q); return !Q.Condition();}
	}
	/** Tests if a this set is a subset of the set S.
		@param S Is the current set a subset of S.
		@return true if this is a subset of S else false.
	*/
	public boolean Subsetof(Set S) {return S.Subsetofthis(this);}
	
	/* ******** Methods transforming Set to other types ************** */
	/** Make a list with the elements of this set (in some order).
		@return A list with its elements from this set
	*/
	public List MakeList()
	{	if (Contents==null) return new List();
		else
		{	ListBuilder LB=new ListBuilder();
			Contents.Iterate(LB);
			return LB.GetResult();
		}
	}
	/** Make a sortedlist with the elements of this set.
		@return A sorted list with its elements from this set
	*/
	public SortedList MakeSortedList()
	{	SortedList L=new SortedList();
		if (Contents==null) {}
		else Contents.Iterate(new SortedListBuilder(L));
		return L;
	}
	/** Make an array with the elements of this set (in some order).
		@return An array with its elements from this set
	*/
	public Element[] MakeArray()
	{	if (Contents==null) return new Element[0];
		else
		{	ArrayBuilder LB=new ArrayBuilder(Card);
			Contents.Iterate(LB);
			return LB.GetResult();
		}
	}
	
	/* ******** Methods for Set as an Element ************** */
	/** Used to define when this set is equal to an element.
		Such a definition has to be included in all objects
		of type Element. Two sets are equal if they contain exactly
		the same elements, where same is defined by equal in the elements
		@param E The element to compare to.
		@return true if this set is equal to the parameter element (if set)
	*/
	public boolean Equal(Element E)
	{	if (E instanceof Set) return Equal((Set)E);
		else return false;
	}
	/** Does this set have the same key as a given element.
		Key is not used by sets and it is defined as equal.
		@param E The element containing the key.
	*/
	public boolean Key(Element E) {return Equal(E);}
	
	
	/* ******** Iterators on Set ************** */
	/** Iterating over the set. The action specified in the
		body object is performed on all elements of the set, in
		some order.
		@see Body for the definition of actions and stop condition.
		@param B The object specifying the action.
	*/
	public void Map(Body B)
	{if (!B.Condition()&&Contents!=null) Contents.Iterate(B);}
	/** Iterating over the set. The function specified in the
		body object is applied to all elements of the set, in
		some order. A set of the results is returned
		@see Body for the definition of the function.
		@param B The object specifying the function.
		@return A set of the function values of the elements.
	*/
	public Set Mapset(Body B)
	{	Set R=new Set();
		Map(new Valueiterator(R,B));
		return R;
	}
	
	/* ************* Draw ***************** */
	/** It is possible to represent the set in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the set. The window has a heading and a size, the default
		is "Picture" and 400 by 400.
	*/
	public void Draw()
	{	Bredd=400; H�jd=400;
		if (Contents!=null)
		{	Pict=new Picture();
			OpenPict();
			Pict.Open();
			Contents.Draw();
			Pict.Draw();
		}
	}
	/** It is possible to represent the set in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the set. The window has a heading and a size, the default
		is "Picture" and the size given by parameters.
		@param x width of window
		@param y height of window
	*/
	public void Draw(int x,int y)
	{	Bredd=x; H�jd=y;
		if (Contents!=null)
		{	Pict=new Picture();
			OpenPict();
			Pict.Open(x,y,"picture");
			Contents.Draw();
			Pict.Draw();
		}
	}
	/** It is possible to represent the set in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the set. The window has a heading and a size, heading
		is given by parameter and the default size is 400 by 400.
		@param S heading of window
	*/
	public void Draw(String S)
	{	Bredd=400; H�jd=400;
		if (Contents!=null)
		{	Pict=new Picture();
			OpenPict();
			Pict.Open(S);	
			Contents.Draw();
			Pict.Draw();
		}
	}
	/** It is possible to represent the set in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the set. The window has a heading and a size, 
		heading and  size are given by parameters.
		@param x width of window
		@param y height of window
		@param S heading of window
	*/
	public void Draw(int x,int y,String S)
	{	Bredd=x; H�jd=y;
		if (Contents!=null)
		{	Pict=new Picture();
			OpenPict();
			Pict.Open(x,y,S);
			Contents.Draw();
			Pict.Draw();
		}
	}
	/** The window representing the set is closed and removed. This
		may also be done by using Interact and clic on the appropriate
		button in the window.
	*/
	public void UnDraw() {Pict.Destroy();}
	/** It is possible to interact with the set represented in the window.
		When no special interaction is defined the following is possible.
		In the top left corner of the window are two boxes sensible for 
		left mouse button. The box marked OK will close and remove the window,
		the box marked Freeze will just freeze the window and no more
		interaction with this window is possible. In both cases a return from
		Interact is made. It is also possible to point at a node and press
		the left or right mouse button. If left button is pressed the Show
		method of the elements contained in this node will be called. The right
		button will act in the same way as no special action is defined.
	*/
	public void Interact() {Pict.Interact();}
	/** It is possible to interact with the set represented in the window.
		Here a special interaction is defined and the following is possible.
		In the top left corner of the window are two boxes sensible for 
		left mouse button. The box marked OK will close and remove the window,
		the box marked Freeze will just freeze the window and no more
		interaction with this window is possible. In both cases a return from
		Interact is made. It is also possible to point at a node and press
		the left or right mouse button. If left button is pressed the Show
		method of the elements contained in this node will be called. The right
		button will for each element call the DoAction method in the specified
		NodeAction object. 
	*/
	public void Interact(NodeAction N) {Pict.RegisterAction(N); Pict.Interact();}
}
