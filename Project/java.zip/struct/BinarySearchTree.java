package struct;
/** ********************************************
	This class implements a binary search tree.
	The tree is an AVL tree and thus reasonably
	balanced.
	@author G�ran Fries
	@version 0.1
***********************************************/
public class BinarySearchTree extends Element
{	private Tree Structure;
	Picture Pict;
	int Bredd=400,M=200;
	
	class Tree
	{	int Height; boolean TrueHeight;
		Set Info;
		Element TheKey;
		Tree Left,Right;
		Tree(Element K)
		{	Height=1; TrueHeight=true;
			Info=new Set();
			Info.Insert(K);
			TheKey=K;
			Left=null;
			Right=null;
		}
		/* **** Access methods **** */
		void SetLeft(Tree T) {Left=T;}
		void SetRight(Tree T) {Right=T;}
		Tree GetLeft() {return Left;}
		Tree GetRight() {return Right;}
		int GetHeight()
		{	if (TrueHeight) return Height;
			else
			{	int vh,hh;
				if (Left!=null) vh=Left.GetHeight(); else vh=0;
				if (Right!=null) hh=Right.GetHeight(); else hh=0;
				if (vh>hh) {Height=vh+1; TrueHeight=true;}
				else {Height=hh+1; TrueHeight=true;}
				return Height;
			}
		}
		boolean Rightmost() {return Right==null;}
		
		/* **** Insert **** */
		Tree Insert(Element E)
		{	
			if (E.Key(TheKey)) {Info.Insert(E);}
			else
			if (E.Before(TheKey))
				{	TrueHeight=false;
					if (Left==null) Left=new Tree(E);
				 	else Left=Left.Insert(E);
				}
			else
			if (E.After(TheKey))
				{	TrueHeight=false;
					if (Right==null) Right=new Tree(E);
				 	else Right=Right.Insert(E);
				}
			else {}
			return Balance();
		}
		
		/* **** Search **** */
		Set Search(Element E)
		{	if (E.Key(TheKey)) return Info.Search(E);
			else
			if (E.Before(TheKey))
				{if (Left==null) return null;
				 else return Left.Search(E);}
			else
			if (E.After(TheKey))
				{if (Right==null) return null;
				 else return Right.Search(E);}
			else {return null;}
		}
		
		/* **** Search Element **** */
		Element SearchElement(Element E)
		{	if (E.Key(TheKey)) return Info.SearchElement(E);
			else
			if (E.Before(TheKey))
				{if (Left==null) return null;
				 else return Left.SearchElement(E);}
			else
			if (E.After(TheKey))
				{if (Right==null) return null;
				 else return Right.SearchElement(E);}
			else {return null;}
		}
		
		/* **** Delete **** */
		Tree Delete(Element E)
		{	if (E.Key(TheKey))
				{Info.Delete(E);
				 if (Info.Empty()) return DeleteRoot();
				 else return this;}
			else
			if (E.Before(TheKey))
				{	int vh,hh,diff;
					if (Left==null) {}
				 	else Left=Left.Delete(E);
				 	return Balance();
				}
			else
			if (E.After(TheKey))
				{	int vh,hh,diff;
					if (Right==null) {}
				 	else Right=Right.Delete(E);
				 	return Balance();
				}
			else {return null;}
		}
		
		/* **** Iterators **** */
		void Preorder(Body B)
		{	Info.Map(B);
			if (Left!=null) Left.Preorder(B);
			if (Right!=null) Right.Preorder(B);
		}
		void Inorder(Body B)
		{	if (Left!=null) Left.Inorder(B);
			Info.Map(B);
			if (Right!=null) Right.Inorder(B);
		}
		void Postorder(Body B)
		{	if (Left!=null) Left.Postorder(B);
			if (Right!=null) Right.Postorder(B);
			Info.Map(B);
		}
		
		/* **** Draw **** */
		void DrawNode(double x, int y)
		{	Pict.PutPlace(M+(int)(x*M),10+y*40,10,0,Info);}
		void DrawArc(double x,int y,double u,int v)
		{	Pict.PutArc(M+(int)(x*M),10+y*40,M+(int)(u*M),10+v*40);}
		void Draw(double x,int y)
		{	DrawNode(x,y);
			if (Left!=null)
			{	DrawArc(x,y,x-Math.pow(2,-(y+1)),y+1);
				Left.Draw(x-Math.pow(2,-(y+1)),y+1);
			}
			if (Right!=null)
			{	DrawArc(x,y,x+Math.pow(2,-(y+1)),y+1);
				Right.Draw(x+Math.pow(2,-(y+1)),y+1);
			}
		}
		
		/* ****** Local ********* */
		private Tree LLRotate()
		{	Tree R,D;
			R=Left;
			D=R.GetRight();
			Left=D;
			R.SetRight(this);
			return R;
		}
		private Tree RRRotate()
		{	Tree R,D;
			R=Right;
			D=R.GetLeft();
			Right=D;
			R.SetLeft(this);
			return R;
		}
		private Tree LRRotate()
		{	Tree R,T;
			R=Left;
			T=R.GetRight();
			R.SetRight(T.GetLeft());
			Left=T.GetRight();
			T.SetLeft(R);
			T.SetRight(this);
			return T;
		}
		private Tree RLRotate()
		{	Tree R,T;
			R=Right;
			T=R.GetLeft();
			R.SetLeft(T.GetRight());
			Right=T.GetLeft();
			T.SetRight(R);
			T.SetLeft(this);
			return T;
		}
		
		Tree DeleteRoot()
		{	if (Left==null) return Right;
			else
			if (Right==null) return Left;
			else
			if (Left.Rightmost())
			{	Left.SetRight(Right);
				return Left.Balance();
			}
			else
			{	Tree RM; Pair R;
				R=Left.GetRightmost();
				RM=R.Second();
				RM.SetLeft(R.First());
				RM.SetRight(Right);
				return RM.Balance();
			}
		}
		Pair GetRightmost()
		{	if (Right.Rightmost())
			{	Tree R;
				R=Right;
				Right=R.GetLeft();
				return new Pair(Balance(),R);
			}
			else
			{	Pair R;
				R=Right.GetRightmost();
				Right=R.First();
				return new Pair(Balance(),R.Second());
			}
		}
		Tree Balance()
		{	int diff;
			diff=Diff();
			if (diff>1)
				{	if (Left.Diff()>0) {return LLRotate();}
					else { return LRRotate();}
				}
			else
			if (diff<-1) 
				{	if (Right.Diff()<0) {return RRRotate();}
					else {return RLRotate();}
				}
			else {return this;}
		}
		int Diff()
		{	int vh,hh;
			if (Left!=null) vh=Left.GetHeight(); else vh=0;
			if (Right!=null) hh=Right.GetHeight(); else hh=0;
			if (vh>hh) {Height=vh+1;} else {Height=hh+1;}
			return vh-hh;
		}
		class Pair
		{	Tree F,S;
			Pair(Tree A, Tree B){F=A; S=B;}
			Tree First() {return F;}
			Tree Second() {return S;}
		}
	}
/* ******************** Constructor ***************************** */	

	public BinarySearchTree() {Structure=null; Pict=new Picture();}
	
	private BinarySearchTree(Tree T) {Structure=T; Pict=new Picture();}
	
/* ******************** Methods ***************************** */

	/* *************** Tree as container ***************** */	
	/** Insert an element into the tree, the element is sorted
		into the tree according to the definitions of Before, After
		and same Key.
		@param E	The element to insert
	*/
	public void Insert(Element E)
	{	if (Structure!=null) Structure=Structure.Insert(E);
		else Structure=new Tree(E);
	}
	/** Delete an element from the tree, if there else do nothing.
		An element Equal to the given element is deleted. The definition
		of Equal in the element is used.
		@param E	The element to delete.
	*/
	public void Delete(Element E)
	{if (Structure!=null) Structure=Structure.Delete(E);}
	/** Search the tree for all elements with the same key as the
		parameter element. A set of those elements is returned.
		@param E	The element defining the key to search for.
		@return	A set of all those element with this key.
	*/
	public Set Search(Element E)
	{if (Structure!=null) return Structure.Search(E); else return null;}
	/** Search the tree for an element equal to a given element.
		The definition of Equal in the element is used.
		@param E	The element to search for
		@return	The element present in the tree or null if not present. 
	*/
	public Element SearchElement(Element E)
	{if (Structure!=null) return Structure.SearchElement(E); else return null;}
	
	/* **** Iterators **** */
	/** Do something with all elements in preorder.
		@param B	An object defining what to do.
	*/
	public void Preorder(Body B)
	{if (Structure!=null) Structure.Preorder(B);}
	/** Do something with all elements in inorder.
		@param B	An object defining what to do.
	*/
	public void Inorder(Body B)
	{if (Structure!=null) Structure.Inorder(B);}
	/** Do something with all elements in postorder.
		@param B	An object defining what to do.
	*/
	public void Postorder(Body B)
	{if (Structure!=null) Structure.Postorder(B);}
	
	/* ************* Search tree as Element ***************** */
	/** Used to define when this tree is equal to an element.
		Such a definition has to be included in all objects
		of type Element. Two trees are equal if they are the
		same objects.
		@param E The element to compare to.
		@return true if this tree is equal to the parameter element
	*/
	public boolean Equal(Element E)
	{	if (E instanceof BinarySearchTree) return E==this;
		else return false;
	}
	/** Does this tree have the same key as a given element.
		Key is not used by trees and it is defined as equal.
		@param E The element containing the key.
	*/
	public boolean Key(Element E) {return Equal(E);}
	
	/* ************* Draw ***************** */
	/** It is possible to represent the tree in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the tree. The window has a heading and a size, the default
		is "Picture" and 400 by 400.
	*/
	public void Draw()
	{	Bredd=400; M=Bredd/2;
		if (Structure!=null) {Pict.Open(); Structure.Draw(0,0); Pict.Draw();}
	}
	/** It is possible to represent the tree in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the tree. The window has a heading and a size, the default
		is "Picture" and the size given by parameters.
		@param x width of window
		@param y height of window
	*/
	public void Draw(int x,int y)
	{	Bredd=x; M=Bredd/2;
		if (Structure!=null)
		{Pict.Open(x,y,"picture"); Structure.Draw(0,0); Pict.Draw();}
	}
	/** It is possible to represent the tree in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the tree. The window has a heading and a size, heading
		is given by parameter and the default size is 400 by 400.
		@param S heading of window
	*/
	public void Draw(String S)
	{	Bredd=400; M=Bredd/2;
		if (Structure!=null)
		{Pict.Open(S); Structure.Draw(0,0); Pict.Draw();}
	}
	/** It is possible to represent the tree in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the tree. The window has a heading and a size, 
		heading and  size are given by parameters.
		@param x width of window
		@param y height of window
		@param S heading of window
	*/
	public void Draw(int x,int y,String S)
	{	Bredd=x; M=Bredd/2;
		if (Structure!=null)
		{Pict.Open(x,y,S); Structure.Draw(0,0); Pict.Draw();}
	}
	/** The window representing the tree is closed and removed. This
		may also be done by using Interact and clic on the appropriate
		button in the window.
	*/
	public void UnDraw() {Pict.Destroy();}
	/** It is possible to interact with the tree represented in the window.
		When no special interaction is defined the following is possible.
		In the top left corner of the window are two boxes sensible for 
		left mouse button. The box marked OK will close and remove the window,
		the box marked Freeze will just freeze the window and no more
		interaction with this window is possible. In both cases a return from
		Interact is made. It is also possible to point at a node and press
		the left or right mouse button. If left button is pressed the Show
		method of the elements contained in this node will be called. The right
		button will act in the same way as no special action is defined.
	*/
	public void Interact() {Pict.Interact();}
	/** It is possible to interact with the tree represented in the window.
		Here a special interaction is defined and the following is possible.
		In the top left corner of the window are two boxes sensible for 
		left mouse button. The box marked OK will close and remove the window,
		the box marked Freeze will just freeze the window and no more
		interaction with this window is possible. In both cases a return from
		Interact is made. It is also possible to point at a node and press
		the left or right mouse button. If left button is pressed the Show
		method of the elements contained in this node will be called. The right
		button will for each element call the DoAction method in the specified
		NodeAction object. 
	*/
	public void Interact(NodeAction N) {Pict.RegisterAction(N); Pict.Interact();}
	
}
