package struct;
/** ********************************************
	This class implements a list of Element,
	elements with a bit more structure than 
	ordinary of type Object. In order to be able
	to put lists as elements in other lists, the
	List is also of type Element.
	@author G�ran Fries
	version 0.1
	version 0.2
	@version 0.3
***********************************************/

public class List extends Element
{	protected Node Contents;
	Picture Pict;
	int Bredd=400,D=40;
	/*********** Internal class *************/
	protected class Node
	{	protected Element Info;
		protected Node Rest;
		Node(Element E, Node N) {Info=E; Rest=N;}
		Element GetInfo() {return Info;}
		Node GetRest() {return Rest;}
		Element Find(Element E)
		{	if (Info.Equal(E)) return E;
			else
			if (Rest!=null) return Rest.Find(E);
			else return null;
		}
		void Iterate(Body B) {B.Perform(Info); if (Rest!=null) Rest.Iterate(B);}
		Node IterateValue(Body B)
		{	if (Rest!=null) return new Node(B.Eval(Info),Rest.IterateValue(B));
			else return new Node(B.Eval(Info),null);
		}
		Node Copy()
		{	if (Rest==null) return new Node(Info,null);
			else return new Node(Info,Rest.Copy());
		}
		Node Copy(Element K)
		{	if (Info.Key(K))
				{	if (Rest==null) return new Node(Info,null);
					else return new Node(Info,Rest.Copy(K));
				}
			else
				{	if (Rest==null) return null;
					else return Rest.Copy(K);
				}
		}
		Node Copy(Node C)
		{	if (Rest==null) return new Node(Info,C.Copy());
			else return new Node(Info,Rest.Copy(C));
		}
		int Count()
		{	if (Rest==null) return 1;
			else return 1+Rest.Count();
		}
		Element Get(int I)
		{	if (I==0) return Info;
			else
			if (Rest==null) return null;
			else return Rest.Get(I-1);
		}
		Node GetRest(int I)
		{	if (Rest==null) return null;
			else
			if (I==0) return Rest.Copy();			
			else return Rest.GetRest(I-1);
		}
		Node GetF(int I)
		{	if (I==0) return null;
			else
			if (Rest==null) return null;
			else return new Node(Info,Rest.GetF(I-1));
		}
		
		/* **** Draw **** */
		void DrawNode(double x, int y)
		{	Pict.PutPlace((int)x,y,10,0,Info);}
		void DrawArc(double x,int y,double u,int v)
		{	Pict.PutArc((int)x,y,(int)u,v);}
		void Draw(double x,int y)
		{	DrawNode(x,y);
			if (Rest!=null)
			{	DrawArc(x,y,x+D,y);
				if(x+D>Bredd-15){x=10; y=y+40; DrawArc(x,y,x+D,y);}
				Rest.Draw(x+D,y);
			}
		}
	}
	private class SortBuilder extends Body
	{	SortedList L;
		SortBuilder(SortedList S) {L=S;}
		public void Perform(Element E)
		{L.Insert(E);}
	}	
	private class ArrBuilder extends Body
	{	Element [] L;
		int I=0;
		ArrBuilder(int Size) {L=new Element[Size];}
		public void Perform(Element E)
		{L[I]=E; I=I+1;}
		public Element [] GetResult() {return L;}
	}
	private Node TrueCopy(Node L)
	{	if(L==null) return null;
		else return new Node(L.GetInfo(),TrueCopy(L.GetRest()));
	}
	private Node TrueConc(Node L1,Node L2)
	{	if(L1==null) return TrueCopy(L2);
		else return new Node(L1.GetInfo(),TrueConc(L1.GetRest(),L2));
	}

	/* *********** The List properties *********** */
	
	/** Constructor without parameters will create 
		an empty list. */
	public List()
	{Contents=null;}
	
	/** Constructor with one parameter creates a list
		containing one element.
		@param E an element to be put into the list
	*/
	public List(Element E)
	{Contents=new Node(E,null);}
	
	/** Constructor with two parameters creates a list
		from one element and a list.
		@param E an element to be put first in the new list
		@param L a list that will be the tail of the new list
	*/
	public List(Element E,List L)
	{	if(L!=null)Contents=new Node(E,TrueCopy(L.Contents));
		else Contents=new Node(E,null);
	}
	
	private List(Node N)
	{Contents=N;}
	
	/* ***** Methods ***** */
	/** @return The first element of the list. */
	public Element Head()
	{	if (Contents!=null) return Contents.GetInfo();
		else return null;
	}
	/** @return A new list = old list with first element removed. */
	public List Tail()
	{	if (Contents!=null)
		{	Node N=Contents.GetRest();
			if (N==null) return new List();
			else return new List(TrueCopy(N));
		}
		else return new List();
	}
	/** @return The number of elements of the list. */
	public int Cardinal()
	{	if (Contents==null) return 0;
		else return(Contents.Count());
	}
	/** This is a "key search" searching the list for elements
		with the same "key" as a given element. To "have a key"
		is an important property of Element.
		@see Element for the definition of key.
		@param K An element representing the "key".
		@return A list of all elements with the given "key".
	*/
	public List Search(Element K)
	{	if (Contents==null) return new List();
		else return new List(Contents.Copy(K));
	}
	/** A list is an ordered sequence of elements, thus the
		elements may be numbered (1,2,3,...), and it is reasonable
		to address the i:th element of a list.
		@param I This is the number of the addressed element.
		@return The i:th element of the list or null if outside of list.
	*/
	public Element Get(int I)
	{	if (I<=0) return null;
		else
		if (Contents!=null) return Contents.Get(I-1);
		else return null;
	}
	/** A list is an ordered sequence of elements, thus the
		elements may be numbered (1,2,3,...), and it is reasonable
		to split the list into the part before and the part after 
		element number i.
		@param I This is the number of the addressed element.
		@return The tail after i:th element of the list.
	*/
	public List Tail(int I)
	{	if (Contents!=null)
		{	Node N=Contents.GetRest(I-1);
			if (N==null) return new List();
			else return new List(TrueCopy(N));
		}
		else return new List();
	}
	/** A list is an ordered sequence of elements, thus the
		elements may be numbered (1,2,3,...), and it is reasonable
		to split the list into the part before and the part after 
		element number i.
		@param I This is the number of the addressed element.
		@return The list of elements before i:th element of the list.
	*/
	public List First(int I)
	{	if (Contents!=null)
		{	Node N=Contents.GetF(I-1);
			if (N==null) return new List();
			else return new List(TrueCopy(N));
		}
		else return new List();
	}
	/** Is an element equal to a given element present in the list.
		@see Element for definition of equal.
		@param E The given element.
		@return true if an element equal to the given is a list member else false.
	*/
	public boolean Member(Element E)
	{	if (Contents==null) return false;
		else return Contents.Find(E)!=null;
	}
	/** Tests for empty list.
		@return true if the list is empty else false.
	*/
	public boolean Empty() {return Contents==null;}
	/** Makes a shallow copy of the list.
		@return A new list with the same elements (and order).
	*/
	public List Copy()
	{	if (Contents==null) return new List();
		else return new List(TrueCopy(Contents));
	}
	/** Makes a concatenation of two lists.
		@param L The second list.
		@return A new list a concatenation of this and the second list.
	*/
	public List Concatenate(List L)
	{	if (Contents==null) return L.Copy();
		else
		if (L.Contents==null) return Copy();
		else return new List(TrueConc(Contents,L.Contents));
	}
	/** Sort a list. A sorted list will be created with the
		elements taken from the current list.
		@return A new sorted list.
	*/
	public SortedList Sort()
	{	SortedList L=new SortedList();
		if (Contents==null) {}
		else Contents.Iterate(new SortBuilder(L));
		return L;
	}
	/** Make an array with the elements of this List (in list order).
		@return An array with its elements from this List
	*/
	public Element[] MakeArray()
	{	if (Contents==null) return new Element[0];
		else
		{	ArrBuilder LB=new ArrBuilder(Contents.Count());
			Contents.Iterate(LB);
			return LB.GetResult();
		}
	}
	/* *********** Iterators ********** */

	/** Iterating over the list. The action specified in the
		body object is performed on all elements of the list, in
		natural list order.
		@see Body for the definition of actions and stop condition.
		@param B The object specifying the action.
	*/
	public void Map(Body B)
	{if (Contents!=null) Contents.Iterate(B);}
	/** Iterating over the list. The function specified in the
		body object is applied to all elements of the list, in
		natural list order. A list of the result is returned
		@see Body for the definition of the function.
		@param B The object specifying the function.
		@return A list of the function values of the elements.
	*/
	public List Maplist(Body B)
	{	if (Contents!=null) return new List(Contents.IterateValue(B));
		else return new List();
	}
	/* *********** Element methods *********** */
	
	/** Used to define when two lists are equal.
		Such a definition has to be included in all objects
		of type Element. Two lists are equal if all elements, in that order,
		are equal in the sense defined by equal in the elements.
		@param E The list to compare to.
		@return true if this list is equal to the parameter element (if list)
	*/
	public boolean Equal(Element E)
	{	if (!(E instanceof List)) return false;
		else
		if (Empty()) return ((List) E).Empty();
		else
		if (Head().Equal(((List) E).Head()))
			return Tail().Equal(((List)E).Tail());
		else return false;
	}
	/** Used to define when two lists are having the same key.
		Such a definition has to be included in all objects
		of type Element. The key concept is not used for lists, two lists
		are regarded to have the same key only if the lists are equal.
		@param E The list to compare to.
		@return true if this list is equal to the parameter element (if list)
	*/
	public boolean Key(Element E) {return Equal(E);}
	
	/* ************* Draw ***************** */
	/** It is possible to represent the list in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the list. The window has a heading and a size, the default
		is "Picture" and 400 by 400.
	*/
	public void Draw()
	{	Bredd=400;
		if (Contents!=null)
		{Pict=new Picture();Pict.Open(); Contents.Draw(50,60); Pict.Draw();}
	}
	/** It is possible to represent the List in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the list. The window has a heading and a size, the default
		is "Picture" and the size given by parameters.
		@param x width of window
		@param y height of window
	*/
	public void Draw(int x,int y)
	{	Bredd=x;
		if (Contents!=null)
		{	Pict=new Picture();
			Pict.Open(x,y,"picture");
			Contents.Draw(50,60);
			Pict.Draw();
		}
	}
	/** It is possible to represent the list in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the list. The window has a heading and a size, heading
		is given by parameter and the default size is 400 by 400.
		@param S heading of window
	*/
	public void Draw(String S)
	{	Bredd=400;
		if (Contents!=null)
		{Pict=new Picture();Pict.Open(S); Contents.Draw(50,60); Pict.Draw();}
	}
	/** It is possible to represent the list in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the list. The window has a heading and a size, 
		heading and  size are given by parameters.
		@param x width of window
		@param y height of window
		@param S heading of window
	*/
	public void Draw(int x,int y,String S)
	{	Bredd=x;
		if (Contents!=null)
		{Pict=new Picture();Pict.Open(x,y,S); Contents.Draw(50,60); Pict.Draw();}
	}
	/** The window representing the tree is closed and removed. This
		may also be done by using Interact and clic on the appropriate
		button in the window.
	*/
	public void UnDraw() {Pict.Destroy();}
	/** It is possible to interact with the list represented in the window.
		When no special interaction is defined the following is possible.
		In the top left corner of the window are two boxes sensible for 
		left mouse button. The box marked OK will close and remove the window,
		the box marked Freeze will just freeze the window and no more
		interaction with this window is possible. In both cases a return from
		Interact is made. It is also possible to point at a node and press
		the left or right mouse button. If left button is pressed the Show
		method of the elements contained in this node will be called. The right
		button will act in the same way as no special action is defined.
	*/
	public void Interact() {Pict.Interact();}
	/** It is possible to interact with the list represented in the window.
		Here a special interaction is defined and the following is possible.
		In the top left corner of the window are two boxes sensible for 
		left mouse button. The box marked OK will close and remove the window,
		the box marked Freeze will just freeze the window and no more
		interaction with this window is possible. In both cases a return from
		Interact is made. It is also possible to point at a node and press
		the left or right mouse button. If left button is pressed the Show
		method of the elements contained in this node will be called. The right
		button will for each element call the DoAction method in the specified
		NodeAction object. 
	*/
	public void Interact(NodeAction N) {Pict.RegisterAction(N); Pict.Interact();}
}
