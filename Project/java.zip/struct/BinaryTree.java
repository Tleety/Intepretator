package struct;
/** ********************************************
	This class implements a binary  tree.
	@author G�ran Fries
	@version 0.1
***********************************************/
public class BinaryTree extends Element
{	private Tree Structure;
	Picture Pict;
	int Bredd=400,M=200;
	
	class Tree
	{	Element Info;
		Tree Left,Right;
		Tree(Element E,Tree L,Tree R)
		{Info=E;Left=Copy(L); Right=Copy(R);}
		Tree(Element I,Tree L,Tree R,int n)
		{Info=I;Left=L; Right=R;}
		/* **** Access methods **** */
		void SetLeft(Tree T) {Left=T;}
		void SetRight(Tree T) {Right=T;}
		Tree GetLeft() {return Left;}
		Tree GetRight() {return Right;}
		Element GetInfo() {return Info;}
		
		Tree Copy(Tree T)
		{	if(T!=null)
			{return new Tree(T.Info,Copy(T.GetLeft()),Copy(T.GetRight()),0);}
			else {return null;}
		}
		
		/* **** Iterators **** */
		void Preorder(Body B)
		{	B.Perform(Info);
			if (Left!=null) Left.Preorder(B);
			if (Right!=null) Right.Preorder(B);
		}
		void Inorder(Body B)
		{	if (Left!=null) Left.Inorder(B);
			B.Perform(Info);
			if (Right!=null) Right.Inorder(B);
		}
		void Postorder(Body B)
		{	if (Left!=null) Left.Postorder(B);
			if (Right!=null) Right.Postorder(B);
			B.Perform(Info);
		}
		
		/* **** Draw **** */
		void DrawNode(double x, int y)
		{	Pict.PutPlace(M+(int)(x*M),10+y*40,10,0,Info);}
		void DrawArc(double x,int y,double u,int v)
		{	Pict.PutArc(M+(int)(x*M),10+y*40,M+(int)(u*M),10+v*40);}
		void Draw(double x,int y)
		{	DrawNode(x,y);
			if (Left!=null)
			{	DrawArc(x,y,x-Math.pow(2,-(y+1)),y+1);
				Left.Draw(x-Math.pow(2,-(y+1)),y+1);
			}
			if (Right!=null)
			{	DrawArc(x,y,x+Math.pow(2,-(y+1)),y+1);
				Right.Draw(x+Math.pow(2,-(y+1)),y+1);
			}
		}
		
	}
/* ******************** Constructor ***************************** */	

	public BinaryTree() {Structure=null; Pict=new Picture();}
	
	public BinaryTree(Element E,BinaryTree L,BinaryTree R)
	{Structure=new Tree(E,L.GetTree(),R.GetTree()); Pict=new Picture();}
	
	public BinaryTree(Element E)
	{Structure=new Tree(E,null,null); Pict=new Picture();}
	
	private BinaryTree(Tree T) {Structure=T; Pict=new Picture();}
	
/* ******************** Methods ***************************** */

	
	/* **** Iterators **** */
	/** Do something with all elements in preorder.
		@param B	An object defining what to do.
	*/
	public void Preorder(Body B)
	{if (Structure!=null) Structure.Preorder(B);}
	/** Do something with all elements in inorder.
		@param B	An object defining what to do.
	*/
	public void Inorder(Body B)
	{if (Structure!=null) Structure.Inorder(B);}
	/** Do something with all elements in postorder.
		@param B	An object defining what to do.
	*/
	public void Postorder(Body B)
	{if (Structure!=null) Structure.Postorder(B);}
	/** Get the left subtree
		@return The left subtree as a BinaryTree
	*/
	public BinaryTree GetLeft(){return new BinaryTree(Structure.Left);}
	/** Get the right subtree
		@return The right subtree as a BinaryTree
	*/
	public BinaryTree GetRight(){return new BinaryTree(Structure.Right);}
	/** Get the root element
		@return the root element of the tree
	*/
	public Element GetRoot()
	{	if(Structure==null){return null;}
		else {return Structure.GetInfo();}
	}
	private Tree GetTree(){return Structure;}
	
	/* ************* Binary tree as Element ***************** */
	/** Used to define when this tree is equal to an element.
		Such a definition has to be included in all objects
		of type Element. Two trees are equal if they are the
		same objects.
		@param E The element to compare to.
		@return true if this tree is equal to the parameter element
	*/
	public boolean Equal(Element E)
	{	if (E instanceof BinaryTree) return E==this;
		else return false;
	}
	/** Does this tree have the same key as a given element.
		Key is not used by trees and it is defined as equal.
		@param E The element containing the key.
	*/
	public boolean Key(Element E) {return Equal(E);}
	
	/* ************* Draw ***************** */
	/** It is possible to represent the tree in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the tree. The window has a heading and a size, the default
		is "Picture" and 400 by 400.
	*/
	public void Draw()
	{	Bredd=400; M=Bredd/2;
		if (Structure!=null) {Pict.Open(); Structure.Draw(0,0); Pict.Draw();}
	}
	/** It is possible to represent the tree in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the tree. The window has a heading and a size, the default
		is "Picture" and the size given by parameters.
		@param x width of window
		@param y height of window
	*/
	public void Draw(int x,int y)
	{	Bredd=x; M=Bredd/2;
		if (Structure!=null)
		{Pict.Open(x,y,"picture"); Structure.Draw(0,0); Pict.Draw();}
	}
	/** It is possible to represent the tree in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the tree. The window has a heading and a size, heading
		is given by parameter and the default size is 400 by 400.
		@param S heading of window
	*/
	public void Draw(String S)
	{	Bredd=400; M=Bredd/2;
		if (Structure!=null)
		{Pict.Open(S); Structure.Draw(0,0); Pict.Draw();}
	}
	/** It is possible to represent the tree in graphical format
		in a window. It is possible to define a graphical interaction with
		the nodes in the tree. The window has a heading and a size, 
		heading and  size are given by parameters.
		@param x width of window
		@param y height of window
		@param S heading of window
	*/
	public void Draw(int x,int y,String S)
	{	Bredd=x; M=Bredd/2;
		if (Structure!=null)
		{Pict.Open(x,y,S); Structure.Draw(0,0); Pict.Draw();}
	}
	/** The window representing the tree is closed and removed. This
		may also be done by using Interact and clic on the appropriate
		button in the window.
	*/
	public void UnDraw() {Pict.Destroy();}
	/** It is possible to interact with the tree represented in the window.
		When no special interaction is defined the following is possible.
		In the top left corner of the window are two boxes sensible for 
		left mouse button. The box marked OK will close and remove the window,
		the box marked Freeze will just freeze the window and no more
		interaction with this window is possible. In both cases a return from
		Interact is made. It is also possible to point at a node and press
		the left or right mouse button. If left button is pressed the Show
		method of the elements contained in this node will be called. The right
		button will act in the same way as no special action is defined.
	*/
	public void Interact() {Pict.Interact();}
	/** It is possible to interact with the tree represented in the window.
		Here a special interaction is defined and the following is possible.
		In the top left corner of the window are two boxes sensible for 
		left mouse button. The box marked OK will close and remove the window,
		the box marked Freeze will just freeze the window and no more
		interaction with this window is possible. In both cases a return from
		Interact is made. It is also possible to point at a node and press
		the left or right mouse button. If left button is pressed the Show
		method of the elements contained in this node will be called. The right
		button will for each element call the DoAction method in the specified
		NodeAction object. 
	*/
	public void Interact(NodeAction N) {Pict.RegisterAction(N); Pict.Interact();}
	
}
