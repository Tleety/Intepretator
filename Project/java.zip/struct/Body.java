package struct;
/** *************************************************
	Objects of this type is used by iterators in structures
	like lists, sets,.... The action or function that should
	be applied to the elements is defined in such an object.
	This class is abstract and defines the common properties
	of such objects. An actual object is of course a normal
	object that may contain data to be used by Perform or
	Eval. Information may be passed between different performs
	in this object.
	@author G�ran Fries
	@version 0.1
************************************************** */
public abstract class Body
{	
	/** Here the action to be applied to all elements
		is defined.
		@param E The element
	*/
	public abstract void Perform(Element E);
	/** An iteration will be stopped in advance as soon as
		this condition will return false. The default action
		is to always return true. 
	*/
	public boolean Condition() {return false;}
	/** Here the function to be applied to all elements
		is defined.
		@param E The element
		@return The resulting element of the applied function
	*/
	public Element Eval(Element E) {return E;}
}
