package real;
/*
 !***************************************************************
 !		Revision history
 ! 1.0	981006 
 !	1.0.1	981008 wait for available introduced
 !	1.0.2	981023 stop the reader if end of file reached
 !	1.1	000831
 !***************************************************************
*/
import file.*;
/* ********************************************************************
*		Reader
* A Reader is an object representing the input from a file or 
* a channel (socket). 
* Constructors:
*	Reader(infile)			Create a reader of the given file
*	Reader(String)			Create a file object with the given name
*								and a reader of this file
*	Reader()					Same as above, but standard input file is used
*	Reader(Channel)		Create a reader of the given channel (socket)
* Methods:
*	StartRead(Proc)		The reader is started in parallell, when input
*								is available a text image will be sent in a
*								ReadEvent to the given Proc
*	StopRead()				The reader is stopped!
*	SetBlocking(boolean)	Set blocking to true for systems, like Linux,
*								not using true time-shareing. (Default is false)
******************************************************************** */

/** Defines the Reader type.
	A reader is an object representing the input from 
	a file or a channel (socket). The reader is an object
	connected to the input stream, that listens in parallell
	to the processes and that is signalling a process when
	some input is available.
	This is not a process in the same meaning as Proc, but it
	contains an execution path represented by a thread object.
	@author G�ran Fries
	@version 1.1
*/
public class Reader
{	
	private infile TheFile=null;
	private Channel TheChannel=null;
	private MyThread TheThread;
	private boolean EOF=false;
	private boolean Linux=false;
	
	class MyThread extends Thread
	{	Proc TheProcess;
		boolean Opened;
		
		public MyThread(Proc P) {TheProcess=P; Opened=true;}
		
		public void Close() {Opened=false; } // Not needed stop(); 
		
		public void run()
		{	String S;
			while (Opened&&!EOF)
			{	if(Linux) {while (!Available()) Sov();}
				if (TheChannel!=null)
					{	if (TheChannel.Endfile()) {EOF=true; S="";}
						else S=TheChannel.Read();
					}
				else
				if (TheFile!=null)
					{	if (TheFile.Endfile()) {EOF=true; S="";}
						else {TheFile.InImage(); S=TheFile.GetImage();}
					}
				else {S="";}
				TheProcess.PutEvent(new ReadEvent(S,EOF));
			}
		}
		
		private boolean Available()
		{	if (TheChannel!=null) return TheChannel.Available();
			else
			if (TheFile!=null) return TheFile.Available();
			else return false;
		}
		private void Sov()
		{ try {sleep(100);}
		  catch (InterruptedException e) {};
		}
		
	}
	
	
	/* ********************************************************** */
	/** Creates a reader connected to an existing infile.
		@param F An infile object.
	*/
	public Reader(infile F) {TheFile=F;}
	/** Creates an infile and a reader connected this infile.
		@param N A file name.
	*/
	public Reader(String N) {TheFile=new infile(N); TheFile.Open();}
	/** Creates a reader connected to standard input.
	*/
	public Reader() {TheFile=new infile(); TheFile.Open();}
	/** Creates a reader connected to a channel, implemented by a socket.
		@param C A Channel object.
	*/
	public Reader(Channel C) {TheChannel=C;}
	/** Avoid blocking the system when input not available.
		Some systems without real time shareing may block.
		For such systems set blocking to true, false is default.
		@param B true for no real time shareing systems.
	*/
	public void SetBlocking(boolean B) {Linux=B;}
	
	/* ********************************************************** */
	/** Start the reader.
		The execution path is started and connected to a process.
		@param P Send input to this process as a ReadEvent.
		@see ReadEvent
	*/
	public void StartRead(Proc P)
	{	TheThread=new MyThread(P);
		TheThread.start();
	}
	/** Stop the reader.
		The execution path is stopped and the reader will not
		get more input.
	*/
	public void StopRead() {TheThread.Close();}
}
