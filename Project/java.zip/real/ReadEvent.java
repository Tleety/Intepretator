package real;
/** Event type of an input message.
	This type is a subtype of ProcessEvent and used to send
	input from a reader to a process.
	@author G�ran Fries
	@version 1.2
*/
public class ReadEvent extends ProcessEvent
{	private final String TheText;
	private int pos,lng;
	private boolean EOL,EOF;
	/* ********************************************************** */
	/** Creates an event with a string message.
		The message is normally an input text, and EOF is set to false.
	*/
	public ReadEvent(String S)
	{TheText=S; pos=0; lng=S.length(); EOF=false;}
	/** Creates an event with a string message.
		The message is normally an input text. Here EOF is also set.
		@param S The text message.
		@param E The EndOfFile status.
	*/
	public ReadEvent(String S, boolean E)
	{TheText=S; pos=0; lng=S.length(); EOF=E;}
	/* ********************************************************** */
	/** Get the message text.
		@return The message text string.
	*/
	public String Get() {return TheText;}
	/** Get the endfile state.
		@return true if end of file reached, else false.
	*/
	public boolean Endfile() {return EOF;}
	/** Get the endline state.
		@return true if end of line reached, else false.
	*/
	public boolean Endline() {return EOL;}
	/** Get a character from the message.
		The message may be read character by character. This will
		get the next character and advance the current character pointer.
		When end of message is reached space will be returned each time.
		@return Next character from message.
	*/
	public char GetChar()
	{	if (lng==0) {EOL=true; return ' ';}
		else
		if (EOL) return ' ';
		else
		{pos=pos+1; EOL=pos>=lng; return TheText.charAt(pos-1);}
	}
	/** Get an integer from the message.
		Reads an integer from the message string starting at
		current position. Current position is advanced over the integer.
		If already end of line reached 0 will be returned.
		@return An integer from the message.
	*/
	public int GetInt()
	{	int k=pos;
		char ch;
		String S;
		if (EOL) return 0;
		else
		{	ch=TheText.charAt(k);
			while(!EOL&&ch==' ')
			{k=k+1; if (k>=lng) EOL=true; else ch=TheText.charAt(k);}
			if (ch=='-') {k=k+1; if (k>=lng) EOL=true; else ch=TheText.charAt(k);}
			while (!EOL&&Character.isDigit(ch))
			{k=k+1; if (k>=lng) EOL=true; else ch=TheText.charAt(k);}
			if (EOL) {S=TheText.substring(pos,lng); pos=lng;}
			else {S=TheText.substring(pos,k);pos=k;} /* k-1 changed to k */
			return Integer.parseInt(S.trim());
		}
	}
	/** Get a text from the message.
		The message may be read character by character. This will
		get the next n characters as a text string (cut at end of line),
		and advance the current character pointer.
		When end of message is reached the returned text will be cut at 
		end of line, further reading will return a text with zero length.
		@param n Length of text.
		@return A text from message.
	*/
	public String GetText(int n)
	{	int k;
		String S;
		if (n<=0) return "";
		else
		if (EOL) return "";
		else
		{	k=pos+n;
			if (k>=lng) k=lng;
			S=TheText.substring(pos,k);
			pos=k;
			return S;
		}
	}
	/** Set line position.
		The next character position will be changed.
		The position is forced to be within line.
		@param n New line position.
	*/
	public void SetPosition(int n)
	{	if(n<0) n=0; else if(n>lng) n=lng;
		pos=n;
	}
	/** Get line position.
		The next character position will be returned.
		@return the line position.
	*/
	public int GetPosition()
	{	return pos;
	}
	/** Get line length.
		The length of current line will be returned.
		@return the line length.
	*/
	public int Length()
	{	return lng;
	}
	/** Skip a number of characters.
		The next character position will be advanced n steps.
		@param n Number of characters to skip.
	*/
	public void Skip(int n)
	{	int k=0;
		if (EOL) {k=lng;}
		else
		if (n>=0) {k=pos+n; if (k>=lng) k=lng;}
		else
		if (n<0) {k=pos+n; if (k<0) k=0;}
		pos=k;
	}
}
