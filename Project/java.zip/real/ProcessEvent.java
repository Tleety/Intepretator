package real;
/* 
 !***************************************************************
 !		Revision history
 !	0.1	980501 
 ! 1.0	980825
 !	1.1	000831
 !
 !***************************************************************
*/
import struct.*;
/** Objects of this type is used to represent an event.
	The type is a subtype of Element, thus events may be kept
	in structures like lists, sets,..
	The simple ProcessEvent type objects has no contents and
	may be used as signals. If the event should be able to hold a message
	a subtype should be defined and used.
	@author G�ran Fries
	@version 1.1
*/
public class ProcessEvent extends Element
{
	/** Defines when two events are equal.
		They are equal only if they are the same object.
		@param E The object to compare to.
		@return true if it is the same object as this.
	*/
	public boolean Equal(Element E)
	{	if (E instanceof ProcessEvent) {return this==(ProcessEvent)E;}
		else return false;
	}
	/** The key concept is not used.
		Defined to be the same as equal.
		@param E The key element.
		@return true if it is the same object as this.
	*/
	public boolean Key(Element E) {return Equal(E);}
}
