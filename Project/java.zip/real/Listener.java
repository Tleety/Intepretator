
package real;
/* 
 !***************************************************************
 !		Revision history
 !	0.1	980501 
 ! 1.0	980825
 !	1.1	000831
 !***************************************************************
*/
import java.net.*;
/* ****************************************************************
*		Listener
* A Listener object represents a connection through a port to some
* machine, the local host or someone else through an IP address.
* (A ServerSocket is used).
* The main method is NextRequest (using ServerSocket accept), this
* will block the running process until a request is made on the port.
* Then the process will be resumed and a Channel object is returned.
* This Channel object is a connection to a certain machine on this
* port. You may call NextRequest repeatedly.
* Constructor:
*	Listener(int Port)		The listener creates a ServerSocket that
*									may listen for requests on the given port.
* Methods:
*	Open() -->boolean			Returns true if OK else false
*	Close()						The listener (ServerSocket) is closed and may
*									not be used anymore.
*	NextRequest()-->Channel	Waits for someone contacting you, then
*									creating a Channel connection to him.
*	GetMachineName()-->String Returns the name of your own machine
**************************************************************** */
/** Type Listener for someone taking contact on a port.
	An object of this type has a socket connection to a port.
	The object has a method that may listen for something sent to the port.
	The calling process will be blocked until something is recived. As
	long as there is a created but not closed Listener all programs
	trying to connect to this port will be successfull, even if
	no NextRequests will be ever issued. If there is no Listener or
	if the Listener object is closed an attempt to connect will
	fail (Open returns false).
	@author G�ran Fries
	@version 1.1
*/
public class Listener
{	private int PortNumber;
	private ServerSocket TheSocket;
	private boolean Error;
	/** Create a listener object connected to specified port.
		A server socket will be created.
		@param Port The port number.
	*/
	public Listener(int Port)
	{	PortNumber=Port;
		{try
			{	TheSocket=new ServerSocket(PortNumber);}
		 catch (Exception E) {Error=true;}
		}
	}
	/** Test for successfull creation.
		@return true if OK, false if the socket could not be properly created.
	*/
	public boolean Open()
	{return !Error;}
	/** The underlying socket will be closed down.
	*/
	public void Close()
	{try {TheSocket.close();}
	 catch (Exception E) {}
	}
	/** Look for request.
		Wait for someone contacting you on the socket (port).
		The process will be blocked. When a contact is tried
		the process will have the control back, a channel is
		created with that socket and this channel is returned
		as the value of the method.
		@return A channel, or null if an exception occured.
	*/
	public Channel NextRequest()
	{	Socket S;
		if (Error) {return null;}
		else
		{try
			{	S=TheSocket.accept();
				return new Channel(S);
			}
		 catch (Exception E) {return null;}
		}
	}
	/** Get the name of the current machine.
		@return Machine name as a text string.
	*/
	public String GetMachineName()
	{try
		{	InetAddress IAD;
			IAD=TheSocket.getInetAddress();
			IAD=IAD.getLocalHost();
			return IAD.getHostName();
		}
	 catch (Exception E) {return "???";}
	}
}
