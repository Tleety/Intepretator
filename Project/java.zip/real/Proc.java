package real;
/* 
 !***************************************************************
 !		Revision history
 !	0.1	980501 
 ! 1.0	980825 (wait/notify)
 !	1.0.1	981013 minor changes, reschedule after event is sent
 !	1.1	000830 Changed to use the new struct
 !
 !***************************************************************
*/
import struct.*;
/** *****************************************************************
			Proc

 Objects of this type represents a process. This abstract class contains 
 the common definition of all processes. A process contains 
 an execution path through the program  (represented by a Thread object)
 A process also contains some internal memory and state information.
 A process also contains some methods for process control
 A real user process is defined as a subtype of Process, the execution
 path is described by the life code, contained in the method Life.
 This method is defined in Process but in order to be a meaningful
 user process this definition has to be overridden.
 @author G�ran Fries
 @version 1.1
****************************************************************** */
public class Proc extends Element
{
	/*
		Local class
		The object representing the execution path
	*/
	class ProcT extends Thread
	{
		public void run()
		{	State=Running;
			try {Life();}
			catch (Exception e) {System.out.println("Avbruten");}
			State=Terminated;
			AllProcesses.Delete(Proc.this);
		}
		
		public synchronized void Resume()
		{try {notify();}
		 catch (Exception E) {System.out.println("Fel1");}
		}
		public synchronized void Suspend()
		{try {wait();}
		 catch (Exception E) {System.out.println("Fel2");}
		}
		
		synchronized void Schedule() {yield();}
		
		synchronized void Delay(int M)
		{	try {wait(M);}
			catch (InterruptedException e) {System.out.println("Fel3");}
		}
	}
	
	class Stopper extends Thread
	{
		public void run()
		{	TheProc.interrupt();
		}
	}
/*=====================================================================*/
	/* *********************************
	*		The data attributes
	********************************* */
	private ProcT TheProc;
	private Queue Events;
	private int State;	//Running, Waiting, Stopped, Terminated
	private static final int Created=0, Running=1, Waiting=2, Stopped=3, 
									 Terminated=4;
	private static final int Qlim=20; // Event Q limit for warnings
	private static Set AllProcesses=new Set();
	/* *********************************
	*		The constructor
	********************************* */
	
	/** The constructor
		When a Proc process is created a thread object representing
		the execution path (thread) of the process is created. 
		The state of the process is set to created, an empty list of
		events is created, and the process (Proc) is inserted in the
		list of existing processes.
		The process is NOT started!
	*/
	public Proc()
	{	TheProc=new ProcT();
		State=Created;
		Events=new Queue();
		AllProcesses.Insert(this);
	}
	/* *********************************
	*		Default life code 
	*		should never be entered!!!
	********************************* */
	
	/** The "life code" of the process.
		A silly default is defined, this method has to be redefined
		in the subclass representing the real process.
		When the process is running, it is its lifecode that is
		executed.
	*/
	public void Life() throws InterruptedException
	{System.out.println("Process without life code");}
	/** This method does always return true, but does also force a 
		reschedule. This has to be done in some systems where
		time sharing is not properly defined.
	*/
	public boolean Loop() {TheProc.Schedule(); return true;}
	/* *********************************
	*		Book-keeping of processes
	*	through static data and methods 
	********************************* */
	
	/** Makes it possible to get the number of objects of type Proc
		that are existing.
	*/
	public static int GetNumberofProcs() {return AllProcesses.Cardinal();}
	/** Send an event to all existing processes.
		@param PE An object of type ProcessEvent to be sent.
		@see ProcessEvent for event definition.
	*/
	public static void Broadcast(ProcessEvent PE)
	{	final ProcessEvent LPE;
		LPE=PE;
		AllProcesses.Map
		(new Body()	{public void Perform(Element E){((Proc)E).PutEvent(LPE);}});
	}
	/** All processes are killed.
		@see #Kill() Kill a process
	*/
	public static void TerminateAll()
	{	AllProcesses.Map
		(new Body()	{public void Perform(Element E){((Proc)E).Kill();}});
	}
	
	
	/* *********************************
	*		External methods
	********************************* */
	
	/** Start the process. The state is set to Running.
		The execution thread object is started, thus the run
		method of the thread object is called and this method
		just calls the Life method of the process. When this
		Life method is left the process state is set to Terminated,
		the process is removed from active list and the run method 
		is terminated. 
	*/
	public final void Start() {TheProc.start();}
	/** A process that has been stopped is restarted.
	*/
	public final void ReStart()
	{	if (State==Stopped)
			{	State=Running;
				TheProc.Resume();
			}
	}
	/** The process is killed.
		The state is set to Terminated, the thread is stopped
		and the process is removed from the process list.
	*/
	public final void Kill()
	{	State=Terminated;
		//new Stopper().start();
		//TheProc.interrupt();
		TheProc.stop();
		AllProcesses.Delete(this);
	}
	/** An event is sent to this process. Notice that this
		method is normally called from another process. The
		event is inserted into the event queue of this (the
		recieving) process, if its state is Waiting it is
		changed to Running and its thread object is resumed,
		otherwise nothing more then queueing of the event is done.
		At this point a reschedule is enforced.
		@param E the sent process event.
	*/
	public final void PutEvent(ProcessEvent E)
	{	Events.Insert((Element)E);
		if (Events.Cardinal()>Qlim)
			{	System.out.print("Warning Event queue size=");
				System.out.println(Events.Cardinal());
			}
		if (State==Waiting)
			{	State=Running;
				TheProc.Resume();
			}
		Thread.yield();				// allow rescheduling after an event is sent.
	}
	public int GetQueueLength() {return Events.Cardinal();}
	/* *********************************
	*		Internal methods
	*	may only be called from
	*	subclasses of this class
	********************************* */
	
	/** The state of the process is set to Stopped and the
		thread is suspended.
	*/
	protected void Stop()
	{	State=Stopped; 
		TheProc.Suspend();
	}
	/** This method should be executed by the process,
		and it is used to recieve or accept an event.
		If the event queue is empty the state will be
		set to Waiting and the thread will be suspended
		until an event has been inserted into the queue.
		After that the process will start execution again.
		If the queue is not empty or after the execution has 
		been resumed the first event is taken from the queue
		and the method will return with this event as the value.
		@return An available event.
	*/
	protected  ProcessEvent WaitEvent()
	{	if (Events.Empty())
			{	ProcessEvent E;
				State=Waiting;
				TheProc.Suspend();
				State=Running;
				E=(ProcessEvent)Events.TakeOut();
				//Events.Delete(E);
				return E;
			}
		else
			{	ProcessEvent E;
				E=(ProcessEvent)Events.TakeOut();
				//Events.Delete(E);
				return E;
			}
	}
	/** This method should be executed by the process,
		and the process is suspended for a number of milliseconds
		and then resumed.
		@param D Number of milliseconds to wait.
	*/
	protected void WaitTime(int D)
	{TheProc.Delay(D);}
	/* *********************************
	*		Element methods
	*	introduced to be able to
	*	hold processes in sets and lists.
	********************************* */
	
	/** Defines when two processes are equal.
		A process object is only equal to itself.
		@param E Is the element E equal to this process.
		@return true only if it is the same object.
	*/
	public boolean Equal(Element E)
	{return (E instanceof Proc)&&(E==this);}
	/** No special key is used, same as equal.
		@param E The key.
		@return true only if it is the same object.
	*/
	public boolean Key(Element E)
	{return Equal(E);}
	/* this is just the default.
	public boolean Before(Element E){return true;}
	public boolean After(Element E){return true;}
	*/
}
