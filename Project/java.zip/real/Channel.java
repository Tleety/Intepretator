package real;
/*
 !***************************************************************
 !		Revision history
 !	0.1	980501 
 ! 1.0	980825
 ! 1.0.1 981005 Event driven Read
 !	1.0.2	981008 Available and CharsToRead introduced
 !	1.1	000831
 !	1.1.1	000919 test for null in Write
 !***************************************************************
*/
import java.net.*;
import java.io.*;
/* ********************************************************************
* Constructors:
*	Channel(String Host, int Port)	External use, mainly from a
*												client.
*	Channel(Socket S)						Internal use (from a Listener).
* Methods:
*	Open()-->boolean				Returns false if Channel could not be
*										created, else true.
*	Close()							Close the Channel, could not be used after.
*	Write(String S)				Write a string an the socket
*	Read()-->String				Read a string written on the socket.
*	ReadChar()-->char				Read a charachter from the socket.
*	Endfile()-->boolean			True if end of file reached
*	Available()-->boolean 		true if input is available (without blocking)
*	CharsToRead()-->int			number of available characters without blocking.
*	GetHostName()-->String		Get the name of the machine connected to
*	GetMachineName()-->String	Get the name of your local machine
*	GetPort()-->int				Get the port number connected through
*	SetTimeout(int)				A timeout in ms may be set (<0 will be
*										regarded as 0). If a read will block more
*										than this time, the read will be interrupted
*										and the result will be: "\u0004res910405"
*										A timeout of 0 is infinite time, 0 is default.
******************************************************************** */
/** Definition of a Channel.
	A Channel object represents a connection between two "programs"
	executing on the same or different machines. (A Socket is used).
	The Channel has connected to a Socket to I/O streams (InputStream, 
	OutputStream), and has also a number of methods.
	Channels are used together with listeners in the following way 
	(client-server).
		Client											Server
	Create a Channel object using			Create a Listener and issue
	constructor with hostname and port	NextRequest. This will
	number.										return a Channel connected
	Then use this channel for				to the client. Use this
	communication (Read/Write)				for communication (Read/Write)
	
	@author G�ran Fries
	@version 1.1
*/
public class Channel
{	private String HostName;
	private int PortNumber;
	private Socket TheSocket;
	private InputStream TheInput;
	private boolean EOF,Error,Opened;
	private OutputStream TheOutput;
	private final static int NEWLINE=10;
	private final static String TMO="\u0004res910405";
	private int ReadTimeout=0;
	/** Creates a Channel.
		Creates a channel connected to a machine (Host) and
		a port number. A socket object is created. This
		socket has an input stream and an output stream.
		@param Host The name of the machine to connect.
		@param Port The number of the port for communication.
	*/
	public Channel(String Host, int Port)
	{	HostName=Host;
		PortNumber=Port;
		{try
			{	TheSocket=new Socket(HostName,PortNumber);
				TheInput=TheSocket.getInputStream();
				TheOutput=TheSocket.getOutputStream();
				Opened=true;
			}
		  catch (Exception E) {Error=true; Opened=false;}
		 }
		 EOF=false;
	}
	/** Creates a Channel.
		Creates a channel around an existing socket connection.
		This constructor is mainly used internally in the package,
		normally called from a Listner.
		@param S The socket.
	*/
	public Channel(Socket S)
	{	TheSocket=S;
		{try
			{	PortNumber=S.getLocalPort();
				HostName="???";
				TheInput=S.getInputStream();
				TheOutput=S.getOutputStream();
				Opened=true;
			}
		 catch (Exception E) {Error=true; Opened=false;}
		}
	}
/* ******************************************************************* */
	/** Open the channel.
		@return true if the connection OK else false.
	*/
	public boolean Open()
	{ Opened=!Error; return !Error;}
	/** Close the channel.
		The socket will be closed.
	*/
	public void Close()
	{try
		{TheSocket.close(); Opened=false;}
	 catch (Exception E) {Error=true;}
	}
	/** Write to the channel.
		A text string is written to the channel.
		@param S The string to transfer through the channel.
	*/
	public synchronized void Write(String S)
	{	int L;
		if (S==null) {L=0; Error=true;}
		else {L=S.length();}
		if (Opened&&!Error)
		{try
			{	for (int k=0; k<=L-1; k=k+1) TheOutput.write((int) S.charAt(k));
				TheOutput.write(NEWLINE);
				TheOutput.flush();
			}
		 catch (Exception E) {Error=true;}
		}
	}
	/** Read from the channel.
		A text string is fetched from the channel.
		@return A text string from the channel.
	*/
	public  String Read()
	{	int C=-1;
		StringBuffer S;
		S=new StringBuffer();
		if (Opened&&!EOF)
		{try
			{	C=TheInput.read();
				while((C!=-1)&&(C!=NEWLINE))
				{	S.append((char) C);
					C=TheInput.read();
				}
			}
		 catch (InterruptedIOException E) {return TMO;}
		 catch (Exception E) {Error=true;}
		}
		if (C==-1) EOF=true;
		return S.toString();
	}
	/** Read character from channel.
		Just one character is fetched from the channel.
		@return One character from the channel.
	*/
	public  char ReadChar()
	{	int C=-1;
		if (Opened&&!EOF)
		{try
			{	C=TheInput.read();}
		 catch (InterruptedIOException E) {return '\0';}
		 catch (Exception E) {Error=true;}
		}
		if (C==-1) {EOF=true; return '\025';}
		else {return (char)C;}
	}
	/** Is an EOF sent through the channel.
		@return true if EOF recieved.
	*/
	public boolean Endfile()
	{return EOF;}
	/** Something available.
		A test is made whether it is possible to read from the
		channel without blocking or not.
		@return true if something is available on the channel.
	*/
	public boolean Available()
	{try
		{	if (Opened&&!EOF) return TheInput.available()>0;
			else return false;
		}
	 catch (IOException E) {return false;}
	}
	/** Characters available.
		This is almost the same as Available, but instead of a
		boolean result, the number of characters available on the
		channel is returned.
		@return Number of available characters on the channel.
	*/
	public int CharsAvailable()
	{try
		{	if (Opened&&!EOF) return TheInput.available();
			else return 0;
		}
	 catch (IOException E) {return 0;}
	}
	/** Name of machine.
		Get the name of the machine this channel is connected to.
		@return Name of machine connected to.
	*/
	public String GetHostName()
	{	InetAddress IAD;
		IAD=TheSocket.getInetAddress();
		return IAD.getHostName();
	}
	/** Name of machine.
		Get the name of the current machine.
		@return Name of current machine.
	*/
	public String GetMachineName()
	{try
		{	InetAddress IAD;
			IAD=TheSocket.getInetAddress();
			IAD=IAD.getLocalHost();
			return IAD.getHostName();
		}
	 catch (Exception E) {return "???";}
	}
	/** Get port number.
		@return The number of the port for this channel.
	*/
	public int GetPort() {return PortNumber;}
	/** Set a timeout for this channel.
		@param M Timeout in milliseconds.
	*/
	public void SetTimeout(int M)
	{	if (M<0) ReadTimeout=0; else ReadTimeout=M;
		{try
			{TheSocket.setSoTimeout(ReadTimeout);}
		 catch (Exception E) {}
		}
	}
}
