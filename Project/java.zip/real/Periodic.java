package real;
/*
 !***************************************************************
 !		Revision history
 !	0.1	980501 
 ! 1.0	980825
 !	1.0.1	981023 no event sent after beeing closed
 !	1.1	000831
 !
 !***************************************************************
*/
/**	A periodic signal generator.
	Objects of this type will have an execution path (a thread),
	that will run in parallell and will periodically generate and
	send signals to a specified process.
	@author G�ran Fries
	@version 1.1
*/
public class Periodic
{	int Time;
	Proc TheProcess;
	boolean Opened=false;
	Thread Tr�den;
	
	class Period extends Thread
	{	public void run()
		{	
			while (Opened)
			{	try {sleep(Time);}
				catch (InterruptedException e) {};
				if (Opened) TheProcess.PutEvent(new ProcessEvent());
			}
		}
	}
	/** Creates a periodic signal generator connected to a process.
		@param ms Number of milliseconds between signals (on the average)
		@param P The process demanding the signals.
	*/
	public Periodic(int ms,Proc P)
	{	Time=ms;
		TheProcess=P;
		Opened=true;
		Tr�den=new Period();
		Tr�den.start();
	}
	/**	Stop the periodic generator.
		The execution will be stopped and no more signals will be sent.
	*/
	public void Close() {Opened=false;}
}
