package grafIO;
import window.*;
import java.awt.*;
/***********************************************************************
*				TextRuta
* En klass f�r att definiera en enkel Textruta i f�nstret. Textrutan har en
* position och en storlek
* Konstruktor:
*	
* Metoder:
*	selected(int,int)-->boolean	true om angivna kordinater inom rutan
*
***********************************************************************/
class EnkelTextRuta extends TextRuta
{	private String Rubrik;
   private w W;
	private String[] Rader;
	private StringBuffer[] RadBuffrar;
	private int[] Positioner;
	private int X,Y,Max,MaxPos;
	private int X0,Y0,B,H;
	private int R,X1,Y1;
	private final int h=10,b=10;
	private Color RutF�rg,CC,MarkColor=w.red;
	private Color RamF�rg=w.red,GrundF�rg=w.yellow,MarkF�rg=w.white;
	private boolean Active=false;
	private boolean LCK=false;
		
	/***************************************************************/
	EnkelTextRuta(w F,int x,int y,int sz,String Namn, int Rd)
	{	Max=Rd;
		CC=w.blue;
		Rubrik=Namn;
		W=F;
		MaxPos=sz;
		B=b*(sz+1);
		H=(Max+2)*h;
		X0=x; Y0=y;
		X=X0; Y=Y0+10;
		Rader=new String[Max];
		RadBuffrar=new StringBuffer[Max];
		Positioner=new int[Max];
		for (int i=0; i<Max; i=i+1)
		{	Positioner[i]=0;
			RadBuffrar[i]=new StringBuffer();
		}
		R=0; X1=X+2; Y1=Y+(R+1)*h;
	}
	EnkelTextRuta(w F,int x,int y,int sz,String Namn)
	{	Max=1;
		CC=w.blue;
		Rubrik=Namn;
		W=F;
		MaxPos=sz;
		B=b*(sz+1);
		H=(Max+2)*h;
		X0=x; Y0=y;
		X=X0; Y=Y0+10;
		Rader=new String[Max];
		RadBuffrar=new StringBuffer[Max];
		Positioner=new int[Max];
		for (int i=0; i<Max; i=i+1)
		{	Positioner[i]=0;
			RadBuffrar[i]=new StringBuffer();
		}
		R=0; X1=X+2; Y1=Y+(R+1)*h;
	}
	
	public void draw()
   {  Color C;
      C=W.GetFiller();
      W.SetFiller(RamF�rg);
      W.FillRectangle(X0,Y0,X0+B,Y0+10);
      W.SetPosition(X0,Y0+10);
      W.Write(Rubrik);
      W.SetFiller(GrundF�rg);
      W.FillRectangle(X0,Y0+11,X0+B,Y0+H);
      W.SetFiller(C);
   }

	void SetActive(){Active=true;}
	void SetNonActive(){Active=false;}
	void SetScrollable() {};
	
	public boolean Locked() {return LCK;}
   public void Lock() {LCK=true;}
   public void UnLock() {LCK=false;}
		
	boolean selected(int x, int y)
	{return (x>X0)&&(x<X0+B)&&(y>Y0)&&(y<Y0+H);}
		
	public void setcolor(Color C) {GrundF�rg=C;}
	public void SetHeaderColor(Color C) {RamF�rg=C;}
   public void SetFrameColor(Color C) {GrundF�rg=C;}
   public void SetMarkColor(Color C) {MarkF�rg=C;}
		
	void selectpos(int x,int y)
	{	int pos,OldR,OldY1;
		String S;
		OldR=R;
		OldY1=Y1;
		R=(y-Y)/h;
		if (R>=Max) R=Max-1;
		else
		if (R<0) R=0;
		Y1=Y+(R+1)*h;
		pos=(x-X-2)/b;
		if (pos>RadBuffrar[R].length()) pos=RadBuffrar[R].length();
		else
		if (pos<0) pos=0;
		Positioner[R]=pos;
		if (OldR!=R) {output(RadBuffrar[OldR],X1,OldY1);}
		output (RadBuffrar[R],X1,Y1,pos);
	}
		
	void mark()
	{	Color C;
		Active=true;
		C=W.GetFiller();
		W.SetFiller(MarkF�rg);
		W.FillRectangle(X,Y,X+B,Y+(Max+1)*h);
		W.SetFiller(C);
		for(int i=0; i<Max; i=i+1)
		{output(RadBuffrar[i],X1,Y+(i+1)*h);}
		//W.SetFiller(MarkColor);
	}
		
	void unmark()
	{	Color C;
		Active=false;
		C=W.GetFiller();
		W.SetFiller(GrundF�rg);
		W.FillRectangle(X,Y,X+B,Y+(Max+1)*h);
		//W.DrawRectangle(X,Y,X+B,Y+(Max+1)*h);
		W.SetFiller(C);
		for(int i=0; i<Max; i=i+1)
		{output(RadBuffrar[i],X1,Y+(i+1)*h);}
	}
	public void commandkey(int C) {}
		
	void insertchar(char c)
	{	if (Positioner[R]<MaxPos)
		{	erase(RadBuffrar[R],X1,Y1);
			RadBuffrar[R].ensureCapacity(RadBuffrar[R].length()+1);
			RadBuffrar[R]=RadBuffrar[R].insert(Positioner[R],c);
			Positioner[R]=Positioner[R]+1;
			output(RadBuffrar[R],X1,Y1,Positioner[R]);
		}
	}
		
	void deletechar()
	{	int L;
		L=RadBuffrar[R].length();
		erase(RadBuffrar[R],X1,Y1);
		if (Positioner[R]>0)
		{	for (int i=Positioner[R]; i<L; i=i+1)
			{RadBuffrar[R].setCharAt(i-1,RadBuffrar[R].charAt(i));}
			RadBuffrar[R].setLength(L-1);
			Positioner[R]=Positioner[R]-1;
		}
		output(RadBuffrar[R],X1,Y1,Positioner[R]);
	}
		
	String[] gettext()
	{	for(int i=0; i<Max; i=i+1) {Rader[i]=RadBuffrar[i].toString();}
		return Rader;
	}
	
	void puttext(String S) {puttext(S,0);}
		
	void puttext(String[] S)
	{	int m;
		if (S.length<Max) m=S.length; else m=Max;
		for(int i=0; i<m; i=i+1)
			{	if (RadBuffrar[i]!=null) erase(RadBuffrar[i],X1,Y+(i+1)*h);
				if (S[i].length()>MaxPos) S[i]=S[i].substring(0,MaxPos);
				RadBuffrar[i]=new StringBuffer(S[i]);
				Positioner[i]=0;
				output(RadBuffrar[i],X1,Y+(i+1)*h);
			}
	}
	void puttext(String[] S,int r)
	{	if (r<0||r>Max) {}
		else
			{	if (RadBuffrar[r]!=null) erase(RadBuffrar[r],X1,Y+(r+1)*h);
				if (S[r].length()>MaxPos) S[r]=S[r].substring(0,MaxPos);
				RadBuffrar[r]=new StringBuffer(S[r]);
				Positioner[r]=0;
				output(RadBuffrar[r],X1,Y+(r+1)*h);
			}
	}
		
	void puttext(String S,int r)
	{	if (r<0||r>Max) {}
		else
			{	if (RadBuffrar[r]!=null) erase(RadBuffrar[r],X1,Y+(r+1)*h);
				if (S.length()>MaxPos) S=S.substring(0,MaxPos);
				RadBuffrar[r]=new StringBuffer(S);
				Positioner[r]=0;
				output(RadBuffrar[r],X1,Y+(r+1)*h);
			}
	}
		
	void clear()
	{	W.EraseFilledRectangle(X,Y-10,X+B,Y+(Max+1)*h);
		W.ClearRectangle(X,Y-10,X+B+1,Y+(Max+1)*h+1);
		W.SetPosition(X,Y);
		W.Erase(Rubrik);
		Active=false;
	}
	/***************************************************************
	*			Lokala hj�lprutiner
	***************************************************************/
	private void output(StringBuffer S,int x,int y)
	{	char c;
		int cur;
		String T;
		cur=x;
		for (int i=0; i<S.length(); i=i+1)
		{	W.SetPosition(cur,y);
			c=S.charAt(i);
			T=new Character(c).toString();
			W.Write(T);
			cur=cur+b;
		}
	}
	private void output(StringBuffer R,int x,int y,int pos)
	{	String S;
		S=R.toString();
		output(new StringBuffer(S.substring(0,pos)),X1,Y1);
		if (pos<S.length()) markchar(S.charAt(pos),X1+(pos*b),Y1);
		if (pos<S.length()-1)
			output(new StringBuffer(S.substring(pos+1)),X1+(pos+1)*b,Y1);
	}
	private void erase(StringBuffer S,int x,int y)
	{	char c;
		int cur;
		String T;
		cur=x;
		if (!Active) W.SetPen(GrundF�rg);
		else W.SetPen(MarkF�rg);
		for (int i=0; i<S.length(); i=i+1)
		{	W.SetPosition(cur,y);
			c=S.charAt(i);
			T=new Character(c).toString();
			W.Write(T);
			cur=cur+b;
		}
		W.SetPen(w.black);
	}
	private void markchar(char c,int x,int y)
	{	String T;
		W.SetPosition(x,y);
		W.SetPen(MarkColor);
		T=new Character(c).toString();
		W.Write(T);
		W.SetPen(w.black);
	}
		
}
