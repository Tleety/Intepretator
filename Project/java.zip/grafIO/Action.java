package grafIO;
public abstract class Action
{	public abstract void DoAction();
}
