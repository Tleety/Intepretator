package grafIO;
import window.*;
import java.awt.*;

/* *********************************************
*********		                 ****************
*********                       ****************
********* ver 0.1 Close, open rekt. knapp ******
********* ver 0.2 felr�ttning, ny Input ********
********* ver 0.3 F�rgade knappar,text,linjer **
********* ver 0.4 Sm�saker gjorda **************
********* ver 0.5 suddning i ruta **************
********* ver 0.6 �teranv�nder knapp/rut nr ****
********* ver 0.7 sm�rre �ndringar *************
********* ver 0.7.1 sm�rre �ndringar ***********
*********                       ****************
********* ver 1.0 St�rre om�ndring  ************
*********   hantering av bilder (Image) ********
********* ver 2.0 St�rre om�ndring  ************
*********   till�gg av komplexa textrutor ******
*********                       ****************
*********   senaste �ndring 030402  ************
*********   senaste pytte�ndring         *******
*********                       ****************
*********                       ****************
*********      G�ran Fries      ****************
***********************************************/

/* **********************************************************************
*		Grafiskt gr�nssnitt
*
* Denna klass kan anv�ndas f�r att ha ett f�nster som gr�nssnitt
* mot programanv�ndaren. I detta f�nster kan man definiera 
* kommandoknappar. Dessutom In/Ut-rutor samt knappar. Till dessa knappar
* kan man knyta aktiviteter. Avsikten med klassen grafisk �r att ha
* ett generellt gr�nssnitt som l�tt kan anv�ndas i ett antal helt
* olika situationer.
* Konstruktor:
*	Parametrar: int vidd,h�jd; String titel; Color f�rg; int knappar
*	Funktion:	H�r skapas ett f�nster av angiven storlek, med titel
*					som rubrik och med angiven bakgrundsf�rg. Om f�rg=null
*					s� f�r man en ful bl� som default. Knappar anger hur
*					m�nga kommandoknappar man maximalt kan ha.
*					Knappar textrutor mm f�r man sedan sj�lv l�gga in!
*
* Statiska "konstanter" och metoder:
* F�ljande f�rger finns: 	black,blue,gray,green,orange,
*									pink,red,yellow,white
* F�rgskapande metoden MakeColor(R,G,B) som ger en f�rg (int R,G,B)
* Alla f�rger �r naturligtvis objekt av typ Color
*
* Metoder:
***MakeCommandButton			************************************
*	Parametrar:	int x,y,storlek; String namn [Color]
*					[storlek kan ers�ttas av bredd,h�jd]
*	Funktion:	Skapa en kvadratisk knapp med v�nster �vre h�rn i x,y
*					och med sidan storlek. Kan �ven skapas rektangul�r.
*					Namn skrivs p� knappen. Kan ges f�rg. Denna
*					knapp registreras som kommandoknapp och identifieras
*					med ett nummer. Om fler �n maximalt till�tna antal knappar
*					f�rs�ker skapas blir det inget!
*	Resultat:	int. Knapparna f�r ett nummer 1,2,3,... 0 betyder ingen
*					knapp skapad.
***DrawButtons					************************************
*	Parametrar:	inga
*	Funktion:	Skapade kommandoknappar ritas ut.
*	Resultat:	inget
***GetCommand					************************************
*	Parametrar:	int TimeOut
*	Funktion:	Programmet v�ntar tills en av kommandoknapparna trycks
*					p�. (Mouse button released) D� returneras nummret p�
*					den knappen. Andra aktiviteter ignoreras. Om ingen knapp
*					trycks p� inom s� m�nga sekunder som TimeOut anger s�
*					returneras att ingen knapp tryckts p�. TimeOut=0 anger
*					o�ndlig v�ntetid. Nedtryckt knapp r�df�rgad tills
*					annan knapp trycks p� eller sl�ppt (ReleaseCommand).
*	Resultat:	int. Nummret p� tryckt knapp, 1,2,3,.... 0 anger ingen
*					knapp tryckt.
***ReleaseCommand				************************************
*	Parametrar:	inga
*	Funktion:	Tidigare r�d knapp ej l�ngre r�d, samt senaste kommando
*					satt till inget.
*	Resultat:	inget
***MakeTextFrame				************************************
*	Parametrar:	int x,y,storlek; String rubrik; [int rader]
*	Funktion:	Skapa en ruta med �vre v�nster h�rn i x,y och med plats
*					f�r storlek tecken i bredd. Rutans h�jd avg�rs av programmet
*					f�r att kunna h�lla ett visst antal rader. Antalet
*					rader anges av den "frivilliga" parametern rader, 
*					default �r en rad. Rutan kan g�ras aktiv genom att man
*					klickar i den. Aktiv ruta �r vit. Text skriven hamnar i
*					aktiv ruta. Man kan klicka i texten och f�r d� motsvarande
*					tecken markerat (r�d). Text kommer nu att skjutas in
*					f�re markerat tecken. Man kan naturligtvis byta mellan ett
*					antal rutor. Man kan naturligtvis s� sm�ningom �verf�ra
*					en rutas text till programmet.
*	Resultat:	int. Anger ett nummer p� rutan, 1,2,3...20. 
***MakeButton					************************************
*	Parametrar:	int x,y,storlek; String namn [Color]
*	Funktion:	G�r en knapp p� samma s�tt som en kommandoknapp, men
*					den registreras i st�llet p� samma s�tt som en textruta.
*					Trycker man p� knappen s� blinkar den till (r�d), �r det
*					dessutom en "stoppknapp" s� h�nder lite mer (se Input).
*					Man kan ocks� knyta en aktivitet till en s�dan knapp-
*					tryckning. Kan g�ras rektangul�r och i f�rg.
*	Resultat:	int. Anger nummer p� knappen, 1,2,3,.....,20.
***Input							************************************
*	Parametrar:	int stopp
*	Funktion:	F�nstret �r nu k�nsligt f�r tryckningar i textrutor
*					och vanliga knappar (ej kommandon). Parametern stopp
*					anger vilken knapp som ska betraktas som stoppknapp.
*					D� man trycker p� en s�dan "fryses" f�nstret och �r
*					inte l�ngre k�nsligt f�r tryckningar, samt �terv�nder
*					man fr�n Input. Man kan �ter g�ra f�nstret k�nsligt
*					genom att anropa Input igen.
* 					Man kan ocks� l�mna Input genom Action!
*	Resultat:	int ett v�rde som Action kan ha l�mnat annars 0
***GetInfo						************************************
*	Parametrar:	int ruta
*	Funktion:	Man kan komma �t texten som finns inskriven i angiven
*					ruta.
*	Resultat:	String[]. En f�ljd av texter, dvs raderna i f�nstret.
***PutInfo						************************************
*	Parametrar:	int ruta; String[] texter 
*					int ruta,rad; String[] texter
*					int ruta,rad; String text
*	Funktion:	Man �ndrar angiven rutas textinneh�ll till det nya.
*					Man kan inte l�gga in fler textrader �n som finns i
*					textrutan, anger man f�rre kommer �vriga (avslutande)
*					textrader i rutan inte att �ndras. Om de nya raderna
*					�r f�r l�nga f�r rutan kommer de att trunkeras. Om rad 
*					angiven som parameter s� �ndras bara angiven rad. Detta
*					kan g�ras p� tv� s�tt: 1) om texter s� ska denna array
*					vara lika stor som antalet rader och motsvarande rad
*					och plats i String array ber�rs. 2) om text s� �ndras
*					angiven rad till denna text
*	Resultat:	inget
***Clear							************************************
*	Parametrar:	ingen eller int ruta eller int ruta,knapp
*	Funktion:	utan parametrar t�mmer denna och tar bort samtliga
*					textrutor och knappar (ej kommandoknappar). Den
*					�terst�ller ocks� �vriga egenskaper (aktiv ruta,antal
*					rutor, knappar,....).
*					Med en parameter tar den endast bort angiven ruta, samt
*					�terst�ller inga andra egenskaper. Med tv� parametrar
*					tar den bort angiven ruta och knapp. (ruta=0 ger inget)
*	Resultat:	inget
***RegisterAction				************************************
*	Parametrar:	int knapp; Action A
*	Funktion:	registrera aktiviteten A hos knappen knapp. Om man
*					trycker p� knappen s� utf�rs aktiviteten.
*					OBS en aktivitet kan anropa f�nstrets LeaveInput(int)
*					som medf�r att Input l�mnas med angivet v�rde, d� man
*					trycker p� denna knapp.
*	Resultat:	inget
***DeRegisterAction			************************************
*	Parametrar:	int knapp
*	Funktion:	ta bort aktiviteten f�e en viss knapp
*	Resultat:	inget
***Write
*	Parametrar:	int x,y String S
*	Funktion:	Skriver en text S i f�nstret p� position x,y
*	Resultat:	inget
***Draw
*	Parametrar:	int x0,y0,x1,y1 [Color C]
*	Funktion:	Ritar en linje fr�n x0,y0 till x1,y1 (med f�rg C om 
*					parametern med)
*	Resultat:	inget
***Erase
*	Parametrar:	int x0,y0,x1,y1 alternativt int x,y String S
*	Funktion:	Suddar en linje resp en text. Detta �r s�ledes omv�ndningen
*					till Draw resp Write
*	Resultat:	inget
***Close
*	Parametrar:	ingen eller int
*	Funktion:	Om parametern=0 eller ingen parameter st�ngs f�nstret ner
*					och tas bort. Om parametern ej noll s� st�ngs f�nstret,
*					men kan �ter �ppnas.
*	Resultat:	inget
***Open
*	Parametrar:	inga
*	Funktion:	�ter�ppnar och visar ett st�ngt men ej borttaget f�nster.
*	Resultat:	inget
*
***********************************************************************/
public class grafisk
{	protected w W;
	private Knapp[] K;
	private static final int MaxKnapp=30;
	private static final int MaxRuta=30;
	private int MaxUsed=0;
	private int Commands;
	private int LastCommand=-1;
	private TextRuta[] TR=new TextRuta[MaxRuta];
	private boolean[] LedigRuta=new boolean[MaxRuta];
	private int Rutor=-1,Active=-1;
	private Knapp[] KR=new Knapp[MaxKnapp];
	private boolean[] LedigKnapp=new boolean[MaxKnapp];
	private int Knappar=-1;
	private boolean Leave=false;
	private int ReturnValue=0;
	private Color MarkColor,CC;
	
	public static final Color 
		black=Color.black,
		blue=Color.blue,
		gray=Color.gray,
		green=Color.green,
		orange=Color.orange,
		pink=Color.pink,
		red=Color.red,
		yellow=Color.yellow,
		white=Color.white;
	
	public static Color MakeColor(int R, int G, int B)
	{return new Color(R,G,B);}
/*********************************************************************
*					Klassen grafisk
* 
*
*********************************************************************/	
	/** Constructor creating an object of type grafisk representing
	    a window used for I/O by buttons and textframes of different
	    complexity.
	    @param width the width of the window in pixels
	    @param height the height of the window in pixels
	    @param title a string used in the titlebar of the window
	    @param C the background colour of the window
	    @param buttons the max number of command buttons
	*/
	public grafisk(int width, int height, String title, Color C, int buttons)
	{	//Color CC;
		if (C==null) CC=blue; else CC=C;
		W=new w(width,height,title,CC);
		MarkColor=red;
		W.SetFiller(MarkColor);
		W.EnableMouse();
		W.EnableKey();
		Commands=buttons;		
		K=new Knapp[Commands];
		Frig�rKnapp();
		Frig�rRuta();
	}
/*********************************************************************
*			Grundl�ggande metoder
*
*********************************************************************/
	/** Used to create a command button in the window
		@param x x coordinate of top leftmost corner
		@param y y coordinate of top leftmost corner
		@param size size of button in pixels (width=height)
		@param name text on the button
		@return a number identifying the button
	*/
	public int MakeCommandButton(int x,int y,int size,String name)
	{	if (MaxUsed>=Commands) {return 0;}
		else
			{	K[MaxUsed]=new Knapp(W,name,x,y,size);
				MaxUsed=MaxUsed+1;
				return MaxUsed;
			}
	}
	/** Used to create a command button in the window
		@param x x coordinate of top leftmost corner
		@param y y coordinate of top leftmost corner
		@param size size of button in pixels (width=height)
		@param name text on the button
		@param C the colour of the button
		@return a number identifying the button
	*/
	public int MakeCommandButton(int x,int y,int size,String name,Color C)
	{	if (MaxUsed>=Commands) {return 0;}
		else
			{	K[MaxUsed]=new Knapp(W,name,x,y,size,C);
				MaxUsed=MaxUsed+1;
				return MaxUsed;
			}
	}
	/** Used to create a command button in the window
		@param x x coordinate of top leftmost corner
		@param y y coordinate of top leftmost corner
		@param b size of button in pixels (width)
		@param h size of button in pixels (height)
		@param name text on the button
		@return a number identifying the button
	*/
	public int MakeCommandButton(int x,int y,int b,int h,String name)
	{	if (MaxUsed>=Commands) {return 0;}
		else
			{	K[MaxUsed]=new Knapp(W,name,x,y,b,h);
				MaxUsed=MaxUsed+1;
				return MaxUsed;
			}
	}
	/** Used to create a command button in the window
		@param x x coordinate of top leftmost corner
		@param y y coordinate of top leftmost corner
		@param b size of button in pixels (width)
		@param h size of button in pixels (height)
		@param name text on the button
		@param C the colour of the button
		@return a number identifying the button
	*/
	public int MakeCommandButton(int x,int y,int b,int h,String name,Color C)
	{	if (MaxUsed>=Commands) {return 0;}
		else
			{	K[MaxUsed]=new Knapp(W,name,x,y,b,h,C);
				MaxUsed=MaxUsed+1;
				return MaxUsed;
			}
	}
	/** Used to create a button in the window
		@param x x coordinate of top leftmost corner
		@param y y coordinate of top leftmost corner
		@param size size of button in pixels (width=height)
		@param name text on the button
		@return a number identifying the button
	*/
	public int MakeButton(int x,int y,int size,String name)
	{	Knappar=FriKnapp();
		if (Knappar==-1||Knappar>=MaxKnapp) return 0;
		KR[Knappar]=new Knapp(W,name,x,y,size);
		KR[Knappar].draw();
		return Knappar+1;
	}
	/** Used to create a button in the window
		@param x x coordinate of top leftmost corner
		@param y y coordinate of top leftmost corner
		@param size size of button in pixels (width=height)
		@param name text on the button
		@param C the colour of the button
		@return a number identifying the button
	*/
	public int MakeButton(int x,int y,int size,String name,Color C)
	{	Knappar=FriKnapp();
		if (Knappar==-1||Knappar>=MaxKnapp) return 0;
		KR[Knappar]=new Knapp(W,name,x,y,size,C);
		KR[Knappar].draw();
		return Knappar+1;
	}
	/** Used to create a button in the window
		@param x x coordinate of top leftmost corner
		@param y y coordinate of top leftmost corner
		@param b size of button in pixels (width)
		@param h size of button in pixels (height)
		@param name text on the button
		@return a number identifying the button
	*/
	public int MakeButton(int x,int y,int b,int h,String name)
	{	Knappar=FriKnapp();
		if (Knappar==-1||Knappar>=MaxKnapp) return 0;
		KR[Knappar]=new Knapp(W,name,x,y,b,h);
		KR[Knappar].draw();
		return Knappar+1;
	}
	/** Used to create a button in the window
		@param x x coordinate of top leftmost corner
		@param y y coordinate of top leftmost corner
		@param b size of button in pixels (width)
		@param h size of button in pixels (height)
		@param name text on the button
		@param C the colour of the button
		@return a number identifying the button
	*/
	public int MakeButton(int x,int y,int b,int h,String name,Color C)
	{	Knappar=FriKnapp();
		if (Knappar==-1||Knappar>=MaxKnapp) return 0;
		KR[Knappar]=new Knapp(W,name,x,y,b,h,C);
		KR[Knappar].draw();
		return Knappar+1;
	}
	/** Command buttons are not automatically drawn. This method will
		draw the command buttons in the window.
	*/
	public void DrawButtons()
	{for (int i=0; i<MaxUsed; i=i+1) K[i].draw();}
	/** This method will wait until one of the command buttons will be
		pressed and released, then the number of the pressed button will
		be returned. There is a time out in seconds given as a parameter,
		if no button will be pressed before time out a zero will be returned.
		A time out time of 0 means "for ever". The pressed command button
		will be marked until another button is pressed or the command is
		released by the ReleaseCommand method.
		@param TM time out in seconds (0 for infinite wait)
		@return the number identifying pressed button (0 if timed out)
	*/
	public int GetCommand(int TM)
	{	Message M;
		boolean Fixed=false;
		int i=0, n=0;
		while(!Fixed)
		{	M=W.GetEvent();
			if (M==null) {}
			else
			if (M instanceof MouseMessage)
				{	if (((MouseMessage) M).GetDirection()==MouseMessage.Released)
						{	int x,y;
							boolean OK=false;
							x=((MouseMessage) M).Getx();
							y=((MouseMessage) M).Gety();
							i=0;
							while (!OK &&i<MaxUsed)
							{	if (K[i].selected(x,y)) {OK=true;}
								else {i=i+1;}
							}
							if (OK) {Fixed=true;} else {i=0;}
						}
					else {}
				}
			else
			if (M instanceof KeyMessage) {}
			else {}
			W.Delay(20);
			n=n+1;
			if (TM!=0) {if (n==TM*50) {i=-1; Fixed=true;}}
		}
		if (LastCommand>=0) {K[LastCommand].unmark();}
		LastCommand=i;
		if (LastCommand>=0) {K[LastCommand].marked();}
		return i+1;
	}
	/** This method gives the control to window input. It is then 
		possible to edit text in text frames and to press buttons
		(not command buttons). This method has a stop button and when
		this is pressed a return will be made. If some other button
		is pressed some registered action connected to this button 
		will be performed, often a return with a certain value.
		@param stop the number identifying the stop button
		@return 0 if stop button else a number depending on action
	*/ 
	public int Input(int stop)
	{	Message M;
		TextRuta ValdTR=null;
		Knapp ValdKnapp=null;
		int x=0,y=0;
		boolean Fixed=false;
		int i=0;
		ReturnValue=0;
		while(!Fixed)
		{	
			M=W.GetEvent();
			if (M==null) {}
			else
			if (M instanceof MouseMessage)
				{	
					if (((MouseMessage) M).GetDirection()==MouseMessage.Released)
						{	boolean OK=false;
							x=((MouseMessage) M).Getx();
							y=((MouseMessage) M).Gety();
							i=0;
							while (!OK &&i<MaxRuta)
							{	if (TR[i]!=null&&TR[i].selected(x,y))
								{OK=true;ValdTR=TR[i];}
								else {i=i+1;}
							}
							if (!OK) i=0;
							while (!OK &&i<MaxKnapp)
							{	if (KR[i]!=null&&KR[i].selected(x,y))
									{OK=true;ValdKnapp=KR[i];}
								else {i=i+1;}
							}
							
						}
					else {}
				}
			else
			if (M instanceof KeyMessage)
				{	KeyMessage K;
					K=(KeyMessage)M;
					if (Active<0) {}
					else
					if (K.GetDirection()==KeyMessage.Pressed) {}
					else
					if (K.CharacterKey())
					{	char c;
						c=K.GetKeyChar();
						if (c=='\b') {TR[Active].deletechar();}
						else
						if (c=='\177') {TR[Active].deletechar();}
						else {TR[Active].insertchar(c);}
					}
					else
					if (K.GetDirection()==KeyMessage.Released&&!K.CharacterKey())
					{	int I;
						I=K.GetKeyCode();
						TR[Active].commandkey(I);
					}
					else {}
				}
			else {}
			
			
			if (ValdTR!=null&&ValdTR.Locked())
			{	if (Active>=0)
				{TR[Active].unmark();TR[Active].SetNonActive();}
				Active=i;
				ValdTR.SetScrollable();
			}
			else
			if(ValdTR!=null)
				{	if (i==Active)
						{	ValdTR.selectpos(x,y);
						}
					else
						{	if (Active>=0)
						   {TR[Active].unmark();TR[Active].SetNonActive();}
							Active=i;
							ValdTR.mark();
							ValdTR.SetActive();
						}
				}
			else
			if (ValdKnapp!=null)
				{	ValdKnapp.blink();
					if (stop==0) Fixed=true;
					else
					if (i==stop-1) Fixed=true;
					else 
						{	ValdKnapp.Perform();
							if (Leave) Fixed=true;
							Leave=false;
						}
				}
			ValdTR=null; ValdKnapp=null;
			W.Delay(20);
		}
		return ReturnValue;
	}
	/** An action may be registered connected to a normal (not command)
		button. The action is represented by an object, and its DoAction
		method implements the action code.
		@param k identifies the button 
		@param A the object defining the action
	*/
	public void RegisterAction(int k,Action A)
	{	if (k==0) {}
		else
		if (k>MaxKnapp+1) {}
		else 
		if (KR[k-1]!=null) KR[k-1].SetAction(A);
	}
	/** The registered action connected to given button will be
		removed.
		@param k identifies the button
	*/
	public void DeRegisterAction(int k)
	{if (k>0&&k<=MaxKnapp&&KR[k-1]!=null) KR[k-1].RemoveAction();}
	/** A command will be released, the commandbutton will not
		be marked anymore.
	*/
	public void ReleaseCommand()
	{	if (LastCommand>=0) {K[LastCommand].unmark();}
		LastCommand=-1;
	}
	/** Create a simple textframe. The frame may hold a fixed number (=1)
		of lines with fixed length. 
		@param x x coordinate of top leftmost corner
		@param y y coordinate of top leftmost corner
		@param s size of line in number of characters
		@param Rub the title of the frame
		@return a number identifying the text frame
	*/
	public int MakeTextFrame(int x,int y,int s,String Rub)
	{	Rutor=FriRuta();
		if (Rutor==-1||Rutor>=MaxRuta) return 0;
		TR[Rutor]=new EnkelTextRuta(W,x,y,s,Rub);
		TR[Rutor].draw();
		return Rutor+1;
	}
	/** Create a simple textframe. The frame may hold a fixed number
		of lines with fixed length. 
		@param x x coordinate of top leftmost corner
		@param y y coordinate of top leftmost corner
		@param s size of line in number of characters
		@param Rub the title of the frame
		@param r the number of lines in the frame
		@return a number identifying the text frame
	*/
	public int MakeTextFrame(int x,int y,int s,String Rub,int r)
	{	Rutor=FriRuta();
		if (Rutor==-1||Rutor>=MaxRuta) return 0;
		TR[Rutor]=new EnkelTextRuta(W,x,y,s,Rub,r);
		TR[Rutor].draw();
		return Rutor+1;
	}
	/** Create a complex text frame that may hold any number of lines.
		Each line may hold a limited number of characters.
	*/
	public int MakeComplexTextFrame(int x,int y,int s,int t,String Rub)
	{	Rutor=FriRuta();
		if (Rutor==-1||Rutor>=MaxRuta) return 0;
		TR[Rutor]=new KomplexTextRuta(W,x,y,s,t,Rub);
		TR[Rutor].draw();
		return Rutor+1;
	}
	
	/** Set the header colour of a textframe.
		@param i the number identifying the frame
		@param C the colour
	*/
	public void SetHeaderColor(int i, Color C)
	{	if(i>0&&i<=MaxRuta) TR[i-1].SetHeaderColor(C);}
	
	/** Set the frame colour of a textframe.
		@param i the number identifying the frame
		@param C the colour
	*/
	public void SetFrameColor(int i, Color C)
	{	if(i>0&&i<=MaxRuta) TR[i-1].SetFrameColor(C);}
	
	/** Set the mark colour of a textframe.
		@param i the number identifying the frame
		@param C the colour
	*/
	public void SetMarkColor(int i, Color C)
	{	if(i>0&&i<=MaxRuta) TR[i-1].SetMarkColor(C);}
	
	/** Set textframe as display only.
		@param i the number identifying the frame
	*/
	public void SetDisplayOnly(int i)
	{	if(i>0&&i<=MaxRuta) TR[i-1].Lock();}
	
	/** Set textframe as a normal editable frame.
		@param i the number identifying the frame
	*/
	public void SetEditMode(int i)
	{	if(i>0&&i<=MaxRuta) TR[i-1].UnLock();}

	/** Read the text in a textframe of some kind. The text is returned
		as an array of strings ("lines").
		@param i an integer used to identify the text frame
		@return the text as a String[]
	*/
		
	public String[] GetInfo(int i)
	{	if (i==0) {if (Active<0) return null; else return TR[Active].gettext();}
		else
		if (i>MaxRuta) {return null;}
		else
		if (TR[i-1]!=null) return TR[i-1].gettext();
		else {return null;}
	}
	/** Write a text to a text frame of some kind. Here one string
		is written.
		@param i an integer used to identify the text frame
		@param S the string to write
	*/
	public void PutInfo(int i,String S)
	{	if (i==0) {if (Active>=0) TR[Active].puttext(S);}
		else
		if (i>MaxRuta) {}
		else
		if (TR[i-1]!=null) TR[i-1].puttext(S);
		else {}
	}
	/** Write a text to a text frame of some kind. Here a number of
		strings are written.
		@param i an integer used to identify the text frame
		@param S the strings to write
	*/
	public void PutInfo(int i,String[] S)
	{	if (i==0) {if (Active>=0) TR[Active].puttext(S);}
		else
		if (i>MaxRuta) {}
		else
		if (TR[i-1]!=null) TR[i-1].puttext(S);
		else {}
	}
	/** Write a text to a text frame of some kind. Here a number of
		strings are written.
		@param i an integer used to identify the text frame
		@param r start writing at line r
		@param S the strings to write
	*/
	public void PutInfo(int i,int r,String[] S)
	{	if (i==0) {if (Active>=0) TR[Active].puttext(S,r-1);}
		else
		if (i>MaxRuta) {}
		else
		if (TR[i-1]!=null) TR[i-1].puttext(S,r-1);
		else {}
	}
	/** Write a text to a text frame of some kind. Here one
		string is written.
		@param i an integer used to identify the text frame
		@param r start writing at line r
		@param S the string to write
	*/
	public void PutInfo(int i,int r,String S)
	{	if (i==0) {if (Active>=0) TR[Active].puttext(S,r-1);}
		else
		if (i>MaxRuta) {}
		else
		if (TR[i-1]!=null) TR[i-1].puttext(S,r-1);
		else {}
	}
	/** Clear textframes and buttons. Here all are cleared and
		removed.
	*/
	public void Clear()
	{	for(int j=0; j<MaxRuta; j=j+1)
		{	if (TR[j]!=null) {TR[j].clear(); TR[j]=null;}}
		Frig�rRuta();
		for(int k=0; k<MaxKnapp; k=k+1)
		{	if (KR[k]!=null) {KR[k].clear(); KR[k]=null;}}
		Frig�rKnapp();
		Active=-1;
	}
	/** Clear textframe. Here one textframe is cleared and
		removed.
		@param x identifies the frame to remove
	*/
	public void Clear(int x)
	{	if (x>0 && x<=MaxRuta)
		{	TR[x-1].clear();
			TR[x-1]=null;
			Frig�rRuta(x-1);
			if (Active==x-1) Active=-1;
		}
	}
	/** Clear textframe and button. Here one textframe and one button
		is cleared and removed. x=0 or y=0 means no frame/button to remove
		@param x identifies the frame to remove
		@param y identifies the button to remove
	*/
	public void Clear(int x,int y)
	{	
		if (x>0 && x<=MaxRuta&&TR[x-1]!=null)
		{	TR[x-1].clear();
			TR[x-1]=null;
			Frig�rRuta(x-1);
			if (Active==x-1) Active=-1;
		}
		if (y>0 && y<=MaxKnapp&&KR[y-1]!=null)
			{KR[y-1].clear(); KR[y-1]=null; Frig�rKnapp(y-1);}
	}
	/** Close and remove the graphical window
	*/
	public void Close()
	{W.Destroy(); W=null;}
	/** Close and if parameter is 0 remove the graphical window
		@param I if 0 close and remove else only close the window.
	*/
	public void Close(int I)
	{	if (I==0) {W.Destroy();W=null;}
		else {W.Close();}
	}
	/** If possible open the window.
	*/
	public void Open()
	{if (W!=null) W.Open(null);}
	
	/*****************************************************
	*		Diverse udda metoder mot f�nstret
	*****************************************************/
	/** Write a plain text somewhere in the window.
		@param x start position of text (x)
		@param y start position of text (y)
		@param T text to be written
	*/
	public void Write(int x, int y, String T)
	{	W.SetPosition(x,y);
		W.Write(T);
	}
	/** Draw a line somewhere in the window.
		@param x0 start position of line (x)
		@param y0 start position of line (y)
		@param x1 end position of line (x)
		@param y1 end position of line (y)
	*/
	public void Draw(int x0, int y0, int x1, int y1)
	{	W.DrawLine(x0,y0,x1,y1);}
	/** Draw a line of given colour somewhere in the window.
		@param x0 start position of line (x)
		@param y0 start position of line (y)
		@param x1 end position of line (x)
		@param y1 end position of line (y)
		@param C  colour of the line
	*/
	public void Draw(int x0, int y0, int x1, int y1, Color C)
	{	W.SetPen(C);
		W.DrawLine(x0,y0,x1,y1);
		W.SetPen(w.black);
	}
	/** Erase a plain text written in the window.
		@param x start position of text (x)
		@param y start position of text (y)
		@param T text to erase
	*/
	public void Erase(int x, int y, String T)
	{	W.SetPosition(x,y);
		W.Erase(T);
	}
	/** Erase a line drawn in the window.
		@param x0 start position of line (x)
		@param y0 start position of line (y)
		@param x1 end position of line (x)
		@param y1 end position of line (y)
	*/
	public void Erase(int x0, int y0, int x1, int y1)
	{	W.EraseLine(x0,y0,x1,y1);}
	/** An image may be placed in the window. The image is taken
		from a gif or jpeg file and placed in the window. The image is scaled
		according to given size.
		@param Id a string used to identify the image
		@param Name the name of the file containing the image
		@param x top left corner of image (x-coordinate)
		@param y top left corner of image (y-coordinate)
		@param dx size of image (in x direction)
		@param dy size of image (in y direction)
	*/
   public void DrawImage(String Id,String Name,int x,int y,int dx,int dy)
   {W.PlaceImage(Id,Name,x,y,dx,dy);}
	/** Remove an image identified by a string.
		@param Id the identifying strin of the image.
	*/
   public void EraseImage(String Id) {W.RemoveImage(Id);}
	/** Change an image. The identified picture will be changed
		to a new image fetched from a file. Notice that the same
		identifier still is the valid name of this picture in
		the window.
		@param Id the identifying string of the image
		@param Name the name of the file containing the new image 
	*/
   public void ChangeImage(String Id,String Name)
   {W.ChangeImage(Id,Name);}

	
	/*****************************************************
	*		Att anv�ndas av Actions
	*****************************************************/
	/** This methode is used from an action registered to
		a button. It is used to leave the input mode of the window
		with a specified value, often used to identify the button
		that has been pressed.
		@param Val the value to specify
	*/
	public void LeaveInput(int Val)
	{Leave=true; ReturnValue=Val;}
	
	/*****************************************************
	*		Felhantering
	*****************************************************/
	
	public void Error(String T)
	{	w ErrorW; Message E=null;
		ErrorW=new w(200,50,"ERROR",red);
		ErrorW.EnableMouse();
		ErrorW.SetPosition(10,30);
		ErrorW.Write(T);
		while (E==null)
		{	E=ErrorW.GetMouseButton();}
		ErrorW.Destroy();
	}
	/*****************************************************
	*		Hj�lprutiner
	*****************************************************/
	private int FriKnapp()
	{	boolean Funnen=false;
		int F=0;
		while (!Funnen && F<MaxKnapp)
		{	if (LedigKnapp[F]) {Funnen=true; LedigKnapp[F]=false;}
			else F=F+1;
		}
		if (Funnen) return F; else return -1;
	}
	
	private void Frig�rKnapp(int I)
	{if (I>=0&&I<MaxKnapp) LedigKnapp[I]=true;}
	private void Frig�rKnapp()
	{for (int I=0; I<MaxKnapp; I=I+1) LedigKnapp[I]=true;}
	
	private int FriRuta()
	{	boolean Funnen=false;
		int F=0;
		while (!Funnen && F<MaxRuta)
		{	if (LedigRuta[F]) {Funnen=true; LedigRuta[F]=false;}
			else F=F+1;
		}
		if (Funnen) return F; else return -1;
	}
	
	private void Frig�rRuta(int I)
	{if (I>=0&&I<MaxRuta) LedigRuta[I]=true;}
	private void Frig�rRuta()
	{for (int I=0; I<MaxRuta; I=I+1) LedigRuta[I]=true;}
}
