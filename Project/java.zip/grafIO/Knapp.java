package grafIO;
import window.*;
import java.awt.*;
/***********************************************************************
*				Knapp
* En klass f�r att definiera en knapp i f�nstret. Knappen har en position,
* en storlek (kvadratisk), och en text. Nu �ven rektangul�r.
* Konstruktor:
*	Knapp(String,int,int,int)		En knapp skapas med namn, position 
*											och storlek. Ritas inte ut!
* Metoder:
*	selected(int,int)-->boolean	true om angivna kordinater inom knappen
*	draw()								knappen ritas ut
*	blink()								knappen blir r�d i 0.1 sekund
*	marked()								knappen f�r r�d f�rg
*	unmark()								knappen �terg�r till normal f�rg
***********************************************************************/
class Knapp
{	private String Name;
	private w W;
	private int x0,y0,h�jd,bredd;
	private Action Act;
	private Color KnappF�rg,MarkColor=w.red;
		
	Knapp(w F,String T, int x, int y, int r)
	{	Name=T;
		x0=x;
		y0=y;
		h�jd=r;
		bredd=r;
		W=F;
		KnappF�rg=null;
	}
		
	Knapp(w F,String T, int x, int y, int r,Color C)
	{	Name=T;
		x0=x;
		y0=y;
		h�jd=r;
		bredd=r;
		W=F;
		KnappF�rg=C;
	}
		
	Knapp(w F,String T, int x, int y, int b,int h)
	{	Name=T;
		x0=x;
		y0=y;
		h�jd=h;
		bredd=b;
		W=F;
		KnappF�rg=null;
	}
		
	Knapp(w F,String T, int x, int y, int b,int h,Color C)
	{	Name=T;
		x0=x;
		y0=y;
		h�jd=h;
		bredd=b;
		W=F;
		KnappF�rg=C;
	}
		
	boolean selected(int x, int y)
	{return (x>x0)&&(x<x0+bredd)&&(y>y0)&&(y<y0+h�jd);}
		
	void draw()
	{	if (KnappF�rg==null) W.DrawRectangle(x0,y0,x0+bredd,y0+h�jd);
		else 
			{	W.SetFiller(KnappF�rg);
				W.FillRectangle(x0,y0,x0+bredd,y0+h�jd);
				W.SetFiller(MarkColor);
			}
		W.SetPosition(x0+3,y0+h�jd/2+2);
		W.Write(Name);
	}
	void blink()
	{	W.FillRectangle(x0,y0,x0+bredd,y0+h�jd);
		W.Delay(100);
		W.EraseFilledRectangle(x0,y0,x0+bredd,y0+h�jd);
		if (KnappF�rg==null) W.DrawRectangle(x0,y0,x0+bredd,y0+h�jd);
		else 
			{	W.SetFiller(KnappF�rg);
				W.FillRectangle(x0,y0,x0+bredd,y0+h�jd);
				W.SetFiller(MarkColor);
			}
		W.SetPosition(x0+3,y0+h�jd/2+2);
		W.Write(Name);
	}
	void marked()
	{	W.FillRectangle(x0,y0,x0+bredd,y0+h�jd);
		W.SetPosition(x0+3,y0+h�jd/2+2);
		W.Write(Name);
	}
	void unmark()
	{	W.EraseFilledRectangle(x0,y0,x0+bredd,y0+h�jd);
		if (KnappF�rg==null)W.DrawRectangle(x0,y0,x0+bredd,y0+h�jd);
		else 
			{	W.SetFiller(KnappF�rg);
				W.FillRectangle(x0,y0,x0+bredd,y0+h�jd);
				W.SetFiller(MarkColor);
			}
		W.SetPosition(x0+3,y0+h�jd/2+2);
		W.Write(Name);
	}
	void clear()
	{	W.EraseFilledRectangle(x0,y0,x0+bredd,y0+h�jd);
		W.ClearRectangle(x0,y0,x0+bredd+1,y0+h�jd+1);
	}
	void SetAction(Action A) {	Act=A;}
	void RemoveAction() {Act=null;}
	void Perform()
	{	if (Act!=null) {Act.DoAction();}
		else {}
	}
}
