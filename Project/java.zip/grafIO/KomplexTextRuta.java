package grafIO;
import struct.*;
import window.*;
import java.awt.Color;
class KomplexTextRuta extends TextRuta
{  
   private List Rader;
   private int R,Pos;
   private int M,N,Frad;
   private int X0,Y0,B,H;
   private w W;
   private boolean Active=false, ScrollOnly=false;
   private boolean LCK=false;
   private Color RamF�rg=w.red,GrundF�rg=w.yellow,MarkF�rg=w.white;
   private String Rubrik;

   class Rad extends Element
   {  char[] L;
      int Epos=0;
      boolean End=false;

      Rad(){L=new char[2*M];}

      char[] Insert(int p,char C)
      {  int i;
         char[] Svans=null;
         if(p>=Epos){L[Epos]=C; Epos=Epos+1;}
         else
         {  for(i=Epos-1;i>=p;i=i-1){L[i+1]=L[i];}
            L[p]=C; Epos=Epos+1;
         }
         if(Epos>M)
         {	int q,r;
         	char Ch;
         	q=M; Ch=L[q];
         	while(Ch!=' '&&q>4){q=q-1; Ch=L[q];}
         	q=q+1; r=Epos-q;
         	Svans=new char[r];
         	for(i=0;i<r;i=i+1){Svans[i]=L[i+q];}
         	Epos=q;
         }
         if(Epos<0)Epos=0;
         Pos=Pos+1;
         if(Pos>Epos) Pos=Epos;
         Trim(L,Epos);
         return Svans;
      }

      char[] Insert(int p, char[] C)
      {  int i,n;
         char[] Svans=null;
         n=C.length;
         if(p>=Epos)
         {  
         	for(i=0;i<n;i=i+1){L[Epos+i]=C[i];}
            Epos=Epos+n;
         }
         else
         {  for(i=Epos-1;i>=p;i=i-1){L[n+i]=L[i];}
            for(i=0;i<n;i=i+1){L[p+i]=C[i];}
            Epos=Epos+n;
         }
         if(Epos>M)
         {  int q,r;
         	char Ch;
            q=M; Ch=L[q];
            while(Ch!=' '&&q>4){q=q-1; Ch=L[q];}
            q=q+1; r=Epos-q;
            Svans=new char[r];
            for(i=0;i<r;i=i+1){Svans[i]=L[q+i];}
            Epos=q;
         }
         Pos=Pos+Size(C);
         if(Pos>Epos) Pos=Epos;
         Trim(L,Epos);
         return Svans;
      }

      char[] Split(int Pos)
      {  int i,n;
         char[] Svans;
         n=Epos-Pos;
         Svans=new char[n];
         for(i=0;i<n;i=i+1){Svans[i]=L[Pos+i];}
         Epos=Pos;
         return Svans;
      }

      void Delete(int Pos)
      {  int i;
         if(Pos>=Epos){Epos=Epos-1;}
         else
         if(Pos!=0)
         {  for(i=Pos-1;i<Epos-1;i=i+1){L[i]=L[i+1];}
            Epos=Epos-1;
         }
         else {}
         if(Epos<0)Epos=0;
      }

      void SetEnd(){End=true;}
      void RemoveEnd(){End=false;}
      boolean GetEnd(){return End;}
      
      char[] GetChars() {return L;}
      String GetString(){return new String(L,0,Epos);}
      int Length(){return Epos;}
      
      public boolean Equal(Element E) {return false;}
      public boolean Key(Element E) {return false;}
   }
   
/* *********************************************************
   Constructor of TextWindow
*/
   KomplexTextRuta(w F,int x,int y,int n,int m,String Rub)
   {  W=F;
   	Rubrik=Rub;
      X0=x; Y0=y; M=m; N=n;
      B=M*8; H=(N+1)*10;
      Frad=1;
      Rader=new List(new Rad());
      R=1; Pos=0;
   }
   
/* *********************************************************
   Methods of TextWindow
*/
   public boolean selected(int x,int y)
   {return (x>X0)&&(x<X0+B)&&(y>Y0)&&(y<Y0+H);}

   public void selectpos(int x,int y)
   {	int dx,dy,max;
   	max=Rader.Cardinal();
   	dy=(y-Y0)/10;
   	if(dy<1) {dy=1;} else if(dy>N) {dy=N;}
   	R=Frad+dy-1;
   	if(R>max) R=max;
   	max=((Rad)Rader.Get(R)).Length();
   	dx=(x-X0)/6;
   	if(dx<0){dx=0;} else if(dx>max){dx=max;}
   	Pos=dx;
   	Display();
   }

   public void deletechar()
   {	Rad AR;
   	if (LCK) return;
   	AR=(Rad)Rader.Get(R);
   	AR.Delete(Pos);
   	Pos=Pos-1;
   	if(Pos<0)Pos=0;
   }
   
   public void commandkey(int C)
   {	Rad RR; int p;
   	if(C==37)
   	{	Pos=Pos-1;
   		if(Pos<0) Pos=0;
   	}
      else
      if(C==38)
      {	R=R-1;
      	if(R<1)R=1;
      	RR=(Rad)Rader.Get(R);
      	p=RR.Length();
      	if(Pos>p) Pos=p;
      }
      else
      if(C==39)
      {	Pos=Pos+1;
      	RR=(Rad)Rader.Get(R);
      	if(Pos>RR.Length()) Pos=Pos-1;
      }
      else
      if(C==40)
      {	R=R+1;
      	if(R>Rader.Cardinal())R=Rader.Cardinal();
      	RR=(Rad)Rader.Get(R);
      	p=RR.Length();
      	if(Pos>p) Pos=p;
      }
      else {}
      Display();
   }

   public void insertchar(char C)
   {	if(LCK) return;
      if((int)C==10)
      {	char[] S;
      	Rad AR;
      	AR=(Rad)Rader.Get(R);
      	AR.SetEnd();
      	S=AR.Split(Pos);
      	R=R+1;
      	AR=new Rad();
      	AR.Insert(0,S);
      	if(R>Rader.Cardinal()) Rader=AdderaRad(Rader,AR);
      	else Rader=InsertBefore(Rader,AR,R);
      }
      else
      {  char[] S;
         Rad AR;
         AR=(Rad)Rader.Get(R);
         if(AR==null)
         {	AR=new Rad(); 
         	S=AR.Insert(Pos,C);
         	Rader=AdderaRad(Rader,AR);
         }
         else
         {S=AR.Insert(Pos,C);}
         if(S!=null&&AR.GetEnd())
         {	AR.RemoveEnd(); R=R+1; Pos=0;
         	AR=new Rad();
         	AR.Insert(Pos,S);
         	AR.SetEnd();
         	if(R>Rader.Cardinal()) Rader=AdderaRad(Rader,AR);
         	else Rader=InsertBefore(Rader,AR,R);
         }
         else
         {	while(S!=null)
         	{  R=R+1; Pos=0;
         		AR=(Rad)Rader.Get(R);
         		if(AR==null)
         		{	AR=new Rad(); 
         			S=AR.Insert(Pos,S);
         			Rader=AdderaRad(Rader,AR);
         		}
         		else
            	{S=AR.Insert(0,S);}
         	}
         }
      }
      Display();
   }
   
   private void puttext(char[] S)
   {  char[] A;
   	Rad AR;
   	AR=(Rad)Rader.Get(R);
   	if(AR==null)
   	{	AR=new Rad();
   		A=AR.Insert(0,S);
   		Rader=AdderaRad(Rader,AR);
   	}
   	else
   	{A=AR.Insert(Pos,S);}
   	if(A!=null&&AR.GetEnd())
      {	AR.RemoveEnd(); R=R+1; Pos=0;
         AR=new Rad();
         AR.Insert(Pos,A);
         AR.SetEnd();
         if(R>Rader.Cardinal()) Rader=AdderaRad(Rader,AR);
         else Rader=InsertBefore(Rader,AR,R);
      }
      else
   	{	while (A!=null)
   		{	R=R+1; Pos=0;
   			AR=(Rad)Rader.Get(R);
   			if(AR==null)
         	{	AR=new Rad(); 
        	 		A=AR.Insert(Pos,A);
         		Rader=AdderaRad(Rader,AR);
         	}
         	else
   			{A=AR.Insert(0,A);}
   		}
   	}
   	Display();
   }

   public void puttext(String S)
   {	while(S.length()>M)
   	{	puttext(S.substring(0,M).toCharArray());
   		S=S.substring(M);
   	}
   	puttext(S.toCharArray());
   }
   
   
/*   {  char[] A;
   	Rad AR;
   	AR=(Rad)Rader.Get(R);
   	if(AR==null)
   	{	AR=new Rad();
   		A=AR.Insert(0,S.toCharArray());
   		Rader=AdderaRad(Rader,AR);
   	}
   	else
   	{A=AR.Insert(Pos,S.toCharArray());}
   	if(A!=null&&AR.GetEnd())
      {	AR.RemoveEnd(); R=R+1; Pos=0;
         AR=new Rad();
         AR.Insert(Pos,A);
         AR.SetEnd();
         if(R>Rader.Cardinal()) Rader=AdderaRad(Rader,AR);
         else Rader=InsertBefore(Rader,AR,R);
      }
      else
   	{	while (A!=null)
   		{	R=R+1; Pos=0;
   			AR=(Rad)Rader.Get(R);
   			if(AR==null)
         	{	AR=new Rad(); 
        	 		A=AR.Insert(Pos,A);
         		Rader=AdderaRad(Rader,AR);
         	}
         	else
   			{A=AR.Insert(0,A);}
   		}
   	}
   	Display();
   }
*/
   
   public void puttext(String[] S)
   {	for(int i=0;i<S.length;i=i+1){puttext(S[i]);}}
   
/*   public void puttext(String[] S)
   {	char[] A;
   	Rad AR;
   	int i,k;
   	k=S.length;
   	i=0;
   	while (i<k)
   	{	AR=(Rad)Rader.Get(R);
   		if(AR==null)
   		{	AR=new Rad();
   			A=AR.Insert(0,S[i].toCharArray());
   			Rader=AdderaRad(Rader,AR);
   		}
   		else
   		{A=AR.Insert(Pos,S[i].toCharArray());}
   		while (A!=null)
   		{	R=R+1; Pos=0;
   			AR=(Rad)Rader.Get(R);
   			if(AR==null)
         	{	AR=new Rad(); 
         		A=AR.Insert(Pos,A);
         		Rader=AdderaRad(Rader,AR);
         	}
         	else
   			{A=AR.Insert(0,A);}
   		}
   		i=i+1;
   	}
   	Display();
   }
*/

   public void puttext(String S[],int R){}
   
   public void puttext(String S,int R){}
   
   public String[] gettext()
   {	Element[] RR; String[] SS;
   	int n=Rader.Cardinal();
   	RR=Rader.MakeArray();
   	SS=new String[n];
   	for(int i=0;i<n;i=i+1){SS[i]=((Rad)RR[i]).GetString();}
   	return SS;
   }

   public void mark(){Active=true; Display();}
   public void unmark(){Active=false; Display();}
   
   public boolean Locked() {return LCK;}
   public void Lock() {LCK=true;}
   public void UnLock() {LCK=false;}
   
   public void setcolor(Color C) {GrundF�rg=C;}
   public void SetHeaderColor(Color C) {RamF�rg=C;}
   public void SetFrameColor(Color C) {GrundF�rg=C;}
   public void SetMarkColor(Color C) {MarkF�rg=C;}
   
   public void SetNonActive()
   {	Active=false;
   	if(ScrollOnly)
   	{	W.SetPosition(X0+B-10,Y0+10);
   		W.SetPen(RamF�rg);
   		W.Write("\u005e");
   		W.SetPen(w.black);
   	}
   	ScrollOnly=false;
   }
   public void SetActive() {Active=true; ScrollOnly=false;}
   public void SetScrollable()
   {	ScrollOnly=true;
   	W.SetPosition(X0+B-10,Y0+10);
   	W.Write("\u005e");
   }

   public void draw()
   {  Color C;
      C=W.GetFiller();
      W.SetFiller(RamF�rg);
      W.FillRectangle(X0,Y0,X0+B,Y0+10);
      W.SetPosition(X0,Y0+10);
      W.Write(Rubrik);
      W.SetFiller(GrundF�rg);
      W.FillRectangle(X0,Y0+11,X0+B,Y0+H);
      W.SetFiller(C);
   }

   public void clear()
   {W.ClearRectangle(X0,Y0,X0+B+1,Y0+H+1);}
   
   /* ***************************************** */
   
   void Display()
   {	int Antal; Color C;
   	C=W.GetFiller();
   	if(Active) W.SetFiller(MarkF�rg);
   	else W.SetFiller(GrundF�rg);
   	W.FillRectangle(X0,Y0+11,X0+B,Y0+H);
   	W.SetFiller(C);
   	Antal=Rader.Cardinal();
   	if(Antal<N) {Frad=1;}
   	else
   	if(Antal>N) {Antal=N; Frad=R-(Antal-1)/2;}
   	if (Frad<1) Frad=1;
   	Display(R,Pos,Frad,Frad+Antal-1);
   }
   
   void Display(int Cr,int Cp,int Start,int Slut)
   {	int i,Xs,Ys,k;
   	char[] Rd; String S; Rad LL;
   	if(R==0) return;
   	Xs=X0; Ys=Y0+20;
   	for(i=Start;i<Cr;i=i+1)
   	{	S=((Rad)Rader.Get(i)).GetString();
   		W.SetPosition(Xs,Ys);
   		W.Write(S);
   		Ys=Ys+10;
   	}
   	LL=(Rad)Rader.Get(i);
   	Rd=LL.GetChars();
   	k=LL.Length()-Cp;
   	if(k<0)k=0;
   	if(LCK) {S=LL.GetString();}
   	else {S=String.valueOf(Rd,0,Cp)+"\u005e"+String.valueOf(Rd,Cp,k);}
   	W.SetPosition(Xs,Ys);
   	W.Write(S);
   	Ys=Ys+10;
   	for(i=Cr+1;i<=Slut;i=i+1)
   	{	LL=(Rad)Rader.Get(i);
   		if(LL!=null)
   		{	S=LL.GetString();
   			W.SetPosition(Xs,Ys);
   			W.Write(S);
   			Ys=Ys+10;
   		}
   	}
   }
   
   List AdderaRad(List L,Rad R)
   {return L.Concatenate(new List(R));}
   
   List InsertBefore(List L,Rad R,int k)
   {	List L1,L2;
   	L1=L.First(k);
   	L2=L.Tail(k-1);
   	return L1.Concatenate(new List(R,L2));
   }
   
   int Size(char[] L)
   {	int i,max;
   	max=L.length;
   	i=0;
   	while(i<max&&L[i]!='\0'){i=i+1;}
   	return i;
   }
   void Trim(char[] C,int l)
   {	int n;
   	n=C.length;
   	for(int i=l;i<n;i=i+1){C[i]='\0';}
   }
}
