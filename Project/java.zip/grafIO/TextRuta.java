package grafIO;
import window.*;
import java.awt.*;
abstract class TextRuta
{  abstract void draw();
	abstract void SetActive();
	abstract void SetNonActive();
	abstract void SetScrollable();
	abstract boolean Locked();
	abstract void Lock();
	abstract void UnLock();
	abstract boolean selected(int x, int y);
	abstract void setcolor(Color C);
	abstract void SetHeaderColor(Color C);
	abstract void SetFrameColor(Color C);
	abstract void SetMarkColor(Color C);
	abstract void selectpos(int x,int y);
	abstract void mark();
	abstract void unmark();
	abstract void commandkey(int c);
	abstract void insertchar(char c);
	abstract void deletechar();
	abstract String[] gettext();
	abstract void puttext(String S);
	abstract void puttext(String[] S);
	abstract void puttext(String[] S,int r);
	abstract void puttext(String S,int r);
	abstract void clear();
}
