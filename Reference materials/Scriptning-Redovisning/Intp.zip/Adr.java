class Adr
{	int a1,a2,a3,a4;
	Adr(int M,int G,int R,int T){a1=M;a2=G;a3=R;a4=T;}
	public void Debug()
	{  System.out.println("Adr:"+a1+"/"+a2+"/"+a3+"/"+a4);}
}
