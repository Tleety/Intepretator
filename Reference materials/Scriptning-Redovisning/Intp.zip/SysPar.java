class SysPar
{	int Type,Reg;
	SysPar(int I,int K){Type=I;Reg=K;}
	public int GetType(){return Type;}
	public int GetReg(){return Reg;}
}
